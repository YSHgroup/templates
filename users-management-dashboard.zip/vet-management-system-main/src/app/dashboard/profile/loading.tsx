import ProfileSkeleton from "@/components/dashboard/skeletons/ProfileSkeleton";

const ProfileLoadingSkeleton = () => {
  return <ProfileSkeleton />;
};

export default ProfileLoadingSkeleton;
