const NotificationsPage = () => {
  return <div>Notifications Page</div>;
};

export default NotificationsPage;
