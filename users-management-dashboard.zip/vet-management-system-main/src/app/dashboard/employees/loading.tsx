import EmployeesSkeleton from "@/components/dashboard/skeletons/EmployeesSkeleton";

const EmployeesLoadingSkeleton = () => {
  return <EmployeesSkeleton />;
};

export default EmployeesLoadingSkeleton;
