import Calendar from "@/components/Calendar";

const AppointmentsPage = () => {
  return <Calendar events={[]} />;
};

export default AppointmentsPage;
