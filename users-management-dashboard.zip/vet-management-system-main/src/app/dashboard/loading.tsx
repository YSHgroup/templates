import DashboardSkeleton from "@/components/dashboard/skeletons/DashboardSkeleton";

const DashboardLoadingSkeeton = () => {
  return <DashboardSkeleton />;
};

export default DashboardLoadingSkeeton;
