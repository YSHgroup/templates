import ClientsSkeleton from "@/components/dashboard/skeletons/ClientsSkeleton";

const ClientsLoadingSkeleton = () => {
  return <ClientsSkeleton />;
};

export default ClientsLoadingSkeleton;
