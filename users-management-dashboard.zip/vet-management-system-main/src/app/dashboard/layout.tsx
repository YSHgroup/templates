import DashboardLayout from "@/components/layouts/Dashboard";

export default DashboardLayout;
