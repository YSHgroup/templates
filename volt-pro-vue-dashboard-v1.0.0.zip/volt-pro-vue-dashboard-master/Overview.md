Volt Pro Vue Dashboard is a premium admin dashboard template built using the fastest growing front-end JavaScript framework, Vue.js,  and the most popular front-end open source toolkit, Bootstrap.
It features out-of-the-box and customizable components, customized plugins, and dozens of example pages that you can use to kick start your web app development.

## Latest Recoommendations - Vue 3, Vite, Vue-Router, Pinya, etc
This template uses the latest recommendations and tools by the core Vue team. No need to purchase a template and use time upgrading.

### Vue 3
On February 7, 2022, Vue 3 became the official version of Vue.js. The core Vue team rolled out new documentation and recommendations for creating Vue projects. Vue has grown from just a library to a framework. Routing, state management, dev tools, are all in Vue's ecosystem. 

### Vite
Many of us who have Vue experience created apps using Vue's webpack-based `vue-cli`. Evan Yu, the creator of Vue, has built a framework-agnostic build tool called Vite which is magnitudes faster and is now the recommended built tool by the Vue core team.

This template was built from Vue's `create-vue` init repository, so it uses Vite as its build tool. You will be amazed how fast your app builds and development server is ready. With hot-module reloading built in, any change you make to styles, TypeScript/JavaSript, and Vue templates are instantly reflected in the browser. It happens so fast it feels like magic.

### TypeScript
TypeScript is a strongly typed programming language that builds on JavaScript. This helps you catch errors at compile time instead of runtime. It also gives you great tooling tooling support in your editor, like navigating between types and finding all references.

Vue3 and its ecosystem were written in TypeScript. Although there is a learning curve, it is recommended for any production application. This template was written in TypeScript and demonstrates how to use types with your code and 3rd party libraries. Some 3rd party libraries didn't have types, and some conflicted with Vue's types. Checkout the `env.d.ts` and `tsconfig.json` files to see how to make workarounds to satisfy TypeScript.

### Composition API with `<script setup>`
THe Vue core team recommends using the Composition API with `<script setup>` syntax when creating apps using Single File Components. We can attest this provides a very good developer experience (DX) without extra ceremony. For example, any reactive variable you declare will be available in your template.

### Vue Router
This template has routing built in and makes heavy use of Vue's core routing library.

### Pinia
Prior to Vue's official rollout of Vue3, Vuex was the standard state management library. Eduardo San Martin Morote, the author of Vue Router, wrote Pinia as an easy-to-use replacement and upgrade of Vuex. It has first-class TypeScript support and works seamlessly with Vue's reactive system. Thank you Eduardo!


## More than a starter pack
Vue.js has made it super simple to create a new app using their `create-vue` init repository. Simply install `Node.js` and run `npm install vue@latest` in a terminal and you can get started on a Vue app with TypeScript, routing, state management, and some sample pages.

This is a great start, but it'll take a lot more work to turn it into a real app or website.

The goal of this Vue template is to save you time by providing a base of real-world application structure, components, and integrations.

### 3rd Party JavaScript Libraries
In a real app, you will use external JavaScript libraries for charts, maps, calendars, notifications, etc. Some have TypeScript definitions, and some don't. Some have Vue components already, and some don't. Some have TypeScript definitions that conflict with Vue. This template has examples of all the above. For examnple, the calendar was already a Vue component, but the map was not, and that's ok. Vue is awesome in that way and this template will demonstrate how easy it is to use both 3rd party Vue components and plain JavaScript (vanillajs) libraries.

### CSS Framework
Rather than writing UI styles from scratch, you will most likely want to use a CSS framework to take advantage of prebuilt HTML components, layouts, typography, helpers, elements like dropdowns and tooltips, etc.

This template uses the most popular CSS framework in the world - Bootstrap. Bootstrap is very well documented, easy to use, pays attention to accessibility, and is easy to override and extend. At the time of this template's release, we used Bootstrap's latest version - v5.1.3.

One reason why Bootstrap is the most popular CSS framework is its use of SCSS variables. All styles can be overwritten or extended by simply creating your own SASS/SCSS file and variables.

### Data-driven Components
Most application user interfaces are data driven. Click on a page and see nicely formatted data or lists of things you're interested in. Rather than code each page using just static HTML, this template relies on composing interfaces using lists of data and parent/child components to display the data. For example, the Users page dynamically creates the message list from data returned from an API call.  Backend API service are simulated but stubbed out so you can easily plug in. Even pages that seem to not have "data", like the theme's landing page, is data driven. Basically anywhere that has repeat elements is a good candidate for data-driven design. Even the navigation items are data driven. This makes it very easy to edit HTML and styles because you only edit one element and let the data dynamically generate the UI. This does have some challenges when items in your list have differences, like how to use a FontAwesome icon or a HeroIcon. Also challenging is dynanically referencing images for each item in your HTML. This template will show you.


### Component Cross Communication
Basic apps and layouts seldom have the need for cross-component communication, that is, communication between components that do not have a parent-child relationship. But most real-world apps do. There's a lot of documentation and examples on parent-child communication using `props` and `emits`. Not so much for cross-component communication. The sidebar toggle in this template demonstrates how you could go about communicating between components across the app.

### Sample Vue components with `v-model` bindings and custom events
I've read the documentation for custom component events several times, but it wasn't until I actually created components with custom events did it make sense. The Pro version of this template includes a custom Modal component that demonstrates using `v-model` with components. It also demonstrates how to emit and listen to custom events in TypeScript with full type support. By looking at this component you'll get a much better grasp of wiring up your own custom events and `v-model`.














