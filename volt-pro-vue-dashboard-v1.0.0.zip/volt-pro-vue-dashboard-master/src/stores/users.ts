import { defineStore } from 'pinia'
import _ from 'lodash'

export const UserStatus = new class {
    readonly UNDEFINED = 0;
    readonly ACTIVE = 1;
    readonly PENDING = 2;
    readonly SUSPENDED = 3;
}

export interface User{
    id: number;
    avatar?: string;
    name: string;
    email: string;
    createdDate: string;
    status: number;
    bgClass?: string; //would not be needed in real-world scenerio
}

//Stores should be used for global app state.
//Since this is only used by the Users page, this is better in a UserService. I've included UserService.ts with commented out functionality.
//This is here just as an example for using Pinia stores.
export const useUsersStore = defineStore({
    id: 'users',
    state: () => ({
        users: [] as User[]
    }),
    actions: {
        //called in src/views/Dashboard.vue
        async initUsers(){
            //simulate delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            this.users = await getUsers();
        },
        async deleteUser(id: number) {
            //simulate delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            _.remove(this.users, u => u.id == id);
        },
        async deleteUsers(ids: number[]){
             //simulate delay
             await new Promise(resolve => setTimeout(resolve, 1000));
             ids.forEach(id => {
                _.remove(this.users, u => u.id == id);
             })
        }
    }
})

async function getUsers(): Promise<User[]>{
    return Promise.resolve([
        {
            id: 1,
            avatar: 'profile-picture-1.jpg',
            name: 'Roy Fendley',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 1
        },
        {
            id: 2,
            name: 'Scott Anderson',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 1,
            bgClass: 'bg-secondary'
        },
        {
            id: 3,
            avatar: 'profile-picture-2.jpg',
            name: 'George Driskell',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 1
        },
        {
            id: 4,
            avatar: 'profile-picture-3.jpg',
            name: 'Bonnie Green',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 1
        },
        {
            id: 5,
            avatar: 'profile-picture-7.jpg',
            name: 'Ronnie Buchanan',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 2
        },
        {
            id: 6,
            name: 'Jane Rinehart',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 2,
            bgClass: 'bg-secondary'
        },
        {
            id: 7,
            avatar: 'profile-picture-4.jpg',
            name: 'William Ginther',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 2
        },
        {
            id: 8,
            avatar: 'profile-picture-5.jpg',
            name: 'Margaret Dow',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 3
        },
        {
            id: 9,
            name: 'Michael Hopkins',
            email: 'info@example.com',
            createdDate: '2020-02-10',
            status: 3,
            bgClass: 'bg-purple text-white'
        }
    ])
}
