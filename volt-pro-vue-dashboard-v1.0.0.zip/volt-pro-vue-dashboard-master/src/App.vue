<template>
  <router-view/>
  <ToastManager :remove-after-shown="false" />
</template>

<script lang="ts" setup>
import ToastManager from '@/components/Shared/ToastManager.vue'

</script>