import {DateTime} from 'luxon'

export class AuthorEarnings{
    constructor(
        public avatarFilename: string,
        public authorName: string,
        public authorTitle: string,
        public earnings: number
    ){}
}

export async function getAuthorEarnings(): Promise<AuthorEarnings[]>{
    return Promise.resolve([
        new AuthorEarnings('profile-picture-1.jpg', 'Christ Wood', 'Graphic Designer', 1834),
        new AuthorEarnings('profile-picture-3.jpg', 'Bonnie Green', 'Web Developer', 1355),
        new AuthorEarnings('profile-picture-2.jpg', 'Christ Wood', 'Vue Developer', 1297),
        new AuthorEarnings('profile-picture-4.jpg', 'Neil Sims', 'Python Developers', 875),
        new AuthorEarnings('profile-picture-5.jpg', 'Rebecca Sas', 'UI/UX, Art Director', 872),
        new AuthorEarnings('profile-picture-6.jpg', 'Jacklyn Brown', 'UI/UX, Art Director', 605),
        new AuthorEarnings('profile-picture-7.jpg', 'Melinda Norrow', 'UI/UX, Art DIrector', 305)
    ])
}

export class Notification{
    constructor(
        public iconShapeColor: string,
        public iconName: string,
        public subject: string,
        public message: string,
        public timestamp: DateTime
    ){}
}

export async function getNotifications(): Promise<Notification[]>{
    return Promise.resolve([
        new Notification('purple', 'ShoppingCartIcon', 'You sold an item', 'Bonnie Green just purchased "Volt - Admin Dashboard (vue)"!', DateTime.now()),
        new Notification('primary', 'InboxIcon', 'New message', `Let's meet at Starbucks at 11:30. Wdyt?`, DateTime.now().minus({minutes: 8})),
        new Notification('warning', 'ExclamationIcon', 'Product issue', 'A new issue has been reported for Pixel Pro.', DateTime.now().minus({minutes: 10})),
        new Notification('success', 'RefreshIcon', 'Product update', 'Spaces - Listings Template has been updated', DateTime.now().minus({hours: 4})),
        new Notification('success', 'RefreshIcon', 'Product update', 'Vold - Admin Dashboard has been updated', DateTime.now().minus({hours: 8}))
    ])
}

export class Event{
    public startDateDate: Date;

    constructor(
        public title: string,
        public organizedBy: string,
        public startDate: string,
        public location: string,
        public endDate?: string
    ){
        this.startDateDate = new Date(this.startDate);
    }
}

export async function getEvents(): Promise<Event[]>{
    return Promise.resolve([
        new Event('Newmarket Nights', 'University of Oxford', '2020-08-10 6:00', 'Cambridge Boat Club, Cambridge'),
        new Event('Noco Hemp Expo', 'University of Oxford', '2020-09-12', 'Denver Expo Club, USA', '2020-09-18'),
        new Event('EmTech MIT Conference', 'Organiced by MIT', '2020-09-15', 'California, USA', '2020-09-18'),
        new Event('Canadian National Exhibition (CNE)', 'Organized by University of Oxford', '2020-09-20', 'Toronto, Canada', '2020-10-07')
    ])
}

export class CountryVisit{
    constructor(
        public name: string,
        public flagFilename: string,
        public visitCount: number,
        public visitPercentage: number
    ){}
}

export async function getCountryVisits(): Promise<CountryVisit[]>{
    return Promise.resolve([
        new CountryVisit('United States', 'united-states-of-america.svg', 272109, 34),
        new CountryVisit('Canada', 'canada.svg', 160064, 20),
        new CountryVisit('Germany', 'germany.svg', 120048, 15),
        new CountryVisit('France', 'france.svg', 100048, 8),
        new CountryVisit('Japan', 'japan.svg', 56022, 7),
        new CountryVisit('Italy', 'italy.svg', 48019, 6),
        new CountryVisit('Netherlands', 'netherlands.svg', 40016, 5),
        new CountryVisit('Sweden', 'sweden.svg', 26016, 3)
    ])
}