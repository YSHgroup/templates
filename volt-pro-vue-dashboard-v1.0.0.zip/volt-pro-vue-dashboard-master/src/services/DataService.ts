export interface PageVisit{
    pageName: string;
    pageViews: number;
    pageValue: number;
    bounceRate: number;
    bounceRateIncreased: boolean;
}

export function getPageVisitsSummaryAsync(): Promise<PageVisit[]>{
    return Promise.resolve([{
        pageName: '/demo/admin/index.html',
        pageViews: 3225,
        pageValue: 20,
        bounceRate: 42.55,
        bounceRateIncreased: true
    },{
        pageName: '/demo/admin/forms.html',
        pageViews: 2987,
        pageValue: 0,
        bounceRate: 43.24,
        bounceRateIncreased: false
    },
    {
        pageName: '/demo/admin/util.html',
        pageViews: 2844,
        pageValue: 294,
        bounceRate: 32.35,
        bounceRateIncreased: false
    },
    {
        pageName: '/demo/admin/validation.html',
        pageViews: 2050,
        pageValue: 147,
        bounceRate: 50.87,
        bounceRateIncreased: true
    },
    {
        pageName: '/demo/admin/modals.html',
        pageViews: 1483,
        pageValue: 19,
        bounceRate: 26.12,
        bounceRateIncreased: false
    }]);
}


interface TeamMember{
    avatarFilename: string;
    name: string;
    status: number;
}

function getTeamMembersAsync(): Promise<TeamMember[]>{
    return Promise.resolve([{
        avatarFilename: 'profile-picture-1.jpg',
        name: 'Chris Wood',
        status: 1
    },
    {
        avatarFilename: 'profile-picture-2.jpg',
        name: 'Jose Leos',
        status: 2
    },
    {
        avatarFilename: 'profile-picture-3.jpg',
        name: 'Bonnie Green',
        status: 0
    },{
        avatarFilename: 'profile-picture-4.jpg',
        name: 'Neil Sims',
        status: 1
    }])
}

export interface Project{
    name: string;
    percentage: number;
}

export function getProjectsAsync(): Promise<Project[]>{
    return Promise.resolve([
        {
            name: 'Rocket - SaaS Template',
            percentage: 75
        },
        {
            name: 'Themesberg - Design System',
            percentage: 60
        },
        {
            name: 'Homepage Design in Figma',
            percentage: 45
        },
        {
            name: 'Backend for Themesberg v2',
            percentage: 34
        }
    ])
}

export interface TrafficSource{
    name: string;
    type: string;
    faIcon: string|null;
    heroIcon: string|null;
    category: string|null;
    globalRank: number|null;
    sharePercent: number;
    changePercent: number;
}

export function getTrafficSourcesAsync(): Promise<TrafficSource[]>{
    return Promise.resolve(
        [{
            name: 'Direct',
            type: 'Direct',
            faIcon: null,
            heroIcon: 'Globe',
            category: null,
            globalRank: null,
            sharePercent: 51,
            changePercent: 2.45
        },
        {
            name: 'Google Search',
            type: 'Search / Organic',
            faIcon: 'google',
            heroIcon: null,
            category: null,
            globalRank: null,
            sharePercent: 18,
            changePercent: 17.78
        },
        {
            name: 'youtube.com',
            type: 'Social',
            faIcon: 'youtube',
            heroIcon: null,
            category: 'Arts and Entertainment',
            globalRank: 2,
            sharePercent: 18,
            changePercent: 0
        },
        {
            name: 'yahoo.com',
            type: 'Referral',
            faIcon: 'yahoo',
            heroIcon: null,
            category: 'News and Media',
            globalRank: 11,
            sharePercent: 8,
            changePercent: -9.45
        },
        {
            name: 'twitter.com',
            type: 'Social',
            faIcon: 'twitter',
            heroIcon: null,
            category: 'Social Networks',
            globalRank: 4,
            sharePercent: 4,
            changePercent: 0
        }])
}

export {
    type TeamMember,
    getTeamMembersAsync
}