import { setHours, setMinutes } from 'date-fns'

export interface Message{
    id: number;
    isStarred: boolean;
    avatar?: string|undefined;
    from: string;
    subject: string;
    body: string;
    date: string;
    bgClass?: string|undefined; //in a real-world situation the icon background color would not be random like in a demo
}

//dates would typically be returned from an api call as a full datetime string

export async function getMessages(): Promise<Message[]>{
    return Promise.resolve([
        {
            id: 1,
            isStarred: false,
            avatar: 'profile-picture-1.jpg',
            from: 'Roy Fendley',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 11), 1).toString()
        },
        {
            id: 2,
            isStarred: false,
            avatar: 'profile-picture-3.jpg',
            from: 'Bonnie Green',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 10), 23).toString()
        },
        {
            id: 3,
            isStarred: false,
            from: 'Scott Anderson',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 10), 0).toString(),
            bgClass: 'bg-secondary'
        },
        {
            id: 4,
            isStarred: false,
            avatar: 'profile-picture-4.jpg',
            from: 'Ronnie Buchanan',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 7), 45).toString()
        },
        {
            id: 5,
            isStarred: false,
            avatar: 'profile-picture-3.jpg',
            from: 'Jane Rinehart',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 7), 30).toString()
        },
        {
            id: 6,
            isStarred: false,
            from: 'John Ginther',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: setMinutes(setHours(new Date(), 6), 10).toString(),
            bgClass: 'bg-purple'
        },
        {
            id: 7,
            isStarred: false,
            avatar: 'profile-picture-6.jpg',
            from: 'George Driskell',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 14, 10:23 AM'
        },
        {
            id: 8,
            isStarred: false,
            from: 'John Benny',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 14, 10:23 AM',
            bgClass: 'bg-purple'
        },
        {
            id: 9,
            isStarred: false,
            avatar: 'profile-picture-4.jpg',
            from: 'Ronnie Buchanan',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 15, 10:23 AM'
        },
        {
            id: 10,
            isStarred: false,
            avatar: 'profile-picture-5.jpg',
            from: 'Flora Maresca',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 15, 10:23 AM'
        },
        {
            id: 11,
            isStarred: false,
            from: 'Themesberg',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 17, 10:23 AM',
            bgClass: 'bg-warning'
        },
        {
            id: 12,
            isStarred: false,
            avatar: 'profile-picture-7.jpg',
            from: 'Jane Rinehart',
            subject: 'Long time no see - Can we help you set up email forwarding?',
            body: 'We’ve noticed you haven’t set up email forwarding and we could help you',
            date: 'June 18, 10:23 AM'
        }
    ])
}