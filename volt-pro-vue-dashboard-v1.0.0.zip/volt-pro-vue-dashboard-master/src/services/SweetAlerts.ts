import Swal from 'sweetalert2'
import 'sweetalert2/src/sweetalert2.scss'

const toast = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary me-3',
        cancelButton: 'btn btn-gray'
    },
    buttonsStyling: false
});

export default toast;