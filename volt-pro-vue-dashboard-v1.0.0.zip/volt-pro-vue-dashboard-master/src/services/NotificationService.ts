import { reactive } from "vue";
import type { RouteLocationRaw } from "vue-router";
import profilePic2 from '@/assets/img/team/profile-picture-2.jpg'
import profilePic3 from '@/assets/img/team/profile-picture-3.jpg'
import profilePic4 from '@/assets/img/team/profile-picture-4.jpg'
import profilePic5 from '@/assets/img/team/profile-picture-5.jpg'


export interface NotificationItem {
    routeInfo: RouteLocationRaw;
    avatarImageSrc: string;
    user: string;
    when: string;
    description: string;
}

const notifications = reactive([] as NotificationItem[]);

//add api to listen for and get notifications
(async () => {
    notifications.push(
    // {
    //     routeInfo: {name: 'DashboardCalendar'},
    //     avatarImageSrc: require('@/assets/img/team/profile-picture-1.jpg'),
    //     user: 'Jose Leos',
    //     when: 'a few moments ago', //use momentjs for this with data from an api
    //     description: 'Added you to an event "Project stand-up" tomorrow at 12:30 AM.'    
    // },
    {
        routeInfo: {name: 'DashboardTasks'},
        avatarImageSrc: profilePic2,
        user: 'Neil Sims',
        when: '2 hrs ago',
        description: `You've been assigned a task for "Awesome new project".`
    },
    {
        routeInfo: {name: 'DashboardTasks'},
        avatarImageSrc: profilePic3,
        user: 'Roberta Casas',
        when: '5 hrs ago',
        description: 'Tagged you in a document called "First quarter financial plans'
    },
    {
        routeInfo: {name: 'DashboardMessage'},
        avatarImageSrc: profilePic4,
        user: 'Joseph Garth',
        when: '1 d ago',
        description: `New message: "Hey, what's up? All set for the presentation?"`
    },
    {
        routeInfo: {name: 'DashboardMessage'},
        avatarImageSrc: profilePic5,
        user: 'Bonnie Green',
        when: '2 d ago',
        description: 'New message: "We need to improve the UI/UX for the landing page."'
    });
})();

export { notifications }