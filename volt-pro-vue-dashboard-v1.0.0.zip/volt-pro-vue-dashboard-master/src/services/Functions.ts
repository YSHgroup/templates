export function calculateInitials(name: string): string{
    return name.split(' ').map(word => word[0]).join('');
}

export function getAvatarUrl(fileName: string){
    return new URL(`../assets/img/team/${fileName}`, import.meta.url).href;
}

export function getFlagUrl(fileName: string){
    return new URL(`../assets/img/flags/${fileName}`, import.meta.url).href;
}

export function getPageThumbnailUrl(fileName: string){
    return new URL(`../assets/img/pages/${fileName}`, import.meta.url).href;
}