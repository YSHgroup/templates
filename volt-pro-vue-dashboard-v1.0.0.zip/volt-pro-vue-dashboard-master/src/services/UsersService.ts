export {}
// export const UserStatus = new class {
//     readonly UNDEFINED = 0;
//     readonly ACTIVE = 1;
//     readonly PENDING = 2;
//     readonly SUSPENDED = 3;
// }

// export interface User{
//     id: number;
//     avatar?: string;
//     name: string;
//     email: string;
//     createdDate: string;
//     status: number;
//     bgClass?: string; //would not be needed in real-world scenerio
// }


// export async function getUsers(): Promise<User[]>{
//     return Promise.resolve([
//         {
//             id: 1,
//             avatar: 'profile-picture-1.jpg',
//             name: 'Roy Fendley',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 1
//         },
//         {
//             id: 2,
//             name: 'Scott Anderson',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 1,
//             bgClass: 'bg-secondary'
//         },
//         {
//             id: 3,
//             avatar: 'profile-picture-2.jpg',
//             name: 'George Driskell',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 1
//         },
//         {
//             id: 4,
//             avatar: 'profile-picture-3.jpg',
//             name: 'Bonnie Green',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 1
//         },
//         {
//             id: 5,
//             avatar: 'profile-picture-7.jpg',
//             name: 'Ronnie Buchanan',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 2
//         },
//         {
//             id: 6,
//             name: 'Jane Rinehart',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 2,
//             bgClass: 'bg-secondary'
//         },
//         {
//             id: 7,
//             avatar: 'profile-picture-4.jpg',
//             name: 'William Ginther',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 2
//         },
//         {
//             id: 8,
//             avatar: 'profile-picture-5.jpg',
//             name: 'Margaret Dow',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 3
//         },
//         {
//             id: 9,
//             name: 'Michael Hopkins',
//             email: 'info@example.com',
//             createdDate: '2020-02-10',
//             status: 3,
//             bgClass: 'bg-purple text-white'
//         }
//     ])
// }