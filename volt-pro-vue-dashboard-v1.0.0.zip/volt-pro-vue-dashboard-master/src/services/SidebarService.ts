//converted to pinia sidebar store in /src/stores/sidebar.ts
// import { reactive } from 'vue'

// interface SidebarMgr {
//     isCollapsed: boolean;
// }

// const sidebarMgr= reactive<SidebarMgr> ({
//     isCollapsed: false
// });

// export default sidebarMgr;
export {}