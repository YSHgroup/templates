import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import './scss/volt.scss'
import {Tooltip} from 'bootstrap';
import { library } from '@fortawesome/fontawesome-svg-core'
import { faChevronRight, faChevronDown } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import { faGoogle, faYoutube, faYahoo, faTwitter } from '@fortawesome/free-brands-svg-icons'
import VueApexCharts from "vue3-apexcharts";
import 'simplebar'

import 'leaflet/dist/leaflet.css';
import 'prismjs/themes/prism.css';

library.add(
    faChevronDown,
    faChevronRight,
    faGoogle,
    faYoutube,
    faYahoo,
    faTwitter
)

createApp(App)
  .component('font-awesome-icon', FontAwesomeIcon)
  .use(createPinia())
  .use(router)
  .use(VueApexCharts)
  .mount('#app')

new Tooltip(document.body, {
    selector: '[data-bs-toggle="tooltip"]'
  });
