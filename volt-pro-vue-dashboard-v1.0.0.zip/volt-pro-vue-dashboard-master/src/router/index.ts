import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router'
import Home from '../views/Home.vue'
import Dashboard from '../views/Dashboard.vue'
import VoltPlaceholder from '@/components/Shared/VoltPlaceholder.vue'
import DashboardOverview from '@/views/Dashboard/DashboardOverview.vue'
import TrafficSources from '@/views/Dashboard/TrafficSources.vue'
import ProductAnalysis from '@/views/Dashboard/ProductAnalysis.vue'
import Messages from '@/views/Dashboard/Messages.vue'
import Message from '@/views/Dashboard/MessageSingle.vue'
import Users from '@/views/Dashboard/Users.vue'
import StaticTransactions from '@/views/Dashboard/StaticTransactions.vue'
import StaticTaskList from '@/views/Dashboard/StaticTaskList.vue'
import StaticSettings from '@/views/Dashboard/StaticSettings.vue'
import Calendar from '@/views/Dashboard/Calendar.vue'
import MapPage from '@/views/Dashboard/MapPage.vue'
import DataTables from '@/views/Dashboard/Tables/DataTables.vue'
import BootstrapTables from '@/views/Dashboard/Tables/BootstrapTables.vue'
import Pricing from '@/views/Dashboard/PageExamples/Pricing.vue'
import StaticBilling from '@/views/Dashboard/PageExamples/StaticBilling.vue'
import StaticInvoice from '@/views/Dashboard/PageExamples/StaticInvoice.vue'
import StaticSignIn from '@/views/Examples/StaticSignIn.vue'
import StaticSignUp from '@/views/Examples/StaticSignUp.vue'
import StaticForgotPassword from '@/views/Examples/StaticForgotPassword.vue'
import StaticResetPassword from '@/views/Examples/StaticResetPassword.vue'
import StaticLock from '@/views/Examples/StaticLock.vue'
import Static404 from '@/views/Examples/Static404.vue'
import Static500 from '@/views/Examples/Static500.vue'
import Buttons from '@/views/Dashboard/Components/Buttons.vue'
import Notifications from '@/views/Dashboard/Components/Notifications.vue'
import Forms from '@/views/Dashboard/Components/Forms.vue'
import Modals from '@/views/Dashboard/Components/Modals.vue'
import Widgets from '@/views/Dashboard/Widgets.vue'
import ComponentOverview from '@/views/Dashboard/Components/Overview.vue'
import Accordion from '@/views/Dashboard/Components/Accordion.vue'
import VueModal from '@/views/Dashboard/VueComponents/VueModal.vue'
import VueOffcanvas from '@/views/Dashboard/VueComponents/VueOffcanvas.vue'
import VueToast from '@/views/Dashboard/VueComponents/VueToast.vue'
import Overview from '@/views/Dashboard/GettingStarted/Overview.vue'
import QuickStart from '@/views/Dashboard/GettingStarted/QuickStart.vue'
import License from '@/views/Dashboard/GettingStarted/License.vue'
import FolderStructure from '@/views/Dashboard/GettingStarted/FolderStructure.vue'
import Changelog from '@/views/Dashboard/GettingStarted/Changelog.vue'
import Resources from '@/views/Dashboard/GettingStarted/Resources.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: Dashboard,
    children: [
      {
        path: '',
        name: 'DashboardOverview',
        component: DashboardOverview
      },
      {
        path: 'transactions',
        name: 'DashboardTransactions',
        component: StaticTransactions
      },
      {
        path: 'settings',
        name: 'DashboardSettings',
        component: StaticSettings
      },
      {
        path: 'tables/datatables',
        name: 'DashboardDatatables',
        component: DataTables
      },
      {
        path: 'tables/bootstrap-tables',
        name: 'DashboardBootstrapTables',
        component: BootstrapTables
      },
      {
        path: 'examples/pricing',
        name: 'DashboardPricing',
        component: Pricing
      },
      {
        path: 'examples/billing',
        name: 'DashboardBilling',
        component: StaticBilling
      },
      {
        path: 'examples/invoice',
        name: 'DashboardInvoice',
        component: StaticInvoice
      },
      {
        path: 'kanban',
        name: 'DashboardKanban',
        component: VoltPlaceholder
      },
      {
        path: 'map',
        name: 'DashboardMap',
        component: MapPage
      },
      {
        path: 'calendar',
        name: 'DashboardCalendar',
        component: Calendar
      },
      {
        path: 'traffic-sources',
        name: 'DashboardTrafficSources',
        component: TrafficSources
      },
      {
        path: 'app-analysis',
        name: 'DashboardAppAnalysis',
        component: ProductAnalysis
      },
      {
        path: 'users',
        name: 'DashboardUsersList',
        component: Users
      },
      {
        path: 'tasks',
        name: 'DashboardTasks',
        component: StaticTaskList
      },
      {
        path: 'messages',
        name: 'DashboardMessages',
        component: Messages
      },
      {
        path: 'message',
        name: 'DashboardMessage',
        component: Message
      },
      {
        path: 'chat',
        name: 'DashboardChat',
        component: VoltPlaceholder
      },
      {
        path: 'components/overview',
        name: 'ComponentsOverview',
        component: ComponentOverview
      },
      {
        path: 'components/accordion',
        name: 'ComponentsAccordion',
        component: Accordion
      },
      {
        path: 'components/buttons',
        name: 'DashboardButtons',
        component: Buttons
      },
      {
        path: 'components/notifications',
        name: 'DashboardNotifications',
        component: Notifications
      },
      {
        path: 'components/forms',
        name: 'DashboardForms',
        component: Forms
      },
      {
        path: 'components/modals',
        name: 'DashboardModals',
        component: Modals
      },
      {
        path: 'vue-components/modal',
        name: 'DashboardVueModal',
        component: VueModal
      },
      {
        path: 'vue-components/offcanvas',
        name: 'DashboardVueOffcanvas',
        component: VueOffcanvas
      },
      {
        path: 'vue-components/toast',
        name: 'DashboardVueToast',
        component: VueToast
      },
      {
        path: 'getting-started/overview',
        name: 'DashboardGettingStartedOverview',
        component: Overview
      },
      {
        path: 'getting-started/quick-start',
        name: 'DashboardGettingStartedQuickStart',
        component: QuickStart
      },
      {
        path: 'getting-started/license',
        name: 'DashboardGettingStartedLicense',
        component: License
      },
      {
        path: 'getting-started/folder-structure',
        name: 'DashboardGettingStartedFolderStructure',
        component: FolderStructure
      },
      {
        path: 'getting-started/changelog',
        name: 'DashboardGettingStartedChangelog',
        component: Changelog
      },
      {
        path: 'getting-started/resources',
        name: 'DashboardGettingStartedResources',
        component: Resources
      },
      {
        path: 'widgets',
        name: 'DashboardWidgets',
        component: Widgets
      }
    ]
  },
  {
    path: '/examples/signin',
    name: 'SignIn',
    component: StaticSignIn
  },
  {
    path: '/examples/signup',
    name: 'SignUp',
    component: StaticSignUp
  },
  {
    path: '/examples/forgot-password',
    name: 'ForgotPassword',
    component: StaticForgotPassword
  },
  {
    path: '/examples/reset-password',
    name: 'ResetPassword',
    component: StaticResetPassword
  },
  {
    path: '/examples/lock',
    name: 'Lock',
    component: StaticLock
  },
  {
    path: '/examples/404',
    name: '404',
    component: Static404
  },
  {
    path: '/500',
    name: '500',
    component: Static500
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  
  scrollBehavior(to, from, savedPosition){
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  },
  routes
})

export default router
