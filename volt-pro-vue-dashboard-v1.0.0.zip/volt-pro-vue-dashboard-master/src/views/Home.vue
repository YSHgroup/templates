<template>
  <HomeNavigation :classes="['navbar-dark']" />
  <main>
     <!-- Hero -->
        <section class="section-header overflow-hidden pt-7 pt-lg-8 pb-9 pb-lg-12 bg-primary text-white">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="bootstrap-big-icon d-none d-lg-block">
                            <svg viewBox="0 0 118 94" width="700" height="622" class="d-block my-1"><title>Vue3</title><path fill="#42b883" d="M78.8,10L64,35.4L49.2,10H0l64,110l64-110C128,10,78.8,10,78.8,10z" data-v-5f26462c=""></path><path fill="#35495e" d="M78.8,10L64,35.4L49.2,10H25.6L64,76l38.4-66H78.8z" data-v-5f26462c=""></path></svg>
                            <!-- <svg xmlns="http://www.w3.org/2000/svg" width="700" height="622" class="d-block my-1" viewBox="0 0 118 94" role="img"><title>Bootstrap</title><path fill-rule="evenodd" clip-rule="evenodd" d="M24.509 0c-6.733 0-11.715 5.893-11.492 12.284.214 6.14-.064 14.092-2.066 20.577C8.943 39.365 5.547 43.485 0 44.014v5.972c5.547.529 8.943 4.649 10.951 11.153 2.002 6.485 2.28 14.437 2.066 20.577C12.794 88.106 17.776 94 24.51 94H93.5c6.733 0 11.714-5.893 11.491-12.284-.214-6.14.064-14.092 2.066-20.577 2.009-6.504 5.396-10.624 10.943-11.153v-5.972c-5.547-.529-8.934-4.649-10.943-11.153-2.002-6.484-2.28-14.437-2.066-20.577C105.214 5.894 100.233 0 93.5 0H24.508zM80 57.863C80 66.663 73.436 72 62.543 72H44a2 2 0 01-2-2V24a2 2 0 012-2h18.437c9.083 0 15.044 4.92 15.044 12.474 0 5.302-4.01 10.049-9.119 10.88v.277C75.317 46.394 80 51.21 80 57.863zM60.521 28.34H49.948v14.934h8.905c6.884 0 10.68-2.772 10.68-7.727 0-4.643-3.264-7.207-9.012-7.207zM49.948 49.2v16.458H60.91c7.167 0 10.964-2.876 10.964-8.281 0-5.406-3.903-8.178-11.425-8.178H49.948z" fill="currentColor"></path></svg> -->
                        </div>
                        <h1 class="fw-bolder">Volt Pro Vue Dashboard<span class="pixel-pro-badge fw-bolder text-gray-800">PRO</span></h1>
                        <h2 class="lead fw-normal text-muted mb-5">A Vue 3, Vite, Bootstrap Premium Admin Dashboard</h2>
                        <!-- Button Modal -->
                        <div class="d-flex justify-content-center mb-5">
                            <router-link :to="{name: 'DashboardOverview'}" class="btn btn-secondary d-inline-flex align-items-center me-4">
                                <font-awesome-icon :icon="faChartLine" class="me-1" /> Dashboard Demo
                            </router-link>                           
                            <a href="https://themesberg.com/product/dashboard/volt-pro-vue#pricing" class="btn btn-outline-gray-100">Purchase now</a>
                        </div>
                        <div class="d-flex justify-content-center flex-column mb-6 mb-lg-5">
                            <a href="https://themesberg.com" target="_blank">
                                <img src="@/assets/img/themesberg.svg" class="d-block mx-auto mb-3" height="25" width="25" alt="Themesberg Logo">
                                <span class="text-muted font-small">A Themesberg production</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <figure class="position-absolute bottom-0 left-0 w-100 d-none d-md-block mb-n2"><svg class="home-pattern" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3000 185.4"><path d="M3000,0v185.4H0V0c496.4,115.6,996.4,173.4,1500,173.4S2503.6,115.6,3000,0z"></path></svg></figure>
        </section>
         <div class="section pt-0">
            <div class="container mt-n10 mt-lg-n12 z-2">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <img src="@/assets/img/mockup-presentation.png" alt="Mockup presentation">
                    </div>
                </div>
            </div>
        </div>
        <section class="section section-lg bg-soft pt-0">
             <div class="container">
                <div class="row justify-content-center mb-5 mb-lg-6">
                    <VoltMiniFeaturette v-for="(miniFeaturette,i) in miniFeaturettes" :key="i" v-bind="miniFeaturette" />
                </div>
                <HomeFeaturedElements/>
             </div>
        </section>
        <HomeExamplePagesSection />
        <HomeFeaturettesSection />
        <HomeFolderStructureSection />
        <section class="section section-lg bg-gray-800">
            <div class="container">
                <div class="row justify-content-center text-center text-white mb-5">
                    <div class="col-12">
                        <h2 class="h1 fw-light mb-3">Less <span class="fw-bold">work</span>, more <span class="fw-bold">flow</span>.</h2>
                        <p class="lead px-lg-8">
                            Boost productivity with BrowserSync. Sass changes are reflected instantly and pages scroll and refresh on devices as you work.
                        </p>
                    </div>
                </div>
                <div class="row justify-content-center mb-6">
                    <div class="col-md-10 col-xl-9">
                        <div class="position-relative">
                            <div class="rounded bg-white p-4 text-dark mb-2">
                                <div class="mb-3">
                                    <div class="fw-bold">&gt; $ npm install</div>
                                    <div class="text-gray">Everything’s installed!</div>
                                </div>
                                <div class="mb-3">
                                    <div class="fw-bold">&gt; $ gulp</div>
                                    <div class="text-gray">SCSS watching</div>
                                    <div class="text-gray">LiveReload started</div>
                                    <div class="text-gray">Opening localhost:3000</div>
                                </div>
                                <div>
                                    <div class="fw-bold">&gt; $ that's it?</div>
                                    <div class="text-gray">It's that simple!</div>
                                </div>
                            </div>
                        </div>
                        <p class="mt-4 text-white text-center">Looks unfamiliar? Don’t worry! Our <a class="text-white text-decoration-underline fw-bolder" href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/getting-started/quick-start/" target="_blank">documentation</a> has got you covered.</p>
                    </div>
                </div>
            </div>
        </section>
        <HomeFreeDemoSection/>
        <HomePlanMatrixSection/>
        <HomeQuestionsSection/>
  </main>
  <HomeFooter/>

</template>

<script lang="ts" setup>
import { ref } from 'vue';
import HomeNavigation from '@/components/HomeNavigation.vue';
import HomeExamplePagesSection from '@/components/HomeExamplePagesSection.vue';
import HomeFeaturedElements from '@/components/HomeFeaturedElements.vue';
import VoltMiniFeaturette from '@/components/Shared/VoltMiniFeaturette.vue';
import type VoltMiniFeaturetteProps from '@/components/Shared/VoltMiniFeaturetteProps'

import HomeFeaturettesSection from '@/components/HomeFeaturettesSection.vue';
import HomeFolderStructureSection from '@/components/HomeFolderStructureSection.vue';
import HomeFreeDemoSection from '@/components/HomeFreeDemoSection.vue';
import HomePlanMatrixSection from '@/components/HomePlanMatrixSection.vue';
import HomeQuestionsSection from '@/components/HomeQuestionsSection.vue';
import HomeFooter from '@/components/HomeFooter.vue';

import { BookOpenIcon, PuzzleIcon, LightBulbIcon } from 'heroicons-vue3/solid'
import { ExternalLinkIcon } from 'heroicons-vue3/outline';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import {faChartLine} from '@fortawesome/free-solid-svg-icons'
import { faJsSquare} from '@fortawesome/free-brands-svg-icons'
import { h } from 'vue'

//import {Tooltip} from 'bootstrap'


const miniFeaturettes = ref<VoltMiniFeaturetteProps[]>([]);
const  docsVersion = import.meta.env.VITE_APP_DOCS_VERSION;
      
 function  initMiniFeaturettes(){
     miniFeaturettes.value.push(
        {
          sizeClasses: 'col-6 col-md-4',
          icon: h(BookOpenIcon),
          heading: '21',
          subHeading: 'Dashboard Pages'
        },
        {
          sizeClasses: 'col-6 col-md-4',
          icon: h(PuzzleIcon),
          heading: '800+',
          subHeading: 'Premium Components'
        },
        {
            sizeClasses: 'col-6 col-md-4',
            icon: h('svg', {height:"26", viewBox:"0 0 27 26", width:"27", xmlns:"http://www.w3.org/2000/svg"}, [
                h('path', {'clip-rule': "evenodd", d:"m.98608 0h24.32332c.5446 0 .9861.436522.9861.975v24.05c0 .5385-.4415.975-.9861.975h-24.32332c-.544597 0-.98608-.4365-.98608-.975v-24.05c0-.538478.441483-.975.98608-.975zm13.63142 13.8324v-2.1324h-9.35841v2.1324h3.34111v9.4946h2.6598v-9.4946zm1.0604 9.2439c.4289.2162.9362.3784 1.5218.4865.5857.1081 1.2029.1622 1.8518.1622.6324 0 1.2331-.0595 1.8023-.1784.5691-.1189 1.0681-.3149 1.497-.5879s.7685-.6297 1.0187-1.0703.3753-.9852.3753-1.6339c0-.4703-.0715-.8824-.2145-1.2365-.1429-.3541-.3491-.669-.6186-.9447-.2694-.2757-.5925-.523-.9692-.7419s-.8014-.4257-1.2743-.6203c-.3465-.1406-.6572-.2771-.9321-.4095-.275-.1324-.5087-.2676-.7011-.4054-.1925-.1379-.3409-.2838-.4454-.4379-.1045-.154-.1567-.3284-.1567-.523 0-.1784.0467-.3392.1402-.4824.0935-.1433.2254-.2663.3959-.369s.3794-.1824.6269-.2392c.2474-.0567.5224-.0851.8248-.0851.22 0 .4523.0162.697.0486.2447.0325.4908.0825.7382.15.2475.0676.4881.1527.7218.2555.2337.1027.4495.2216.6475.3567v-2.4244c-.4015-.1514-.84-.2636-1.3157-.3365-.4756-.073-1.0214-.1095-1.6373-.1095-.6268 0-1.2207.0662-1.7816.1987-.5609.1324-1.0544.3392-1.4806.6203s-.763.6392-1.0104 1.0743c-.2475.4352-.3712.9555-.3712 1.5609 0 .7731.2268 1.4326.6805 1.9785.4537.546 1.1424 1.0082 2.0662 1.3866.363.146.7011.2892 1.0146.4298.3134.1405.5842.2865.8124.4378.2282.1514.4083.3162.5403.4946s.198.3811.198.6082c0 .1676-.0413.323-.1238.4662-.0825.1433-.2076.2676-.3753.373s-.3766.1879-.6268.2473c-.2502.0595-.5431.0892-.8785.0892-.5719 0-1.1383-.0986-1.6992-.2959-.5608-.1973-1.0805-.4933-1.5589-.8879z",
                'fill-rule':"evenodd"})]),
            heading: 'TypeScript',
            subHeading: 'Safety'
        },
        {
            sizeClasses: 'col-6 col-md-4',
            icon: h('svg', {class: "logo", viewBox:"0 0 128 128", width:"24", height:"24"}, [
                h('path', {fill:"#42b883", d:"M78.8,10L64,35.4L49.2,10H0l64,110l64-110C128,10,78.8,10,78.8,10z"}),
                h('path', {fill:"#35495e", d:"M78.8,10L64,35.4L49.2,10H25.6L64,76l38.4-66H78.8z"})]),
            heading: 'Vue 3',
            subHeading: 'Powered'
        },
        
        {
            sizeClasses: 'col-6 col-md-4',
            icon: h('img', {src: 'https://vitejs.dev/logo.svg'}),
            heading: 'Vite',
            subHeading: 'Fast'
        },
        {
            sizeClasses: 'col-6 col-md-4',
            icon: h('img', {src: 'https://pinia.vuejs.org/logo.svg'}),
            heading: 'Pinia',
            subHeading: 'State'
        }
      )
 }
      
initMiniFeaturettes();
</script>
