<template>
    <div class="row my-4">
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow text-center py-4 mb-4 mb-lg-0">
                <div class="card-body">
                    <h2 class="display-3 mb-3">Volt<span class="pixel-pro-badge subscription-badge bg-secondary fw-bolder">PRO</span></h2>
                    <p>Switch your subscription to a different type, such as a monthly plan, annual plan, or student plan. And see a list of subscription plans that Volt offers</p>
                    <p class="text-dark my-4">Next payment of <span class="fw-bold">$36 (yearly)</span> occurs on August 13, 2020.</p>
                    <a class="btn btn-sm btn-outline-gray-800 me-2" href="#">Cancel subscription</a>
                    <a class="btn btn-sm btn-secondary" href="./pricing.html">Change plan</a>
                </div>
                </div>
        </div>
        <div class="col-12 col-lg-6">
            <div class="card border-0 card-body shadow p-0 p-md-4">
                <div class="card-header border-bottom p-3">
                    <h3 class="h5">Order History</h3>
                    <p class="mb-0">Manage billing information and view receipts</p>
                </div>
                <div class="card-body px-0 py-0">
                    <ul class="list-group">
                        <li class="list-group-item border-bottom py-3">
                            <div class="row align-items-center">
                                <div class="col">                       
                                    <h3 class="h6 mb-1">
                                        <a href="./invoice.html">Invoice #120345</a>
                                    </h3>
                                    <!-- Text -->
                                    <small class="text-gray-700">
                                        Billed August 21, 2019
                                    </small>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn-sm btn-gray-800">
                                        Pay now
                                    </button>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item py-3">
                            <div class="row align-items-center">
                                <div class="col">                       
                                    <h3 class="h6 mb-1">
                                        <a href="./invoice.html">Invoice #120344</a>
                                    </h3>
                                    <!-- Text -->
                                    <small class="text-gray-700">
                                        Billed July 21, 2019
                                    </small>
                                </div>
                                <div class="col-auto">
                                    <span class="badge rounded px-3 py-2 bg-success">
                                        <span class="text-uppercase fw-bolder">Paid</span>
                                    </span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <form action="#" method="post" class="card border-0 shadow p-3 pb-4 mb-4">
        <div class="card-header mx-lg-4 p-0 py-3 py-lg-4 mb-4 mb-md-0">
            <h3 class="h5 mb-0">Billing details</h3> 
        </div>
        <div class="card-body p-0 p-md-4">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputEmail1">Email address *</label>
                        <input type="email" class="form-control" placeholder="example@company.com" id="cartInputEmail1" aria-describedby="cartInputEmail1" required>
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!--Form-->
                    <label for="country">Country</label>
                    <select class="form-select mb-4" id="country" aria-label="Country select example">
                        <option selected>Choose...</option>
                        <option value="1">United States</option>
                        <option value="2">Germany</option>
                        <option value="3">Canada</option>
                    </select>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputAddress1">Address</label>
                        <input type="text" placeholder="Texas" class="form-control" id="cartInputAddress1" aria-describedby="cartInputAddress1">
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputCity1">City</label>
                        <input type="text" placeholder="Dallas" class="form-control" id="cartInputCity1" aria-describedby="cartInputCity1">
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputZip1">Zip/Postal code</label>
                        <input type="number" placeholder="123456" class="form-control" id="cartInputZip1" aria-describedby="cartInputZip1">
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputCompany1">Company Name *</label>
                        <input type="text" placeholder="Company LLC" class="form-control" id="cartInputCompany1" aria-describedby="cartInputCompany1" required>
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputVAT1">VAT ID</label>
                        <input type="number" placeholder="NL232142" class="form-control" id="cartInputVAT1" aria-describedby="cartInputVAT1">
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Form -->
                    <div class="form-group mb-4">
                        <label for="cartInputPhone1">Phone Number</label>
                        <input type="number" placeholder="+(12)345 6789" class="form-control" id="cartInputPhone1" aria-describedby="cartInputPhone1">
                    </div>
                    <!-- End of Form -->
                </div>
                <div class="col-12">
                    <button class="btn btn-gray-800 mt-2 animate-up-2" type="submit">Update</button>
                </div>
            </div>
        </div>
    </form>
    <form action="#" method="post" class="card border-0 shadow p-3 pb-4 mb-4">
        <div class="card-header mx-lg-4 p-0 py-3 py-lg-4 mb-4 mb-md-0">
            <h3 class="h5 mb-0">Card details</h3> 
        </div>
        <div class="card-body p-0 p-md-4">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label" for="cardNameLabel"><span class="small text-dark">(Full name as displayed on card)</span></label>
                        <div class="input-group mb-4">
                            <input class="form-control" id="cardNameLabel" placeholder="Name on Card *" type="text" required="true"> </div>
                    </div>
                </div>
                <div class="col-12 mb-4">
                    <label for="cardNumberLabel">Card Number <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"></path><path fill-rule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clip-rule="evenodd"></path></svg>
                        </span>
                        <input class="form-control" id="cardNumberLabel" placeholder="0000 0000 0000 0000" type="number" required="true">                                               
                        </div>
                </div>
                <div class="col-12 col-md-6 mb-4 mb-lg-0">
                    <div class="form-group">
                        <label for="cardCVCLabel">CVC <span class="text-danger">*</span></label>
                        <input class="form-control" id="cardCVCLabel" placeholder="CVC" type="number" required="true"> </div>
                </div>
                <div class="col-12 col-md-6">
                    <label for="cardExpiryLabel">Card Expiry <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <svg class="icon icon-xs text-gray-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>                                </span>
                        <input class="form-control" id="cardExpiryLabel" placeholder="MM / YY" type="number" required="true">                                               
                    </div>
                </div>
                <div class="col-12 mt-4">
                    <button class="btn btn-gray-800 mt-2 animate-up-2" type="submit">Update</button>
                </div>
            </div>
        </div>
    </form> 
</template>