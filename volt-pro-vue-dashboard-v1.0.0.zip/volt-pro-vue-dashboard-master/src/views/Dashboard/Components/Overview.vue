<template>
    <div class="py-4">
        <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
            <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                <li class="breadcrumb-item">
                    <a href="#">
                        <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#">Components</a></li>
                <li class="breadcrumb-item active" aria-current="page">Overview</li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4">Overview</h1>
                <p class="mb-0">Native Bootstrap components play nicely with Vue</p>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card border-0 shadow components-section">
                <div class="card-body">
                    <div class="vstack gap-4">
                        <div>
                            <h3 class="fs-4">Bootstrap and Vue Components</h3>
                            <p class="">As stated in Vue's documentation, Vue is a progressive framework for building user interfaces. This means that you can start with HTML and progressively add behavior to build interactive user interfaces.</p>
                            <p class="lead">This is great news for HTML templates based on Boostrap.</p>
                            <p>Most <a href="https://getbootstrap.com/docs/5.1/components/accordion/" class="link">Boostrap components</a> work as-is with Vue and you can incorporate them in your Vue components just with their markup and css classes.</p>
                            <p>Even Bootstrap components that have behavior, like accordions and modals, can be used directly in Vue templates.
                                Bootstrap Buttons, for example, are simply <code>button</code>, <code>input</code>, or <code>anchor</code> tags decorated with css classes to define their color, size, and style.
                                Vue's elegant way of wiring up built-in DOM events, like <code>click</code>, makes adding an event handler to a button as easy as adding another HTML attribute.
                                HTML event handlers can either be defined inline or simply call a component function:</p>
                        
                    
                            <div>
                                <div class="hstack gap-4 mb-3">
                                    <button type="button" class="btn btn-primary" @click="count = count + 1">Increment count</button>
                                    <span class="monospace fs-3">{{ count }}</span>
                                </div>
                                <pre class="language-markup"><code><!--
            <template>
            <div class="vstack gap-3 mb-3">
                <button type="button" class="btn btn-primary me-3" @click="count = count + 1">Increment count</button>
                <span class="monospace fs-3">{{ count }}</span>
            </div>
            </template
            <script lang="ts" setup>
                import { ref } from 'vue'

                const count = ref(0);
            </script>
                            --></code></pre>
                            </div>
                        </div>

                        <div>
                            <h3 class="fs-4">Do we need a Vue component for every Bootstrap component?</h3>
                            <p>No. There is no need to create a Vue component for every Boostrap component because you can use css classes to define styles and Vue's event handler syntax to respond to events.</p>
                            <p>If you create Vue components for basic Boostrap components, you will need to define <code>props</code> for styles and you will severely limit the possibilities that css would provide.
                            Just take one style property: size. Do you really want to either expose a <code>size</code> prop or multiple size options via props?</p>
                            <p>If you expect the user to use Bootstrap css classes, then might as well let the user create the HTML element as well. The only advantage to defining your own custom Vue components in that case would be to 
                                standardize defaults, such as <code>button</code> HTML element with default <code>class="btn btn-primary"</code>.
                            </p>
                        </div>
                        
                        <div>
                            <h3 class="fs-4">What about Bootstrap's components that depend on Javascript?</h3>
                            <p>Bootstrap has several helpful components that require Javascript, such as <code>dropdown</code>, <code>tooltip</code>, and <code>accordian</code>.</p>
                            <p>The good news is you can include Bootstrap's javascript in your HTML template without conflicting with Vue. That is what this template does.</p>
                        </div>

                        <div>
                            <h3 class="fs-4">When do you need to create Vue components to replace Bootsrap's then?</h3>
                            <p>When component interactions depend on Vue data, then it saves a lot of time to create corresponding Vue components so the underlying HTML elements can be wired up in one place.
                                Also, as mentioned, Vue components can simplify your templates by encapsulating complex HTML markup and defaults. The tradeoff with reusability is flexibility.
                                If a Vue component does not expose a prop for an attribute that you need, or if there's no overriding its defaults, then you have to resort to using Bootstrap's HTML direclty.</p>


                            <p>The PRO version of this template includes a few Vue components: <code>Modal</code>, <code>Offcanvas</code>, <code>Toast</code>.
                            These can be used as-is or provide a good starting point for you to extend to add more functionality or expose more options.</p>
                        </div>
                    </div>
                    
                </div>
        </div>

    </div>

</template>

<script lang="ts" setup>
import { ref } from 'vue';

const count = ref(0);
</script>