<template>
    <div class="py-4">
        <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
            <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                <li class="breadcrumb-item">
                    <a href="#">
                        <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#">Components</a></li>
                <li class="breadcrumb-item active" aria-current="page">Accordion</li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4">Accordion</h1>
                <p class="mb-0">Elegant way to hide and show content</p>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card border-0 shadow components-section">
            <div class="card-body">
                <h5 class="card-title">Simple Accordion</h5>
                <p class="lead">Content remains in the DOM and visibility is toggled with CSS. Uses Bootstrap's build in javascript to expand/collapse.</p>
                <div class="example">
                    <div class="fs-6 mb-3">Example from Bootstrap's docs</div>
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Accordion Item #1
                            </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Accordion Item #2
                            </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Accordion Item #3
                            </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Accordion Item #4 With A Vue Component as Content
                            </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p><strong>You can place any html here, including Vue components.</strong></p>
                                    <CustomersWidget />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card border-0 shadow components-section">
            <div class="card-body">
                <h5 class="card-title">Advanced Vue-powered Accordion</h5>
                <p class="lead">When content is hidden, it is removed from the DOM. Uses Vue's event handlers and conditionals to expand/collapse.</p>
                <p>Removing hidden content from the DOM saves browser memory and CPU. If content is data driven, then network traffic and server resources are also saved. If accordion item content is complex with a lot of elements, event listeners, or fetches data, I recommend this accordion.</p>
                <p><strong>Note: </strong> Collapse animations do not work with this accordion. For that, you need to create Accordion and AccordionItem components and listen to <a class="btn btn-sm btn-outline-primary" href="https://getbootstrap.com/docs/5.1/components/collapse/">Bootstrap's collapse events</a>.</p>
                <div class="example">
                    <div class="fs-6 mb-3">Example from Bootstrap's docs</div>
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" :class="{'collapsed': !isActive(1)}" @click="setActive(1)" type="button" :aria-expanded="isActive(1)" aria-controls="collapseOne">
                                Accordion Item #1
                            </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse" :class="{'show': isActive(1)}" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div v-if="isActive(1)" class="accordion-body">
                                    <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button" :class="{'collapsed': !isActive(2)}" @click="setActive(2)" type="button" :aria-expanded="isActive(2)" aria-controls="collapseTwo">
                                Accordion Item #2
                            </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" :class="{'show': isActive(2)}" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div v-if="isActive(2)" class="accordion-body">
                                    <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button" :class="{'collapsed': !isActive(3)}" @click="setActive(3)" type="button" :aria-expanded="isActive(3)" aria-controls="collapseThree">
                                Accordion Item #3
                            </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" :class="{'show': isActive(3)}" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div v-if="isActive(3)" class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button" :class="{'collapsed': !isActive(4)}" @click="setActive(4)" type="button" :aria-expanded="isActive(4)" aria-controls="collapseFour">
                                Accordion Item #4 With A Vue Component as Content
                            </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" :class="{'show': isActive(4)}" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                <div v-if="isActive(4)" class="accordion-body">
                                    <p><strong>You can place any html here, including Vue components.</strong></p>
                                    <CustomersWidget />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



</template>

<script lang="ts" setup>
import CustomersWidget from '@/components/Widgets/CustomersWidget.vue'
import { ref } from 'vue';
const activeItem = ref(1);

function isActive(index: number){
    return activeItem.value == index;
}

function setActive(index: number){
    activeItem.value = index;
}
</script>