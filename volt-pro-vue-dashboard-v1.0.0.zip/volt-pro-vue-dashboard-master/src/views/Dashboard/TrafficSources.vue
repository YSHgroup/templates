<template>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
        <div class="dropdown">
            <button class="btn btn-gray-800 d-inline-flex align-items-center me-2 dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Categories
                <ChevronDownIcon class="icon icon-xs ms-2" />
            </button>
            <div class="dropdown-menu dashboard-dropdown dropdown-menu-start mt-2 py-1">
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <CubeIcon class="dropdown-icon text-gray-400 me-2" />
                    My App
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <CollectionIcon class="dropdown-icon text-gray-400 me-2" />
                    My Website
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <GlobeIcon class="dropdown-icon text-gray-400 me-2" />
                    Worldwide Traffic
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <PresentationChartLineIcon class="dropdown-icon text-gray-400 me-2" />
                    Niche Traffic
                </a>
            </div>
        </div>
        <div class="btn-group">
            <button type="button" class="btn btn-sm btn-outline-gray-600">Share</button>
            <button type="button" class="btn btn-sm btn-outline-gray-600">Export</button>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-xl-6 col-xxl-4 mb-4">
            <TrafficSourcesTrafficShare />
        </div>
        <div class="col-12 col-xl-6 col-xxl-8 mb-4">
            <TrafficSourcesTrafficVolumes />
        </div>
    </div>
    <div class="row">
        <div class="col-12 mb-4">
            <TrafficSourcesTable />
        </div>
    </div>
    
</template>

<script lang="ts" setup>
import { ChevronDownIcon, CubeIcon, CollectionIcon, GlobeIcon, PresentationChartLineIcon } from 'heroicons-vue3/solid'
import TrafficSourcesTable from '@/components/Dashboard/TrafficSourcesTable.vue'
import TrafficSourcesTrafficShare from '@/components/Dashboard/TrafficSourcesTrafficShare.vue'
import TrafficSourcesTrafficVolumes from '@/components/Dashboard/TrafficSourcesTrafficVolumes.vue'

</script>
