<template>
<div class="py-4">
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
        <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
            <li class="breadcrumb-item">
                <a href="#">
                    <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                </a>
            </li>
            <li class="breadcrumb-item"><a href="#">Volt</a></li>
            <li class="breadcrumb-item"><a href="#">Vue Components</a></li>
            <li class="breadcrumb-item active" aria-current="page">Vue Modal</li>
        </ol>
    </nav>
    <div class="d-flex justify-content-between w-100 flex-wrap">
        <div class="mb-3 mb-lg-0">
            <h1 class="h4">Vue Modal</h1>
            <p class="lead">A custom Vue modal component based on Bootstrap perfect for both simple and complex secondary content.</p>
            <p class="lead mb-0">Exclusive to Themesberg.</p>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Features</h5>
                <ul>
                    <li>Reproduces Bootstrap modal markup exactly</li>
                    <li>Nested component model so classes can easily be added to dialog, header, body, and footer</li>
                    <li>Multiple ways to toggle showing and hiding</li>
                    <li>Works with <code>v-model</code></li>
                    <li>Option to remove content from DOM when hidden</li>
                    <li>Supports built-in bootstrap animations</li>
                    <li>Emits events when shown and hidden</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Example</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-primary" @click="showExample1 = true">Show modal</button>
                    <TVModal v-model="showExample1" :fade="true">
                        <TVModalHeader title="Simple Modal" />
                        <TVModalBody>
                            <p>This is a simple modal.</p>
                        </TVModalBody>
                        <TVModalFooter />
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-primary" @click="showExample1 = true">Show modal&lt;/button>
    &lt;TVModal v-model="showExample1" :fade="true">
        &lt;TVModalHeader title="Simple Modal" />
        &lt;TVModalBody>
            &lt;p>This is a simple modal.&lt;/p>
        &lt;/TVModalBody>
        &lt;TVModalFooter />
    &lt;/TVModal>
    &lt;/template>
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'

        const showExample1 = ref(false);
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Example using ref</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-primary" @click="refExample?.toggle()">Toggle modal</button>
                    <TVModal ref="refExample" :fade="true">
                        <TVModalHeader title="Toggle with ref" />
                        <TVModalBody>
                            <p>This modal is toggled with <code>.toggle()</code> on the ref.</p>
                        </TVModalBody>
                        <TVModalFooter />
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-primary" @click="refExample?.toggle()">Toggle modal&lt;/button>
    &lt;TVModal ref="refExample" :fade="true">
        &lt;TVModalHeader title="Toggle with ref" />
        &lt;TVModalBody>
            &lt;p>This modal is toggled with &lt;code>.toggle()&lt;/code> on the ref.&lt;/p>
        &lt;/TVModalBody>
        &lt;TVModalFooter />
    &lt;/TVModal>
    &lt;/template>
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'
        import { TVModalI } from '@/components/Shared/TVTypes'

        const refExample = ref&lt;TVModalI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Modal with custom footer</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-secondary" @click="customFooterExampleShow">Show</button>
                    <TVModal v-model="customFooterExample" :fade="true">
                        <TVModalHeader title="Check out this custom footer" />
                        <TVModalBody>
                            <p>The content of this modal is worth copying.</p>
                        </TVModalBody>
                        <TVModalFooter>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                            <button type="button" class="btn btn-secondary" @click="customFooterExample = false">Cancel2</button>
                            <button type="button" v-if="!isCustomFooterSubmitted" class="btn btn-primary" @click="customFooterExampleSubmit" >Submit</button>
                            <span v-else class="text-success">Submitted!</span>
                        </TVModalFooter>
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-secondary" @click="customFooterExampleShow">Show&lt;/button>
    &lt;TVModal v-model="customFooterExample" :fade="true">
        &lt;TVModalHeader title="Check out this custom footer" />
        &lt;TVModalBody>
            &lt;p>The content of this modal is worth copying.&lt;/p>
        &lt;/TVModalBody>
        &lt;TVModalFooter>
            &lt;button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">Cancel&lt;/button>
            &lt;button type="button" class="btn btn-secondary" @click="customFooterExample = false">Cancel2&lt;/button>
            &lt;button type="button" v-if="!isCustomFooterSubmitted" class="btn btn-primary" @click="customFooterExampleSubmit" >Submit&lt;/button>
            &lt;span v-else class="text-success">Submitted!&lt;/span>
        &lt;/TVModalFooter>
    &lt;/TVModal>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'
        import { TVModalI } from '@/components/Shared/TVTypes'

        const customFooterExample = ref(false);
        const isCustomFooterSubmitted = ref(false);

        function customFooterExampleShow(){
            customFooterExample.value = true;
            isCustomFooterSubmitted.value = false;
        }

        function customFooterExampleSubmit(){
            isCustomFooterSubmitted.value = true;
        }
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Modal with content removed from DOM</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-tertiary" @click="noDOMExample?.toggle()">Toggle modal</button>
                    <TVModal ref="noDOMExample" :fade="true" :remove-from-dom-when-hidden="true">
                        <TVModalHeader title="Content in and out of DOM" />
                        <TVModalBody>
                            <p class="lead">Inspect this modal when the modal is hidden. All elements inside <code>modal-dialog</code> will be removed.</p>
                            <p>This is extremely useful for modals with lots of components that could consume CPU and memory.</p> 
                            <p><b>Example: </b>A table of contents with thousands of elements.</p>
                        </TVModalBody>
                        <TVModalFooter />
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-tertiary" @click="noDOMExample?.toggle()">Toggle modal&lt;/button>
    &lt;TVModal ref="noDOMExample" :fade="true" :remove-from-dom-when-hidden="true">
        &lt;TVModalHeader title="Content in and out of DOM" />
        &lt;TVModalBody>
            &lt;p class="lead">Inspect this modal when the modal is hidden. All elements inside &lt;code>modal-dialog&lt;/code> will be removed.&lt;/p>
            &lt;p>This is extremely useful for modals with lots of components that could consume CPU and memory.&lt;/p> 
            &lt;p>&lt;b>Example: &lt;/b>A table of contents with thousands of elements.&lt;/p>
        &lt;/TVModalBody>
        &lt;TVModalFooter />
    &lt;/TVModal>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'
        import { TVModalI } from '@/components/Shared/TVTypes'

        const noDOMExample = ref&lt;TVModalI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Modal with custom Bootstrap options</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-tertiary" @click="customBootstrapExample?.toggle()">Toggle modal</button>
                    <TVModal ref="customBootstrapExample" :fade="true" :centered="true" dialog-classes="modal-xl">
                        <TVModalHeader title="Extra Large Modal Vertically Centered" />
                        <TVModalBody>
                            <p class="lead">Use <code>dialog-classes</code> to add classnames to the <code>modal-dialog</code>, such as <code>modal-xl</code>..</p>
                            <p class="lead">Since the modal header, body, and footer are individual Vue components, any attributes you add to them will be added to <code>modal-header</code>, <code>modal-body</code>, and <code>modal-footer</code>, respectively.</p>
                        </TVModalBody>
                        <TVModalFooter />
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-tertiary" @click="customBootstrapExample?.toggle()">Toggle modal&lt;/button>
    &lt;TVModal ref="customBootstrapExample" :fade="true" :centered="true" dialog-classes="modal-xl">
        &lt;TVModalHeader title="Extra Large Modal Vertically Centered" />
        &lt;TVModalBody>
            &lt;p class="lead">Use &lt;code>dialog-classes&lt;/code> to add classnames to the &lt;code>modal-dialog&lt;/code>, such as &lt;code>modal-xl&lt;/code>.&lt;/p>
            &lt;p class="lead">Since the modal header, body, and footer are individual Vue components, any attributes you add to them will be added to &lt;code>modal-header&lt;/code>, &lt;code>modal-body&lt;/code>, and &lt;code>modal-footer&lt;/code>, respectively.&lt;/p>
        &lt;/TVModalBody>
        &lt;TVModalFooter />
    &lt;/TVModal>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'
        import { TVModalI } from '@/components/Shared/TVTypes'

        const customBootstrapExample = ref&lt;TVModalI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Simple Modal with just a <code>modal-body</code></h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-gray-500" @click="simpleBodyModalExample?.toggle()">Toggle modal</button>
                    <TVModal ref="simpleBodyModalExample" :centered="true">
                        <TVModalBody>
                            <p class="lead">You always need some body.</p>
                            <button type="button" class="btn btn-gray-300" data-bs-dismiss="modal">Close</button>
                        </TVModalBody>
                    </TVModal>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-gray-500" @click="simpleBodyModalExample?.toggle()">Toggle modal&lt;/button>
    &lt;TVModal ref="simpleBodyModalExample" :centered="true">
        &lt;TVModalBody>
            &lt;p class="lead">You always need some body.&lt;/p>
            &lt;button type="button" class="btn btn-gray-300" data-bs-dismiss="modal">Close&lt;/button>
        &lt;/TVModalBody>
    &lt;/TVModal>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVModal from '@/components/Shared/TVModal.vue'
        import TVModalBody from '@/components/Shared/TVModalBody.vue'
        import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
        import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
        import { ref } from 'vue'
        import { TVModalI } from '@/components/Shared/TVTypes'

        const simpleBodyModalExample = ref&lt;TVModalI>();
    &lt;/script>
                    </code></pre>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Options</h5>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Prop</th>
                            <th>Type</th>
                            <th>Default</th>
                            <th>Required</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>fade</code></td>
                            <td>Boolean</td>
                            <td>false</td>
                            <td></td>
                            <td>whether to use the fade animation</td>
                        </tr>
                        <tr>
                            <td><code>backdrop</code></td>
                            <td>Boolean</td>
                            <td>true</td>
                            <td></td>
                            <td>whether to show clickable backdrop</td>
                        </tr>
                        <tr>
                            <td><code>centered</code></td>
                            <td>Boolean</td>
                            <td>false</td>
                            <td></td>
                            <td>whether to center vertically</td>
                        </tr>
                        <tr>
                            <td><code>dialogClasses</code></td>
                            <td>String</td>
                            <td>''</td>
                            <td></td>
                            <td>space-delimited class names to add to <code>modal-dialog</code></td>
                        </tr>
                        <tr>
                            <td><code>removeFromDomWhenHidden</code></td>
                            <td>Boolean</td>
                            <td>false</td>
                            <td></td>
                            <td>whether to keep content in DOM when hidden or not</td>
                        </tr>
                        <tr>
                            <td><code>v-model</code></td>
                            <td>Boolean</td>
                            <td>--</td>
                            <td></td>
                            <td>model property that when true will show the model and false will hide it. See <a class="link-info" href="https://v3.vuejs.org/api/directives.html#v-model">Vue docs</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import TVModal from '@/components/Shared/TVModal.vue'
import TVModalBody from '@/components/Shared/TVModalBody.vue'
import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
import { onMounted, ref } from 'vue'
import type { TVModalI } from '@/components/Shared/TVTypes'
import Prism from 'prismjs'

const showExample1 = ref(false);
const refExample = ref<TVModalI>();
const customFooterExample = ref(false);
const isCustomFooterSubmitted = ref(false);
const noDOMExample = ref<TVModalI>();
const customBootstrapExample = ref<TVModalI>();
const simpleBodyModalExample = ref<TVModalI>();

function customFooterExampleShow(){
    customFooterExample.value = true;
    isCustomFooterSubmitted.value = false;
}

function customFooterExampleSubmit(){
    isCustomFooterSubmitted.value = true;
}

onMounted(() => {
    Prism.highlightAll();
})

</script>

<style scoped>
.btn {
    margin-bottom: 2rem;
}
</style>

