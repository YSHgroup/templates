<template>
<div class="py-4">
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
        <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
            <li class="breadcrumb-item">
                <a href="#">
                    <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                </a>
            </li>
            <li class="breadcrumb-item"><a href="#">Volt</a></li>
            <li class="breadcrumb-item"><a href="#">Vue Components</a></li>
            <li class="breadcrumb-item active" aria-current="page">Vue Offcanvas</li>
        </ol>
    </nav>
    <div class="d-flex justify-content-between w-100 flex-wrap">
        <div class="mb-3 mb-lg-0">
            <h1 class="h4">Vue Offcanvas</h1>
            <p class="lead">A custom Vue offcanvas component based on Bootstrap perfect for both simple and complex secondary content and navigation.</p>
            <p class="lead mb-0">Exclusive to Themesberg.</p>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Features</h5>
                <ul>
                    <li>Reproduces Bootstrap Offcanvas markup exactly</li>
                    <li>Nested component model so classes can easily be added to offcanvas, header, and body.</li>
                    <li>Supports all four placement options (<code>left,</code> <code>top,</code> <code>right, </code><code>bottom </code>)</li>
                    <li>Multiple ways to toggle showing and hiding</li>
                    <li>Works with <code>v-model</code></li>
                    <li>Option to remove content from DOM when hidden</li>
                    <li>Includes built-in bootstrap animation</li>
                    <li>Emits events when shown and hidden</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Basic Example</h5>
                <div class="mb-5">
                    <div class="hstack gap-4">
                        <button type="button" class="btn btn-primary" @click="showExample1 = true">Open Offcanvas on left</button>
                        <button type="button" class="btn btn-primary" @click="showExample1Top = true">Open Offcanvas on top</button>
                        <button type="button" class="btn btn-primary" @click="showExample1Right = true">Open Offcanvas on right</button>
                        <button type="button" class="btn btn-primary" @click="showExample1Bottom = true">Open Offcanvas on bottom</button>
                    </div>
                    <TVOffcanvas v-model="showExample1">
                        <TVOffcanvasHeader title="Simple Offcanvas" />
                        <TVOffcanvasBody>
                            <p>This is a simple offcanvas.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <TVOffcanvas v-model="showExample1Top" placement="top">
                        <TVOffcanvasHeader title="Simple Offcanvas" />
                        <TVOffcanvasBody>
                            <p>This is a simple offcanvas.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <TVOffcanvas v-model="showExample1Right" placement="right">
                        <TVOffcanvasHeader title="Simple Offcanvas" />
                        <TVOffcanvasBody>
                            <p>This is a simple offcanvas.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <TVOffcanvas v-model="showExample1Bottom" placement="bottom">
                        <TVOffcanvasHeader title="Simple Offcanvas" />
                        <TVOffcanvasBody>
                            <p>This is a simple offcanvas.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <pre><code class="language-markup">
    &lt;template>
    &lt;div class="hstack gap-4">
        &lt;button type="button" class="btn btn-primary" @click="showExample1 = true">Open Offcanvas on left&lt;/button>
        &lt;button type="button" class="btn btn-primary" @click="showExample1Top = true">Open Offcanvas on top&lt;/button>
        &lt;button type="button" class="btn btn-primary" @click="showExample1Right = true">Open Offcanvas on right&lt;/button>
        &lt;button type="button" class="btn btn-primary" @click="showExample1Bottom = true">Open Offcanvas on bottom&lt;/button>
    &lt;/div>
    &lt;TVOffcanvas v-model="showExample1">
        &lt;TVOffcanvasHeader title="Simple Offcanvas" />
        &lt;TVOffcanvasBody>
            &lt;p>This is a simple offcanvas.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;TVOffcanvas v-model="showExample1Top" placement="top">
        &lt;TVOffcanvasHeader title="Simple Offcanvas" />
        &lt;TVOffcanvasBody>
            &lt;p>This is a simple offcanvas.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;TVOffcanvas v-model="showExample1Right" placement="right">
        &lt;TVOffcanvasHeader title="Simple Offcanvas" />
        &lt;TVOffcanvasBody>
            &lt;p>This is a simple offcanvas.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;TVOffcanvas v-model="showExample1Bottom" placement="bottom">
        &lt;TVOffcanvasHeader title="Simple Offcanvas" />
        &lt;TVOffcanvasBody>
            &lt;p>This is a simple offcanvas.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;/template>
    &lt;script lang="ts" setup>
        import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
        import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
        import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
        import { ref } from 'vue'

        const showExample1 = ref(false);
        const showExample1Top = ref(false);
        const showExample1Right = ref(false);
        const showExample1Bottom = ref(false);
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Example using ref</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-primary" @click="refExample?.toggle()">Toggle Offcanvas</button>
                    <TVOffcanvas ref="refExample">
                        <TVOffcanvasHeader title="Toggle with ref" />
                        <TVOffcanvasBody>
                            <p>This offcanvas is toggled with <code>.toggle()</code> on the ref.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-primary" @click="refExample?.toggle()">Toggle Offcanvas&lt;/button>
    &lt;TVOffcanvas ref="refExample">
        &lt;TVOffcanvasHeader title="Toggle with ref" />
        &lt;TVOffcanvasBody>
            &lt;p>This offcanvas is toggled with &lt;code>.toggle()&lt;/code> on the ref.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;/template>
    &lt;script lang="ts" setup>
        import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
        import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
        import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
        import { ref } from 'vue'
        import { TVOffcanvasI } from '@/components/Shared/TVTypes'

        const refExample = ref&lt;TVOffcanvasI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Offcanvas with content removed from DOM</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-tertiary" @click="noDOMExample?.toggle()">Toggle offcanvas</button>
                    <TVOffcanvas ref="noDOMExample" :remove-from-dom-when-hidden="true">
                        <TVOffcanvasHeader title="Content in and out of DOM" />
                        <TVOffcanvasBody>
                            <p class="lead">Inspect this offcanvas when the offcanvas is hidden. All elements inside <code>offcanvas</code> will be removed.</p>
                            <p>This is extremely useful for offcanvases with lots of components that could consume CPU and memory.</p> 
                            <p><b>Example: </b>A table of contents with thousands of elements.</p>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-tertiary" @click="noDOMExample?.toggle()">Toggle offcanvas&lt;/button>
    &lt;TVOffcanvas ref="noDOMExample" :remove-from-dom-when-hidden="true">
        &lt;TVOffcanvasHeader title="Content in and out of DOM" />
        &lt;TVOffcanvasBody>
            &lt;p class="lead">Inspect this offcanvas when the offcanvas is hidden. All elements inside &lt;code>offcanvas&lt;/code> will be removed.&lt;/p>
            &lt;p>This is extremely useful for offcanvases with lots of components that could consume CPU and memory.&lt;/p> 
            &lt;p>&lt;b>Example: &lt;/b>A table of contents with thousands of elements.&lt;/p>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
        import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
        import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
        import { ref } from 'vue'
        import { TVOffcanvasI } from '@/components/Shared/TVTypes'

        const noDOMExample = ref&lt;TVOffcanvasI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Offcanvas with body scroll and custom header</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-tertiary" @click="customBootstrapExample?.toggle()">Toggle offcanvas</button>
                    <TVOffcanvas ref="customBootstrapExample" placement="right" :body-scrolling="true">
                        <TVOffcanvasHeader>
                            <h2 class="fs-2">This has a H2 title</h2>
                            <div class="card bg-secondary">
                                <div class="card-body">Why not put a card here</div>
                            </div>
                        </TVOffcanvasHeader>
                        <TVOffcanvasBody>
                            <p class="lead">The offcanvas header has default slot markup if all you want to give it is a title. But feel free to get creative and include slot content instead.</p>
                            <p class="lead">Since the offcanvas header and body are individual Vue components, any attributes you add to them will be added to <code>offcanvas-header</code> and <code>offcanvas-body</code>, respectively.</p>
                            <div class="d-grid mt-2">
                                <button type="button" class="btn btn-lg btn-primary btn-block" data-bs-dismiss="offcanvas">Close</button>
                            </div>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-tertiary" @click="customBootstrapExample?.toggle()">Toggle offcanvas&lt;/button>
    &lt;TVOffcanvas ref="customBootstrapExample" placement="right" :body-scrolling="true">
        &lt;TVOffcanvasHeader>
            &lt;h2 class="fs-2">This has a H2 title&lt;/h2>
            &lt;div class="card bg-secondary">
                &lt;div class="card-body">Why not put a card here&lt;/div>
            &lt;/div>
        &lt;/TVOffcanvasHeader>
        &lt;TVOffcanvasBody>
            &lt;p class="lead">The offcanvas header has default slot markup if all you want to give it is a title. But feel free to get creative and include slot content instead.&lt;/p>
            &lt;p class="lead">Since the offcanvas header and body are individual Vue components, any attributes you add to them will be added to &lt;code>offcanvas-header&lt;/code> and &lt;code>offcanvas-body&lt;/code>, respectively.&lt;/p>
            &lt;div class="d-grid mt-2">
                &lt;button type="button" class="btn btn-lg btn-primary btn-block" data-bs-dismiss="offcanvas">Close&lt;/button>
            &lt;/div>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
        import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
        import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
        import { ref } from 'vue'
        import { TVOffcanvasI } from '@/components/Shared/TVTypes'

        const customBootstrapExample = ref&lt;TVOffcanvasI>();
    &lt;/script>
                    </code></pre>
                </div>

                <h5 class="card-title">Simple Offcanvas with no header</h5>
                <div class="mb-5">
                    <button type="button" class="btn btn-secondary" @click="simpleBodyExample?.toggle()">Toggle offcanvas</button>
                    <TVOffcanvas ref="simpleBodyExample" placement="top">
                        <TVOffcanvasBody class="d-flex flex-column">
                            <p class="lead">You always need some body.</p>
                            <button type="button" class="btn btn-gray-500 mt-auto" data-bs-dismiss="offcanvas">Close</button>
                        </TVOffcanvasBody>
                    </TVOffcanvas>
                    <pre class="language-markup"><code>
    &lt;template>
    &lt;button type="button" class="btn btn-secondary" @click="simpleBodyExample?.toggle()">Toggle offcanvas&lt;/button>
    &lt;TVOffcanvas ref="simpleBodyExample" placement="top">
        &lt;TVOffcanvasBody class="d-flex flex-column">
            &lt;p class="lead">You always need some body.&lt;/p>
            &lt;button type="button" class="btn btn-gray-500 mt-auto" data-bs-dismiss="offcanvas">Close&lt;/button>
        &lt;/TVOffcanvasBody>
    &lt;/TVOffcanvas>
    &lt;/template
    &lt;script lang="ts" setup>
        import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
        import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
        import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
        import { ref } from 'vue'
        import { TVOffcanvasI } from '@/components/Shared/TVTypes'

        const simpleBodyExample = ref&lt;TVOffcanvasI>();
    &lt;/script>
                    </code></pre>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Options</h5>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Prop</th>
                            <th>Type</th>
                            <th>Default</th>
                            <th>Required</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>placement</code></td>
                            <td>String</td>
                            <td>left</td>
                            <td></td>
                            <td>control placement with <code>left,</code> <code>top,</code> <code>right, </code>and <code>bottom </code></td>
                        </tr>
                        <tr>
                            <td><code>backdrop</code></td>
                            <td>Boolean</td>
                            <td>true</td>
                            <td></td>
                            <td>whether to show clickable backdrop</td>
                        </tr>
                        <tr>
                            <td><code>body-scrolling</code></td>
                            <td>Boolean</td>
                            <td>false</td>
                            <td></td>
                            <td>whether to allow the page body to scroll</td>
                        </tr>
                        <tr>
                            <td><code>removeFromDomWhenHidden</code></td>
                            <td>Boolean</td>
                            <td>false</td>
                            <td></td>
                            <td>whether to keep content in DOM when hidden or not</td>
                        </tr>
                        <tr>
                            <td><code>v-model</code></td>
                            <td>Boolean</td>
                            <td>--</td>
                            <td></td>
                            <td>model property that when true will show the offcanvas and false will hide it. See <a class="link-info" href="https://v3.vuejs.org/api/directives.html#v-model">Vue docs</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import type { TVOffcanvasI } from '@/components/Shared/TVTypes'
import TVOffcanvas from '@/components/Shared/TVOffcanvas.vue'
import TVOffcanvasHeader from '@/components/Shared/TVOffcanvasHeader.vue'
import TVOffcanvasBody from '@/components/Shared/TVOffcanvasBody.vue'
import Prism from 'prismjs'

const showExample1 = ref(false);
const showExample1Top = ref(false);
const showExample1Right = ref(false);
const showExample1Bottom = ref(false);

const refExample = ref<TVOffcanvasI>();
const noDOMExample = ref<TVOffcanvasI>();
const customBootstrapExample = ref<TVOffcanvasI>();
const simpleBodyExample = ref<TVOffcanvasI>();

onMounted(() => {
    Prism.highlightAll();
})

</script>

<style scoped>
.btn {
    margin-bottom: 2rem;
}
</style>

