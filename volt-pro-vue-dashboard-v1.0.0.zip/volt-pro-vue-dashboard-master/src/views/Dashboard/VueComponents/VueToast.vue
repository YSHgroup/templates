<template>
<div class="py-4">
    <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
        <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
            <li class="breadcrumb-item">
                <a href="#">
                    <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                </a>
            </li>
            <li class="breadcrumb-item"><a href="#">Volt</a></li>
            <li class="breadcrumb-item"><a href="#">Vue Components</a></li>
            <li class="breadcrumb-item active" aria-current="page">Vue Toast</li>
        </ol>
    </nav>
    <div class="d-flex justify-content-between w-100 flex-wrap">
        <div class="mb-3 mb-lg-0">
            <h1 class="h4">Vue Toast</h1>
            <p class="lead">A custom Vue toast component based on Bootstrap. Useful for low-key simple notifications.</p>
            <p class="lead mb-0">Exclusive to Themesberg.</p>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Features</h5>
                <ul>
                    <li>Reproduces Bootstrap Toast markup exactly</li>
                    <li>Includes a <code>ToastService</code> and <code>ToastManager</code> component to easily show toasts</li>
                    <li>Basic. Only need to give it a title, text content, and icon.</li>
                    <li>Currently only supports one type of toast</li>
                    <li>Includes built-in bootstrap animation</li>
                    <li>Multiple toasts stack</li>
                    <li>Guaranteed to show toasts in order</li>
                    <li>Used by the <router-link class="link-primary" :to="{name: 'DashboardUsersList' }">Users page</router-link> to show confirmation of bulk email and bulk delete actions</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">Basic Example</h5>
                <div class="mb-5">
                    <div class="hstack gap-4">
                        <button type="button" class="btn btn-primary" @click="showExample1()">Show toast</button>
                    </div>
                    <pre>
                        <code class="language-markup" >
    //App.vue
    &lt;template>
    &lt;router-view/>
    &lt;ToastManager :remove-after-shown="false" />
    &lt;/template>

    &lt;script lang="ts" setup>
    import ToastManager from '@/components/Shared/ToastManager.vue'

    &lt;/script>

    //other component
    &lt;template>
    &lt;div class="hstack gap-4">
        &lt;button type="button" class="btn btn-primary" @click="showExample1()">Show toast&lt;/button>
    &lt;/div>
    &lt;/template>
    &lt;script lang="ts" setup>
    import toastService from '@/components/Shared/ToastService';
    import { KeyIcon} from 'heroicons-vue3/solid'

    function showExample1(){
        toastService.addToast('Sample Toast', 'Notifying users is the key', KeyIcon);
    }
    &lt;/script>
                    </code>
                    </pre>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h5 class="card-title">ToastManager Options</h5>
                <table class="table mb-5">
                    <thead>
                        <tr>
                            <th>Prop</th>
                            <th>Type</th>
                            <th>Default</th>
                            <th>Required</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>removeAfterShown</code></td>
                            <td>Boolean</td>
                            <td>true</td>
                            <td></td>
                            <td>Whether to delete toasts after shown. Set to false if you want to keep a history. Even if false, toasts will only be shown once.</td>
                        </tr>
                    </tbody>
                </table>

                <h5 class="card-title">ToastService Methods</h5>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Method</th>
                            <th>Description</th>
                            <th>Parameters</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>addToast(title: String, body: String, icon?: VNode)</code></td>
                            <td>Add a toast to be shown. Will be shown immediately.</td>
                            <td><ul class="unstyled">
                                <li><code>title: String</code></li>
                                <li><code>body: String</code></li>
                                <li><code>icon?: VNode</code>
                                    <div>e.g. a heroIcon, bootstrap icon, font awesome icon
                                    </div>
                                </li>
                            </ul></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import toastService from '@/components/Shared/ToastService';
import { KeyIcon} from 'heroicons-vue3/outline'
import { onMounted } from 'vue';
import Prism from 'prismjs'

function showExample1(){
    toastService.addToast('Sample Toast', 'These messages are the key to good UX.', KeyIcon);
}

onMounted(() => {
    Prism.highlightAll();
})

</script>

<style scoped>
.btn {
    margin-bottom: 2rem;
}
</style>

