<template>
    <div class="py-4">
        <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
            <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                <li class="breadcrumb-item">
                    <a href="#">
                        <svg class="icon icon-xxs" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#">Volt</a></li>
                <li class="breadcrumb-item active" aria-current="page">Calendar</li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4">Calendar</h1>
                <p class="mb-0">Dozens of reusable components built to provide buttons, alerts, popovers, and more.</p>
            </div>
            <div>
                <a href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/plugins/calendar/" class="btn btn-outline-gray-600 d-inline-flex align-items-center">
                    <svg class="icon icon-xs me-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                    Calendar Docs
                </a>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow">
        <FullCalendar class="p-4" :options="calendarOptions" />
        <div id="calendar" class="p-4"></div>
    </div>
    
    <!-- Add event modal -->
    <teleport to="body">
        <TVModal id="newEventModal" aria-labelledby="newEventModal" v-model="showNewEventModal">
            <TVModalHeader title="New Event" />
            <TVModalBody>
                <form id="newEventForm" ref="newEventForm" @submit.prevent="addNewEvent">
                    <div class="mb-4">
                        <label for="eventTitle">Event title</label>
                        <input type="text" class="form-control" id="eventTitle" required v-model="activeEvent.title">
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <div class="mb-4">
                                <label for="dateStart">Select start date</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                                    </span>
                                    <input class="form-control" id="dateStart" type="date" placeholder="dd/mm/yyyy" required v-model="activeEvent.start">                                               
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="mb-2">
                                <label for="dateEnd">Select end date</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                                    </span>
                                    <input class="form-control" id="dateEnd" type="date" placeholder="dd/mm/yyyy" required v-model="activeEvent.end">                                               
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </TVModalBody>
            <TVModalFooter>
                <button type="submit" class="btn btn-gray-800" id="addNewEvent" @click="newEventForm?.requestSubmit()">Add new event</button>
                <button type="button" class="btn btn-gray-300 ms-auto" data-bs-dismiss="modal">Close</button>
            </TVModalFooter>
        </TVModal>
        <!-- Edit event modal -->
        <TVModal id="modal-edit-event" aria-labelledby="modal-edit-event" v-model="showEditEventModal">
            <TVModalHeader title="Edit Event" />
            <TVModalBody>
                <form id="editEventForm" class="modal-content" ref="editEventForm" @submit.prevent="editEvent">
                    <div class="mb-4">
                        <label for="eventTitleEdit">Event title</label>
                        <input type="text" class="form-control" id="eventTitleEdit" required v-model="activeEvent.title">
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <div class="">
                                <label for="dateStartEdit">Select start date</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                                    </span>
                                    <input class="form-control" id="dateStartEdit" type="date" placeholder="dd/mm/yyyy" required v-model="activeEvent.start">                                               
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="mb-2">
                                <label for="dateEndEdit">Select end date</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg>
                                    </span>
                                    <input data-datepicker="" class="form-control" id="dateEndEdit" type="date" placeholder="dd/mm/yyyy" required v-model="activeEvent.end">                                               
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </TVModalBody>
            <TVModalFooter>
                <button type="submit" class="btn btn-gray-800 me-2" id="editEvent" @click="editEventForm?.requestSubmit()">Update event</button>
                <button type="submit" class="btn btn-danger" id="deleteEvent" @click="deleteEventClick">Delete event</button>
                <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">Close</button>
            </TVModalFooter>
        </TVModal>
    </teleport>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import '@fullcalendar/core/vdom'
import FullCalendar from '@fullcalendar/vue3'
import type { CalendarOptions, EventApi, EventClickArg, EventInput } from '@fullcalendar/core'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin, { type DateClickArg } from '@fullcalendar/interaction'
import { getCalendarEvents } from '@/services/CalendarService'
import TVModal from '@/components/Shared/TVModal.vue'
import TVModalHeader from '@/components/Shared/TVModalHeader.vue'
import TVModalBody from '@/components/Shared/TVModalBody.vue'
import TVModalFooter from '@/components/Shared/TVModalFooter.vue'
import {add as dateAdd, format as dateFormat} from 'date-fns'
import _ from 'lodash'
import customSwal from '@/services/SweetAlerts'


const activeEvent = ref<EventInput|EventApi>({});
const events = ref<EventInput[]>([]);
const showNewEventModal = ref(false);
let newEventId = 99;
const newEventForm = ref<HTMLFormElement>();
const editEventForm = ref<HTMLFormElement>();
const showEditEventModal = ref(false);

function handleDateClick(arg: DateClickArg){
    activeEvent.value = {
        title: '',
        start: arg.dateStr,
        end: dateFormat(dateAdd(arg.date, {days: 1}), 'yyyy-MM-dd')
    };
    
    showNewEventModal.value = true;

    console.log('dateClick');
}

function handleEventClick(arg: EventClickArg){
    console.log('eventClick');
    //originally tried to clone arg.event, but start and end dates didn't match up with the html form input
    activeEvent.value = {
        id: arg.event.id,
        title: arg.event.title,
        start: arg.event.startStr,
        end: arg.event.endStr,
        classNames: arg.event.classNames
    }
    showEditEventModal.value = true;
}

const calendarOptions = ref<CalendarOptions>({
    plugins: [dayGridPlugin, interactionPlugin],
    dateClick: handleDateClick,
    eventClick: handleEventClick,
    events: [],
    selectable: true,
    initialView: 'dayGridMonth',
    themeSystem: 'bootstrap',
    initialDate: '2020-12-01',
    editable: true,
    buttonText: {
        prev: 'Previous',
        next: 'Next'
    },
});

(async () => {
    //fetch calendar items from server
    events.value = await getCalendarEvents();
    calendarOptions.value.events = events.value;
})();

function addNewEvent(){
    //calendar will automatically update
    console.log('addNewEvent');

    if (!activeEvent.value.title){
        return;
    }

    //make api call to save to server first

    events.value.push(
        {
            id: (newEventId++).toString(), //make api call to save then can get id, or generate id client-side (not recommended)
            title: activeEvent.value.title,
            start: activeEvent.value.start?.toString(),
            end: activeEvent.value.end?.toString(),
            className: 'bg-secondary',
            draggable: true
        });
    showNewEventModal.value = false;
}

function editEvent(){
    console.log('edit event');

    //save activeEvent changes to server with ajax call

    //update client-side event
    const event = events.value.find(e => e.id == activeEvent.value.id);
    if (!event){
        return;
    }
    event.title = activeEvent.value.title;
    event.start = activeEvent.value.start?.toString();
    event.end = activeEvent.value.end?.toString();

    showEditEventModal.value = false;
}

function deleteEventClick(){
    customSwal.fire({
        icon: 'error',
        title: 'Confirm deletion',
        text: 'Are you sure you want to delete this event?',
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: 'No, cancel!',
    }).then(function (result) {
        if (result.value) {
            //api call to delete from database sending in activeEvent.value

            //update calendar
            const indexToRemove = _.findIndex(events.value, e => e.id == activeEvent.value.id);
            if (indexToRemove < 0){
                return;
            }
            events.value.splice(indexToRemove, 1);

            customSwal.fire(
                'Deleted!',
                'The event has been deleted.',
                'success'
            );
        } 
        showEditEventModal.value = false;
    })
    
}

      
</script>
