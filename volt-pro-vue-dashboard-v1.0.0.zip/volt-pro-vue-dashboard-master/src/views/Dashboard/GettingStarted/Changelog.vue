<template>
<div class="row mt-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h3 class="card-title">Changelog</h3>
                <p class="lead">Changelog for new features, upgrades, and bug fixes for Volt Pro Vue Dashboard</p>
                
                <div class="vstack gap-4">
                    <div>
                        <h4 class="card-title">Version 1.0.0 - Feb 1, 2022</h4>
                        <ul>
                            <li>Initial release</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
</script>