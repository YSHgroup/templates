<template>
<div class="row mt-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h3 class="card-title">License</h3>
                <p class="lead">Licensing details for Volt Pro Vue Dashboard</p>
                <p>Check out our <a href="https://themesberg.com/licensing" class="link-info">official licensing page <ExternalLinkIcon class="icon icon-xs" /></a> to learn more about our licensing.</p>            
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import { ExternalLinkIcon } from 'heroicons-vue3/outline';
</script>