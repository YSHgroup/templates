<template>
<div class="row mt-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h3 class="card-title">Overview</h3>
                <p class="lead">Volt Pro Vue is a premium admin dashboard template powered by Vue.js (Vue 3) and Bootstrap 5 built using the latest recommendations by the Vue team.</p>
                <p>Use this template as-is as a great starting point for an admin dashboard, or copy the pieces you need to aid you in your design and function of any other site or SaaS application.</p>

                <div class="vstack gap-4">
                    <div>
                        <h4 class="card-title">Methodology</h4>
                        <p>This product was built based on the latest official recommendations in the 
                            <a href="https://vuejs.org/guide/introduction.html" class="link-info">Vue 3 guide <ExternalLinkIcon class="icon icon-xs"/></a>,
                            <a href="https://vuejs.org/style-guide/" class="link-info">Vue 3 style guide <ExternalLinkIcon class="icon icon-xs"/></a>,
                            and <a href="https://getbootstrap.com/docs/5.1/getting-started/introduction/" class="link-info">Bootstrap 5 docs <ExternalLinkIcon class="icon icon-xs"/></a>.
                            We structured the app based on real-world experience. Most of the views and components were built in a data-driven manner to
                            model a typical admin dashboard or SaaS application.</p>
                    </div>
                    <div>
                        <h4 class="card-title">How we built it</h4>
                        <ul>
                            <li>Scaffolded using <code>create-vue</code> (<a href="https://vuejs.org/guide/quick-start.html#with-build-tools" class="link-info">docs <ExternalLinkIcon class="icon icon-xs"/></a>):
                                <ul>
                                    <li>Vite</li>
                                    <li><code>pnpm</code> (<code>npm</code> also works. Vue 3's repo uses pnpm so that's what we used.) The commands are the same as npm. <a href="https://pnpm.io/" class="link-info">pnpm docs <ExternalLinkIcon class="icon icon-xs"/></a></li>
                                    <li>Vue.js 3.x</li>
                                    <li>Typescript</li>
                                    <li>Single-file components</li>
                                    <li>Composition api with <code>script setup</code></li>
                                    <li>Vue Router with hashmode, easily changed</li>
                                    <li>Pinia for state management</li>
                                    <li>Sass/SCSS</li>
                                    <li>ESLint with error prevention only, lint on save</li>
                                    <li>Dedicated config files for Babel, ESLint, etc</li>
                                </ul>
                            </li>
                            <li>Single-file Components (SFCs)</li>
                            <li><a href="https://vuejs.org/guide/extras/composition-api-faq.html" class="link-info">Composition API <ExternalLinkIcon class="icon icon-xs"/></a></li>
                            <li><code>script setup</code> (<a href="https://vuejs.org/api/sfc-script-setup.html#script-setup" class="link-info">docs <ExternalLinkIcon class="icon icon-xs"/>)</a></li> 
                            <li>Bootstrap 5.1
                                <ul>
                                    <li>Sass variables with defaults (<a href="https://getbootstrap.com/docs/5.1/customize/sass/#variable-defaults" class="link-info">docs <ExternalLinkIcon class="icon icon-xs"/>)</a></li>
                                    <li>CSS Grid is not enabled (<a href="https://getbootstrap.com/docs/5.1/layout/css-grid/" class="link-info">docs <ExternalLinkIcon class="icon icon-xs"/></a>)</li>
                                </ul>
                            </li>
                            <li>SVG Icon libraries
                                <ul>
                                    <li><a href="https://heroicons.com/" class="link-info">Heroicons <ExternalLinkIcon class="icon icon-xs"/></a></li>
                                    <li><a href="https://fontawesome.com/v5.15/icons" class="link-info">Font Awesome 5 <ExternalLinkIcon class="icon icon-xs"/></a></li>
                                </ul>
                            </li>

                        </ul>
                    </div>
                    <div>
                        <h4 class="card-title">Developer Tooling</h4>
                        <p class="lead"><a href="https://vuejs.org/guide/scaling-up/tooling.html#ide-support" class="link-info">Vue Official Tooling Docs <ExternalLinkIcon class="icon icon-xs"/></a></p>
                        <ol>
                            <li>Visual Studio Code with plugins:
                                <ul>
                                    <li>ESLint</li>
                                    <li>Vue Language Features (Volar)</li>
                                    <li>Typescript Vue Plugin (Volar)</li>
                                </ul>
                            </li>
                            <li>OR Webstorm</li>
                            <li><a href="https://devtools.vuejs.org/" class="link-info">Vue DevTools Chrome Browser Extension <ExternalLinkIcon class="icon icon-xs" /></a></li>
                        </ol>
                    </div>
                    <div>
                        <h4 class="card-title">Getting Started</h4>
                        <div class="alert alert-warning">Continue with the <router-link class="alert-link" :to="{name: 'DashboardGettingStartedQuickStart'}">QuickStart</router-link> to get up and running in no time.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import { ExternalLinkIcon } from 'heroicons-vue3/outline';
</script>