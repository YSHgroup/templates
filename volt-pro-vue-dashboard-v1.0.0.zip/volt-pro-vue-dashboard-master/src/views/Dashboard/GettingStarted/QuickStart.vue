<template>
<div class="row mt-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h3 class="card-title">Quick Start</h3>
                <p class="lead">This guide will help you get started with Volt Pro Vue Dashboard.</p>
                <p>You'll be up and running in no time.</p>

                <p class="lead">Volt Pro Vue Dashboard is scaffolded using Vue's <code>create-vue</code> repo.</p>

                <div class="alert alert-warning">Please read the <router-link :to="{name: 'DashboardGettingStartedOverview'}">Overview</router-link> first if you haven't already.</div>

                <div class="vstack gap-4">
                    <div>
                        <h3 class="card-title">Prerequisites</h3>
                        <ol>
                            <li>Node.js: <a href="https://nodejs.org/en/download/" class="link-info">Install Node.js <ExternalLinkIcon class="icon icon-xs" />.</a> <em>LTS recommended</em></li>
                        </ol>
                    </div>
                    <div>
                        <h3 class="card-title">Option 1 - pnpm (recommended)</h3>
                        <ol>
                            <li>Install <code>pnpm</code>: <a href="https://pnpm.io/" class="link-info">Install pnpm <ExternalLinkIcon class="icon icon-xs" /></a></li>
                            <li>Open a terminal at the root directory of the project (the directory with <code>package.json</code>). <em>We recommend opening the project folder in Visual Studio Code, and opening a Terminal there.</em></li>
                            <li>From the terminal, run:
                                <pre>
                                    <code class="fs-5">pnpm install</code>
                                </pre>
                                <div>This will install all the project dependencies. A <code>pnpm-lock.yaml</code> file will be generated. This should be saved in source control.</div>
                            </li>
                            <li>Once dependencies are installed, now run:
                                <pre>
                                    <code class="fs-5">npm run dev</code>
                                </pre>
                            </li>
                        </ol>
                        <p>That's it! This will launch the site in development mode with hot module reloading.</p>
                        <p>See <a href="https://vitejs.dev/guide/#command-line-interface" class="link-info">Vite <ExternalLinkIcon class="icon icon-xs" /></a> for other commands, which can be found in the <code>package.json</code> file <code>scripts</code> section</p>
                    </div>
                    <div>
                        <h3 class="card-title">Option 2 - NPM</h3>
                        <ol>
                            <li><code>npm</code> is installed automatically with <code>node.js</code> installation.</li>
                            <li>Open a terminal at the root directory of the project (the directory with <code>package.json</code>). <em>We recommend opening the project folder in Visual Studio Code, and opening a Terminal there.</em></li>
                            <li>Delete the <code>pnpm-lock.yaml</code> file at the root of the project.</li>
                            <li>From the terminal, run:
                                <pre>
                                    <code class="fs-5">npm install</code>
                                </pre>
                                <div>This will install all the project dependencies. A <code>package-lock.json</code> file will be added to the root of your project.</div>
                            </li>
                            <li>Once dependencies are installed, now run:
                                <pre>
                                    <code class="fs-5">npm run serve</code>
                                </pre>
                            </li>
                        </ol>
                        <p>That's it! This will launch the site in development mode with hot module reloading.</p>
                        <p>See <a href="https://vitejs.dev/guide/#command-line-interface" class="link-info">Vite<ExternalLinkIcon class="icon icon-xs" /></a> for other commands, which can be found in the <code>package.json</code> file <code>scripts</code> section</p>
                    </div>
                </div>                
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import { ExternalLinkIcon } from 'heroicons-vue3/outline';
</script>