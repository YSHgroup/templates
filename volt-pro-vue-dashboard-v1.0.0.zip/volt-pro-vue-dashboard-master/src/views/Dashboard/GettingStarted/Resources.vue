<template>
<div class="row mt-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow">
            <div class="card-body">
                <h3 class="card-title">Useful Resources</h3>
                <p class="lead">Helpful documentation resources to get you going with your project</p>
                <p>I have to refer to these a lot!</p>

                <table class="table">
                    <thead>
                        <tr>
                            <th>Resource</th>
                            <th>URL</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Vue 3 Guide</td>
                            <td><a href="https://vuejs.org/guide/introduction.html" class="link-info">https://vuejs.org/guide/introduction.html <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Primary documenation site for Vue 3</td>
                        </tr>
                        <tr>
                            <td>Vue 3 Style Guide</td>
                            <td><a href="https://vuejs.org/style-guide/" class="link-info">https://vuejs.org/style-guide/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Official style guide for Vue</td>
                        </tr>
                        <tr>
                            <td>Vue Router</td>
                            <td><a href="https://router.vuejs.org/" class="link-info">https://router.vuejs.org/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Official Vue routing library used in this project</td>
                        </tr>
                        <tr>
                            <td>Vite</td>
                            <td><a href="https://vitejs.dev/guide/" class="link-info">https://vitejs.dev/guide/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Official recommended lightweight and fast build tool built by Evan Yu</td>
                        </tr>
                        <tr>
                            <td>Pinia</td>
                            <td><a href="https://pinia.vuejs.org/" class="link-info">https://pinia.vuejs.org/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Official recommended state management library maintained by the Vue core team</td>
                        </tr>
                        <tr>
                            <td>Bootstrap</td>
                            <td><a href="https://getbootstrap.com/docs/5.1/getting-started/introduction/" class="link-info">https://getbootstrap.com/docs/5.1/getting-started/introduction/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Docs for Bootstrap markup, styles, and components</td>
                        </tr>
                        <tr>
                            <td>Volt Pro Bootstrap 5 Dashboard</td>
                            <td><a href="https://demo.themesberg.com/volt-pro/pages/dashboard/dashboard.html" class="link-info">https://demo.themesberg.com/volt-pro/pages/dashboard/dashboard.html <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Components and markup examples for this theme</td>
                        </tr>
                        <tr>
                            <td>Heroicons</td>
                            <td><a href="https://heroicons.com/" class="link-info">https://heroicons.com/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>List of available Heroicons</td>
                        </tr>
                        <tr>
                            <td>Font Awesome 5 Icons</td>
                            <td><a href="https://fontawesome.com/v5.15/icons" class="link-info">https://fontawesome.com/v5.15/icons <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>List of available Font Awesome 5 Icons</td>
                        </tr>
                        <tr>
                            <td>Vue Chrome Devtools</td>
                            <td><a href="https://devtools.vuejs.org/" class="link-info">https://devtools.vuejs.org/ <ExternalLinkIcon class="icon icon-xs" /></a></td>
                            <td>Chrome extension useful in debugging and inspecting your app while developing</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</template>

<script lang="ts" setup>
import { ExternalLinkIcon } from 'heroicons-vue3/outline';
</script>