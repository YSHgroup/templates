<template>
    <div class="py-4">
        <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
            <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                <li class="breadcrumb-item">
                    <a href="#">
                        <HomeIcon class="icon icon-xxs" />
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#">Volt</a></li>
                <li class="breadcrumb-item active" aria-current="page">Map</li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between w-100 flex-wrap">
            <div class="mb-3 mb-lg-0">
                <h1 class="h4">MapBox (Leaflet.js)</h1>
                <p class="mb-0">Dozens of reusable components built to provide buttons, alerts, popovers, and more.</p>
            </div>
            <div>
                <a href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/plugins/mapbox/" class="btn btn-outline-gray-600 d-inline-flex align-items-center">
                    <QuestionMarkCircleIcon class="icon icon-xs me-1" />
                    MapBox Docs
                </a>
            </div>
        </div>
    </div>

    <div class="card">
        <div id="mapbox" class="p-4" ref="elMapbox"></div>
    </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { QuestionMarkCircleIcon } from 'heroicons-vue3/solid'
import { HomeIcon } from 'heroicons-vue3/outline'
import L from 'leaflet'
import markerUrl from '@/assets/img/marker.svg'


const baseLatLng: L.LatLngTuple = [37.57, -122.26];
const zoom = 10;
const listings = [
        {
            url: '#',
            latLng: [37.70, -122.41],
            name: 'Call with Jane',
            date: 'Tomorrow at 12:30 PM'
        },
        {
            url: '#',
            latLng: [37.59, -122.39],
            name: 'HackTM conference',
            date: 'In about 5 minutes'
        },
        {
            url: '#',
            latLng: [37.52, -122.29],
            name: 'Marketing event',
            date: 'Today at 1:00 PM'
        },
        {
            url: '#',
            latLng: [37.37, -122.12],
            name: 'Dinner with partners',
            date: 'In 2 hours'
        },
        {
            url: '#',
            latLng: [37.36, -121.94],
            name: 'Interview with Google',
            date: 'In two days at 15:00 PM'
        }
    ];

 const icon = L.icon({
            iconUrl: markerUrl,
            iconSize: [38, 95], // size of the icon
            shadowSize: [50, 64], // size of the shadow
            iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
            shadowAnchor: [4, 62],  // the same for the shadow
            popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
        });

const elMapbox = ref<HTMLElement>();
        
onMounted(() => {
    if (elMapbox.value){
        console.log('mapbox id: ', import.meta.env.VITE_MAPBOX_ID);
        console.log('mapbox token', import.meta.env.VITE_MAPBOX_TOKEN);
        
        const mapListings = L.map(elMapbox.value).setView(baseLatLng, zoom);

        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            maxZoom: 18,
            id: import.meta.env.VITE_MAPBOX_ID,
            accessToken: import.meta.env.VITE_MAPBOX_TOKEN
        }).addTo(mapListings);

        listings.map(function (listing) {
            const popupHtml = `
                <a href="${listing.url}" class="card card-article-wide border-0 flex-column no-gutters no-hover">
                    <div class="card-body py-0 d-flex flex-column justify-content-between col-12">
                        <h4 class="h5 fw-normal mb-2">${listing.name}</h4>
                        <div class="d-flex"><div class="icon icon-xs icon-tertiary me-2"><span class="fas fa-clock"></span></div><div class="font-xs text-dark">${listing.date}</div></div>
                    </div>
                </a>
            `;

            const marker = L.marker(listing.latLng as L.LatLngTuple, { icon: icon }).addTo(mapListings);
            marker.bindPopup(popupHtml);
        });
    }
})
</script>


