<template>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
        <div class="d-block mb-4 mb-md-0">
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
                <ol class="breadcrumb breadcrumb-dark breadcrumb-transparent">
                    <li class="breadcrumb-item"><a href="#"><span class="fas fa-home"></span></a></li>
                    <li class="breadcrumb-item"><a href="#">Volt</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Widgets</li>
                </ol>
            </nav>
            <h2 class="h4">Widgets</h2>
            <p class="mb-0">You can easily show your stats content by using these cards.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-6 col-xl-4 mb-4">
        <CustomersWidget />
        </div>
        <div class="col-12 col-sm-6 col-xl-4 mb-4">
        <RevenueWidget />
        </div>
        <div class="col-12 col-sm-12 col-xl-4 mb-4">
        <UsersWidget />
        </div>
    </div><!-- end row -->
    <div class="row">
        <div class="col-12 col-xxl-4 mb-4">
        <WeeklySalesWidget />
        </div>
        <div class="col-12 col-md-6 col-xxl-4 mb-4">
        <TopAuthorEarningsWidget />
        </div>
        <div class="col-12 col-md-6 col-xxl-4 mb-4">
        <NotificationsTimelineWidget />
        </div>
    </div><!-- end row -->
    <div class="row justify-content-lg-center">
        <div class="col-12 mb-4">
            <SalesValueWidget />
        </div>
    </div><!-- end row -->
    <div class="row">
        <div class="col-12 col-xl-7 col-xxl-8 mb-4">
        <div class="row">
            <!-- Page visits -->
            <div class="col-12 mb-4">
            <PageVisitsWidget />
            </div>
            <div class="col-12 col-xxl-6 mb-4">
            <TeamMembersWidget />
            </div>
            <div class="col-12 col-xxl-6 mb-4">
            <ProgressTrackWidget />
            </div>
            <div class="col-12">
            <EventsWidget />
            </div>
        </div>
        </div>
        <div class="col-12 col-xl-5 col-xxl-4 mb-4">
        <div class="col-12 px-0 mb-4">
            <StaticRankWidget />
        </div>
        <div class="col-12 px-0 mb-4">
            <StaticAcquisitionWidget />
        </div>
        <div class="col-12 px-0">
            <TrafficByCountryWidget />
        </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import CustomersWidget from "@/components/Widgets/CustomersWidget.vue";
import RevenueWidget from "@/components/Widgets/RevenueWidget.vue";
import UsersWidget from "@/components/Widgets/UsersWidget.vue";
import PageVisitsWidget from "@/components/Widgets/PageVisitsWidget.vue";
import TeamMembersWidget from "@/components/Widgets/TeamMembersWidget.vue";
import SalesValueWidget from "@/components/Widgets/SalesValueWidget.vue";
import WeeklySalesWidget from "@/components/Widgets/WeeklySalesWidget.vue";
import TopAuthorEarningsWidget from "@/components/Widgets/TopAuthorEarningsWidget.vue"
import NotificationsTimelineWidget from "@/components/Widgets/NotificationsTimelineWidget.vue"
import ProgressTrackWidget from "@/components/Widgets/ProgressTrackWidget.vue"
import EventsWidget from "@/components/Widgets/EventsWidget.vue"
import StaticRankWidget from "@/components/Widgets/StaticRankWidget.vue"
import StaticAcquisitionWidget from "@/components/Widgets/StaticAcquisitionWidget.vue"
import TrafficByCountryWidget from "@/components/Widgets/TrafficByCountryWidget.vue"

</script>