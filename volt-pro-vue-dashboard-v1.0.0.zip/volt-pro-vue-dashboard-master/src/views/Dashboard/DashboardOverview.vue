<template>
  <div class="py-4">
    <div class="dropdown">
      <button class="btn btn-gray-800 d-inline-flex align-items-center me-2 dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <PlusIcon class="icon icon-xs me-2" /> New Task
      </button>
      <div class="dropdown-menu dashboard-dropdown dropdown-menu-start mt-2 py-1">
        <a class="dropdown-item d-flex align-items-center" href="#">
          <UserAddIcon class="dropdown-icon text-gray-400 me-2" />
          Add User
        </a>
        <a class="dropdown-item d-flex align-items-center" href="#">
          <CollectionIcon class="dropdown-icon text-gray-400 me-2" />
          Add Widget
        </a>
        <a class="dropdown-item d-flex align-items-center" href="#">
          <CloudUploadIcon class="dropdown-icon text-gray-400 me-2" />
          Upload Files
        </a>
        <a class="dropdown-item d-flex align-items-center" href="#">
          <ShieldCheckIcon class="dropdown-icon text-gray-400 me-2" />
          Preview Security
        </a>
        <div role="separator" class="dropdown-divider my-1"></div>
        <a class="dropdown-item d-flex align-items-center" href="#">
          <FireIcon class="dropdown-icon text-danger me-2" />
          Upgrade to Pro
        </a>
      </div>
    </div>
  </div>
  <div class="row justify-content-lg-center">
    <div class="col-12 mb-4">
      <SalesValueWidget />
    </div>
  </div><!-- end row -->
  <div class="row">
    <div class="col-12 col-sm-6 col-xl-4 mb-4">
      <CustomersWidget />
    </div>
    <div class="col-12 col-sm-6 col-xl-4 mb-4">
      <RevenueWidget />
    </div>
    <div class="col-12 col-sm-12 col-xl-4 mb-4">
      <UsersWidget />
    </div>
  </div><!-- end row -->
  <div class="row">
    <div class="col-12 col-xxl-4 mb-4">
      <WeeklySalesWidget />
    </div>
    <div class="col-12 col-md-6 col-xxl-4 mb-4">
      <TopAuthorEarningsWidget />
    </div>
    <div class="col-12 col-md-6 col-xxl-4 mb-4">
      <NotificationsTimelineWidget />
    </div>
  </div><!-- end row -->
  <div class="row">
    <div class="col-12 col-xl-7 col-xxl-8 mb-4">
      <div class="row">
        <!-- Page visits -->
        <div class="col-12 mb-4">
          <PageVisitsWidget />
        </div>
        <div class="col-12 col-xxl-6 mb-4">
          <TeamMembersWidget />
        </div>
        <div class="col-12 col-xxl-6 mb-4">
          <ProgressTrackWidget />
        </div>
        <div class="col-12">
          <EventsWidget />
        </div>
      </div>
    </div>
    <div class="col-12 col-xl-5 col-xxl-4 mb-4">
      <div class="col-12 px-0 mb-4">
        <StaticRankWidget />
      </div>
      <div class="col-12 px-0 mb-4">
        <StaticAcquisitionWidget />
      </div>
      <div class="col-12 px-0">
        <TrafficByCountryWidget />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import CustomersWidget from "../../components/Widgets/CustomersWidget.vue";
import RevenueWidget from "../../components/Widgets/RevenueWidget.vue";
import UsersWidget from "../../components/Widgets/UsersWidget.vue";
import PageVisitsWidget from "../../components/Widgets/PageVisitsWidget.vue";
import TeamMembersWidget from "../../components/Widgets/TeamMembersWidget.vue";
import SalesValueWidget from "../../components/Widgets/SalesValueWidget.vue";
import WeeklySalesWidget from "../../components/Widgets/WeeklySalesWidget.vue";
import TopAuthorEarningsWidget from "../../components/Widgets/TopAuthorEarningsWidget.vue"
import NotificationsTimelineWidget from "../../components/Widgets/NotificationsTimelineWidget.vue"
import ProgressTrackWidget from "../../components/Widgets/ProgressTrackWidget.vue"
import EventsWidget from "../../components/Widgets/EventsWidget.vue"
import StaticRankWidget from "../../components/Widgets/StaticRankWidget.vue"
import StaticAcquisitionWidget from "../../components/Widgets/StaticAcquisitionWidget.vue"
import TrafficByCountryWidget from "../../components/Widgets/TrafficByCountryWidget.vue"

import {PlusIcon, UserAddIcon, CollectionIcon, CloudUploadIcon, ShieldCheckIcon, FireIcon} from "heroicons-vue3/solid"

</script>