<template>
    <DashboardNav />
    <DashboardSidenav :class="{'notransition': !showTransition}"/>
    <main class="content" :class="{'notransition': !showTransition}">
        <DashboardTopnavbar/>
        <div v-if="isLoading" class="d-flex justify-content-center p-5 m-5">
            <div class="fs-2">
                <span class="ms-1">Loading...</span>
                <span class="spinner-border" role="status" aria-hidden="true"></span>
            </div>
        </div>
        <router-view v-else/>
        <footer class="bg-white rounded shadow p-5 mb-4 mt-4">
            <div class="row">
                <div class="col-12 col-md-4 col-xl-6 mb-4 mb-md-0">
                    <p class="mb-0 text-center text-lg-start">© 2019-<span class="current-year">{{ currentYear }}</span> <a class="text-primary fw-normal" href="https://themesberg.com" target="_blank">Themesberg</a></p>
                </div>
                <div class="col-12 col-md-8 col-xl-6 text-center text-lg-start">
                    <!-- List -->
                    <ul class="list-inline list-group-flush list-group-borderless text-md-end mb-0">
                        <li class="list-inline-item px-0 px-sm-2">
                            <a href="https://themesberg.com/about">About</a>
                        </li>
                        <li class="list-inline-item px-0 px-sm-2">
                            <a href="https://themesberg.com/themes">Themes</a>
                        </li>
                        <li class="list-inline-item px-0 px-sm-2">
                            <a href="https://themesberg.com/blog">Blog</a>
                        </li>
                        <li class="list-inline-item px-0 px-sm-2">
                            <a href="https://themesberg.com/contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </main>
</template>

<script lang="ts" setup>
import { onMounted, ref } from "vue";
import DashboardNav from '@/components/DashboardNav.vue';
import DashboardSidenav from '@/components/DashboardSidenav.vue';
import DashboardTopnavbar from '@/components/DashboardTopnavbar.vue';
import { useUsersStore } from '@/stores/users';

//init app state
//init users (just an example - users don't need to be global to the app)
const usersStore = useUsersStore();
const isLoading = ref(false);

(async () => {
    try{
        isLoading.value = true;
        await usersStore.initUsers();
    }
    catch(ex){
        //console.log(ex)
    }
    finally{
        isLoading.value = false;
    }
})()

const currentYear = new Date().getFullYear();

const showTransition = ref(false);
onMounted(() => {
    setTimeout(() => {
        showTransition.value = true;
    }, 500);
})
</script>