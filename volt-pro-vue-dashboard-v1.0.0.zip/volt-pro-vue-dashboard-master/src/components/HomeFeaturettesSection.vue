<template>
  <section class="section section-lg bg-gray-800 text-white">
    <div class="container">
      <div class="row justify-content-center mb-5 mb-lg-6">
        <div class="col-12 text-center">
          <h2 class="h1 px-lg-5">Awesome Features</h2>
          <p class="lead px-lg-8">
            You get all Vue and Bootstrap components fully customized. Besides, you
            receive numerous plugins out of the box and ready to use.
          </p>
        </div>
      </div>
      <div class="row">
        <VoltFeaturette
          v-for="(featurette, i) in featurettes"
          :key="i"
          v-bind="featurette"
        />
      </div>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import VoltFeaturette from "./Shared/VoltFeaturette.vue";
import type VoltFeaturetteProp from "./Shared/VoltFeaturetteProps";
import {faBootstrap, faSass, faGulp, faAccessibleIcon, faVuejs, faHtml5} from '@fortawesome/free-brands-svg-icons';
import {faBolt, faMobileAlt, faMapMarkedAlt, faPenFancy} from '@fortawesome/free-solid-svg-icons';
import {faImages, faFileAlt, faCalendarAlt} from '@fortawesome/free-regular-svg-icons';


const featurettes = ref<VoltFeaturetteProp[]>([]);

const sizeClasses = "col-12 col-sm-6 col-lg-3";

featurettes.value.push(
  {
    sizeClasses,
    faIcon: faVuejs,
    heading: "Vue 3",
    subHeading: "The progressive JavaScript framework",
  },
  {
    sizeClasses,
    faIcon: faBolt,
    heading: "Vite",
    subHeading: "Speedy builds and hot module reloads",
  },
  {
    sizeClasses,
    faIcon: faBootstrap,
    heading: "Bootstrap 5",
    subHeading: "Built with the most popular CSS Framework",
  },
  {
    sizeClasses,
    faIcon: faSass,
    heading: "Sass",
    subHeading: "Variables and mixins to empower development",
  },
  {
    sizeClasses,
    faIcon: faMobileAlt,
    heading: "Responsive",
    subHeading: "All pages and components are 100% responsive",
  },
  {
    sizeClasses,
    faIcon: faImages,
    heading: "Creative rights",
    subHeading: "All images, icons and fonts are licensed & free to use",
  },
  {
    sizeClasses,
    faIcon: faFileAlt,
    heading: "Documentation",
    subHeading: "Everything that comes with Volt is well documented",
  },
  {
    sizeClasses,
    faIcon: faAccessibleIcon,
    heading: "WCAG Accessibility",
    subHeading: "Accessibility-oriented design and functionality",
  },
  {
    sizeClasses,
    faIcon: faHtml5,
    heading: "W3C Validated",
    subHeading: "HTML pages are all valid by W3C Standards",
  },
  {
    sizeClasses,
    faIcon: faCalendarAlt,
    heading: "Calendar",
    subHeading: "Advanced integration with FullCalendar.js",
  },
  {
    sizeClasses,
    faIcon: faMapMarkedAlt,
    heading: "MapBox",
    subHeading: "Custom integration with markers and cards",
  },
  {
    sizeClasses,
    faIcon: faPenFancy,
    heading: "Design",
    subHeading: "Crafted by professional UI/UX designers",
  }
);
</script>