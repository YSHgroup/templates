<template>
    <nav class="navbar navbar-dark navbar-theme-primary px-4 col-12 d-lg-none">
        <router-link class="navbar-brand me-lg-5" :to="{name: 'Home'}">
            <img class="me-2" height="25" width="25" src="@/assets/img/vue-logo.svg" alt="Volt logo" />
            Volt Pro Vue
        </router-link>
        <div class="d-flex align-items-center">
            <button class="navbar-toggler d-lg-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
</template>