<template>
    <div class="card border-0 shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-centered table-nowrap mb-0 rounded">
                    <thead class="thead-light">
                        <tr>
                            <th class="border-0 rouded-start">#</th>
                            <th class="border-0">Traffic Source</th>
                            <th class="border-0">Source Type</th>
                            <th class="border-0">Category</th>
                            <th class="border-0">Global Rank</th>
                            <th class="border-0">Traffic Share</th>
                            <th class="border-0 rounded-end">Change</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Item -->
                        <tr v-for="(trafficSource,index) in trafficSources" :key="trafficSource.name">
                            <td><a href="#" class="text-primary fw-bold">{{index+1}}</a> </td>
                            <td class="fw-bold">
                                <div class="d-flex align-items-center">
                                    <template v-if="trafficSource.heroIcon">
                                        <component :is="trafficSource.heroIcon + 'Icon'" class="icon icon-xxs text-gray-500 me-2" />
                                    </template>
                                    <font-awesome-icon v-else :icon="['fab', trafficSource.faIcon]" class="icon icon-xxs text-gray-500 me-2" />
                                    {{ trafficSource.name }}
                                </div>
                            </td>
                            <td>
                                {{trafficSource.type}}
                            </td>
                            <td>
                                {{trafficSource.category ?? '-'}} 
                            </td>
                            <td>
                                {{trafficSource.globalRank ? '#' + trafficSource.globalRank :  '--'}}
                            </td>
                            <td>
                                <div class="row d-flex align-items-center">
                                    <div class="col-12 col-xl-2 px-0">
                                        <div class="small fw-bold">{{trafficSource.sharePercent}}%</div>
                                    </div>
                                    <div class="col-12 col-xl-10 px-0 px-xl-1">
                                        <div class="progress progress-lg mb-0">
                                            <div class="progress-bar bg-dark" role="progressbar" :aria-valuenow="trafficSource.sharePercent" aria-valuemin="0" aria-valuemax="100" :style="{width: trafficSource.sharePercent + '%'}"></div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-center" :class="trafficSource.changePercent > 0 ? 'text-success' : trafficSource.changePercent < 0 ? 'text-danger' : ''">
                                    <template v-if="trafficSource.changePercent > 0">
                                        <ChevronUpIcon class="icon icon-xs me-1" />
                                        <span class="fw-bold">{{ trafficSource.changePercent }}%</span>
                                    </template>
                                    <template v-else-if="trafficSource.changePercent < 0">
                                        <ChevronDownIcon class="icon icon-xs me-1" />
                                        <span class="fw-bold">{{ trafficSource.changePercent * -1 }}%</span>
                                    </template>
                                    <template v-else>
                                        --
                                    </template>
                                    
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { type TrafficSource, getTrafficSourcesAsync } from '@/services/DataService'
import { ChevronDownIcon, ChevronUpIcon } from 'heroicons-vue3/solid'


const trafficSources = ref<TrafficSource[]>([]);

(async () => {
    trafficSources.value = await getTrafficSourcesAsync();
})();

       
</script>
