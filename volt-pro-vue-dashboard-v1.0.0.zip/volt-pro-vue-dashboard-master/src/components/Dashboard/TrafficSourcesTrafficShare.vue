<template>
    <div class="card border-0 shadow">
        <div class="card-body d-flex flex-row align-items-center flex-0 border-bottom">
            <div class="d-block">
                <div class="h6 fw-normal text-gray mb-2">Traffic Share</div>
                <h2 class="h4">Direct</h2>
                <div class="small mt-2">                               
                    <span class="text-success fw-bold">51.5%</span>
                </div>
            </div>
            <div class="ms-auto">
                <div class="d-flex align-items-center mb-2">
                    <span class="fw-normal small me-3">Direct</span>
                    <span class="small fw-bold text-dark ms-auto">51.50%</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <span class="fw-normal small me-3">Referrals</span>
                    <span class="small fw-bold text-dark ms-auto">29.40%</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <span class="fw-normal small me-3">Organic</span>
                    <span class="small fw-bold text-dark ms-auto">9.10%</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <span class="fw-normal small me-3">Social</span>
                    <span class="small fw-bold text-dark ms-auto">6.50%</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <span class="fw-normal small me-3">Mail</span>
                    <span class="small fw-bold text-dark ms-auto">3.50%</span>
                </div>
            </div>
        </div>
        <div class="card-body p-2 py-5">
            <div id="traffic-share-chart"></div>
            <apexchart type="bar" :options="options" :series="series" />
        </div>
    </div>
</template>

<script lang="ts" setup>
import {ref} from 'vue';
import type { ApexOptions } from 'apexcharts';

// Sales by Product
const series = ref([{
            name: 'Visits',
            data: [4, 7, 9, 29, 51]
        }]);

    const options = ref<ApexOptions>({
        chart: {
            type: 'bar',
            height: 500,
            foreColor: '#4B5563',
            fontFamily: 'Inter',
        },
        plotOptions: {
            bar: {
                horizontal: true,
                distributed: false,
                barHeight: '90%',
                borderRadius: 10,
                colors: {
                    backgroundBarColors: ['#fff'],
                    backgroundBarOpacity: .2,
                    backgroundBarRadius: 10,
                },
            }
        },
        colors: ['#4D4AE8'],
        dataLabels: {
            enabled: true,
            textAnchor: 'middle',
            formatter: function (val, opt) {
                return opt.w.globals.labels[opt.dataPointIndex]
            },
            offsetY: -1,
            dropShadow: {
                enabled: false,
            },
            style: {
                fontSize: '12px',
                fontFamily: 'Inter',
                fontWeight: '500',
            }
        },
        grid: {
            show: false,
            borderColor: '#f2f2f2',
            strokeDashArray: 1,
        },
        legend: {
            show: false,
        },
        yaxis: {
            labels: {
                show: false
            },
        },
        tooltip: {
            fillSeriesColor: false,
            onDatasetHover: {
                highlightDataSeries: false,
            },
            theme: 'light',
            style: {
                fontSize: '12px',
                fontFamily: 'Inter',
            },
            y: {
                formatter: function (val) {
                    return val + "%"
                }
            },
        },
        xaxis: {
            categories: ['Mail', 'Social', 'Organic', 'Referrals', 'Direct'],
            labels: {
                style: {
                    fontSize: '12px',
                    fontWeight: 500,
                },
                offsetY: 5
            },
            axisBorder: {
                color: '#ffffff',
            },
            axisTicks: {
                color: '#ffffff',
                offsetY: 5
            },
        }
    });

</script>
