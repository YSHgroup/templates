import type { IconDefinition } from "@fortawesome/free-solid-svg-icons";
import type { VNode } from 'vue';

export default interface SidenavItem{
    id: string;
    routeName?: string;
    iconImage?: string;
    iconImageAlt?: string;
    icon?: IconDefinition;
    heroIcon?: VNode;
    minimizedText?: string;
    title: string;
    children?: SidenavItem[];
    notificationCount?: number;
    url?: string;
    badge?: string;
}