<template>
    <router-link :to="{name: routeName}" class="page-preview scale-up-2">
        <img class="shadow-lg rounded" :src="thumbnailPath" :alt="thumbnailAltText">
        <div class="text-center show-on-hover rounded-bottom">
            <h6 class="m-0 text-center d-inline-flex align-items-center text-white">{{ name }} <font-awesome-icon :icon="externalLinkIcon" class="ms-2"/></h6>
        </div>
    </router-link>
</template>

<script lang="ts" setup>
import { faExternalLinkAlt as externalLinkIcon } from '@fortawesome/free-solid-svg-icons';
import { computed } from 'vue'
import { getPageThumbnailUrl } from '@/services/Functions'

const props = defineProps<{
        thumbnailFilename: string,
        thumbnailAltText: string,
        routeName: string,
        name: string
}>();

const thumbnailPath = computed(() => getPageThumbnailUrl(props.thumbnailFilename));

</script>

<style lang="scss" scoped>
.page-preview:hover{
    z-index: 1;
}

.page-preview .show-on-hover{
    left: 0;
    width: 100%;
    bottom: 0;
}
</style>