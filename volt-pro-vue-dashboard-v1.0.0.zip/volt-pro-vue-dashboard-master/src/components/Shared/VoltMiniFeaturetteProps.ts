import type { VNode } from "vue";

export default interface VoltMiniFeaturetteProps{
    sizeClasses: string;
    icon: VNode;
    heading: string;
    subHeading: string;
}