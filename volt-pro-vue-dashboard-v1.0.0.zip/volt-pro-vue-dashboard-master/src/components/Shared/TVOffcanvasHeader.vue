<template>
    <div class="offcanvas-header">
        <slot>
            <h5 class="offcanvas-title">{{ title }}</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </slot>
    </div>
</template>

<script lang="ts" setup>
defineProps({
    title: {
        type: String,
        required: false
    }
})
</script>