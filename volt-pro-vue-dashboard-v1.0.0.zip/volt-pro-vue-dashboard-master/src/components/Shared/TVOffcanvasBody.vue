<template>
<div class="offcanvas-body">
    <slot></slot>
</div>
</template>

<script lang="ts" setup>


</script>