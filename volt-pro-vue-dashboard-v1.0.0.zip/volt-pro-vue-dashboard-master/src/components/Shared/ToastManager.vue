<template>
    <teleport to="body">
        <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
            <Toast v-for="toast in unShownToasts" :key="toast.id" :title="toast.title" @on-shown="toastShown(toast)" class="mb-3">
                {{ toast.body }} <component :is="toast.icon" class="ms-2 icon icon-xs" />
            </Toast>
        </div>
    </teleport>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import Toast from './Toast.vue'
import toastService, { ToastItem } from './ToastService';

const props = defineProps({
        removeAfterShown: {
            type: Boolean,
            default: true,
            required: false
        }
    });

const unShownToasts = computed(() => toastService.toasts.value.filter(t => !t.isShown));

function toastShown(toast: ToastItem){
    console.log('toastManager: toastShown');
    toast.isShown = true;

    //by default, toast item data will be removed.
    //if you don't want this behavior, for exmaple, you may want to keep a history of shown toasts to display to the user,
    //  then set removeAfterShown prop to false.
    //in either case, toast will be removed from the DOM.
    if (props.removeAfterShown){
        toastService.removeToast(toast.id);
    }

}
</script>
