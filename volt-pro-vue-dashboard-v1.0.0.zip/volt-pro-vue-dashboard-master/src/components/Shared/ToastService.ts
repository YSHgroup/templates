import { ref, type VNode } from "vue";
import _ from 'lodash'

export class ToastItem{
    isShown = false;

    constructor(
        public id: number,
        public title: string,
        public body: string,
        public icon?: VNode){}
}

class ToastService{
    readonly toasts = ref<ToastItem[]>([]);
    private counter = 0;

    public addToast(title: string, body: string, icon?: VNode){
        console.log('add toast');
        const toastItem = new ToastItem(
            this.counter++,
            title,
            body,
            icon);
        this.toasts.value.push(toastItem);
    }

    public removeToast(id: number){
        this.toasts.value = _.remove(this.toasts.value, t => t.id == id);
    }
}

export default new ToastService();