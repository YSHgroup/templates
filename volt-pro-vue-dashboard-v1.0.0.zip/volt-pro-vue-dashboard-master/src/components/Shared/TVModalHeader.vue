<template>
<div class="modal-header">
    <slot>
        <h5 class="modal-title">{{ title }}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </slot>
</div>
</template>

<script lang="ts" setup>

defineProps({
    title: {
        type: String,
        required: false
    }
})
</script>