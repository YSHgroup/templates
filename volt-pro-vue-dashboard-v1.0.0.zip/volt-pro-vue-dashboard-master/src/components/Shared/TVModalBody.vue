<template>
<div class="modal-body">
    <slot></slot>
</div>
</template>

<script lang="ts" setup>


</script>