<template>
    <div class="text-center mb-4" :class="sizeClasses">
        <div class="icon icon-shape bg-white shadow-lg rounded mb-4">
            <!-- <span><font-awesome-icon :icon="faIcon" /></span> -->
            <component :is="icon" class="icon icon-md text-secondary" />
        </div>
        <h3 class="fw-bolder">{{heading}}</h3>
        <p class="text-gray">{{subHeading}}</p>
    </div>
</template>

<script lang="ts" setup>
import type { PropType, VNode } from 'vue';


defineProps({
         sizeClasses: String,
         icon: {
             type: Object as PropType<VNode>,
             required: true
         },
         heading: String,
         subHeading: String
     });
</script>