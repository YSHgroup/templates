<template>
<div class="modal-footer">
    <slot>
        <button type="button" class="btn btn-link text-gray-600 ms-auto" data-bs-dismiss="modal">Close</button>
    </slot>
</div>
</template>