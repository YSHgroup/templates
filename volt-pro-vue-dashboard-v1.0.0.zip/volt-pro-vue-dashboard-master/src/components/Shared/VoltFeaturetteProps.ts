import type { IconDefinition } from "@fortawesome/fontawesome-svg-core";

export default interface VoltFeaturetteProp{
    sizeClasses: string;
    faIcon: IconDefinition;
    heading: string;
    subHeading: string;
}