<template>
    <div class="offcanvas" :class="[placementClass]" :data-bs-backdrop="backdrop" :data-bs-scroll="bodyScrolling" tabindex="-1" ref="elOffcanvas">    
        <slot v-if="!removeFromDomWhenHidden || showContent"></slot>
    </div>
</template>

<script lang="ts" setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { Offcanvas } from 'bootstrap'


const props = defineProps({
    placement: {
        type: String,
        default: 'left',
        required: false
    },
    backdrop: {
        type: Boolean,
        default: true,
        required: false
    },
    bodyScrolling: {
        type: Boolean,
        default: false,
        required: false
    },
    modelValue: {
        type: Boolean,
        default: false,
        required: false
    },
    removeFromDomWhenHidden: {
        type: Boolean,
        default: false,
        required: false
    }
});

const emit = defineEmits(['shown', 'hidden', 'update:modelValue'])

const elOffcanvas = ref<HTMLElement>();
const bsOffcanvas = ref<Offcanvas>();
const showContent = ref(false);
const placementClass = computed(() => {
    const placement = props.placement.toLowerCase();
    if (placement == 'top') return 'offcanvas-top';
    else if (placement == 'right') return 'offcanvas-end';
    else if (placement == 'bottom') return 'offcanvas-bottom';
    else return 'offcanvas-start';
});

//can be called by parent
async function show(){
    if (bsOffcanvas.value){
        showContent.value = true;
        await nextTick();
        bsOffcanvas.value.show();
    }
}

//can be called by parent
function hide(){
    if (bsOffcanvas.value){
        bsOffcanvas.value.hide();
    }
}

async function toggle(){
    if (bsOffcanvas.value){
        if (!showContent.value){
            showContent.value = true;
            await nextTick();
        }
        bsOffcanvas.value.toggle();
    }
}

onMounted(() => {
    if (elOffcanvas.value){
        bsOffcanvas.value = new Offcanvas(elOffcanvas.value);

        watch(() => props.modelValue, async () => {
            if (bsOffcanvas.value){
                if (props.modelValue){
                    showContent.value = true;
                    await nextTick();
                    bsOffcanvas.value.show();
                }
                else{
                    bsOffcanvas.value.hide();
                }
            }
        }, { immediate: true })

        elOffcanvas.value.addEventListener('hidden.bs.offcanvas', function() {
            emit('hidden');
            emit('update:modelValue', false);
            showContent.value = false;
        })

        elOffcanvas.value.addEventListener('shown.bs.offcanvas', function() {
            emit('shown');
        })
    }
});

onBeforeUnmount(() => {
    if (bsOffcanvas.value){
        bsOffcanvas.value.hide();
    }
})

defineExpose({
    show,
    hide,
    toggle
});
        
</script>
