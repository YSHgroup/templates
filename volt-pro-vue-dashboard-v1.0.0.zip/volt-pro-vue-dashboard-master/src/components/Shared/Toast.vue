<template>
    <div ref="elToast" class="toast bg-gray-300" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header" v-if="title">
            <BellIcon class="me-2 icon icon-xs" />
            <strong class="me-auto">{{ title }}</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            <slot></slot>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { Toast } from 'bootstrap'
import { BellIcon } from 'heroicons-vue3/outline'

defineProps({
        title: {
            type: String,
            required: false
        }
    });

const emit = defineEmits(['onShown']);
const elToast = ref<Element>();

onMounted(() => {
    if (elToast.value){
        const bsToast = new Toast(elToast.value);

        //show immediately
        console.log('about to show toast');
        bsToast.show();

        elToast.value.addEventListener('hidden.bs.toast', function () {
            console.log('toast hidden');
            emit('onShown');
        });
    }
})
</script>
