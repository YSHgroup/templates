export interface TVModalI{
    show(): void;
    hide(): void;
    toggle(): void;
}

export interface TVOffcanvasI{
    show(): void;
    hide(): void;
    toggle(): void;
}