<template>
     <div :class="sizeClasses">
        <div class="card bg-white shadow-soft text-primary rounded mb-4">
            <div class="px-3 px-lg-4 py-5 text-center">
                <span class="icon icon-md mb-3"><font-awesome-icon :icon="faIcon"/></span>
                <h5 class="fw-bold text-primary">{{ heading }}</h5>
                <p class="mb-0 text-gray-600">{{ subHeading }}</p>
            </div>
        </div>
    </div>
</template>

<script lang="ts">


export default {
    a: 'abc'
}
</script>

<script lang="ts" setup>
import type { IconDefinition } from "@fortawesome/fontawesome-svg-core";
import type { PropType } from "vue";


defineProps({
        sizeClasses: String,
        faIcon: Object as PropType<IconDefinition>,
        heading: String,
        subHeading: String
    });
</script>