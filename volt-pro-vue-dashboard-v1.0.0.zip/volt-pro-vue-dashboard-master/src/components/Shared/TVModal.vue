<template>
    <div class="modal" :class="{'fade': fade}" :data-bs-backdrop="backdrop" tabindex="-1" ref="elModal" role="dialog" aria-hidden="true">
        <div class="modal-dialog" :class="[{'modal-dialog-centered': centered}, dialogClasses]" role="document">
            <div class="modal-content" v-if="!removeFromDomWhenHidden || showContent">
                <slot></slot>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { Modal } from 'bootstrap'


const props = defineProps({
    fade: {
        type: Boolean,
        default: false,
        required: false
    },
    backdrop: {
        type: Boolean,
        default: true,
        required: false
    },
    centered: {
        type: Boolean,
        default: false,
        required: false
    },
    dialogClasses: {
        type: String,
        default: '',
        required: false
    },
    modelValue: {
        type: Boolean,
        default: false,
        required: false
    },
    removeFromDomWhenHidden: {
        type: Boolean,
        default: false,
        required: false
    }
});

const emit = defineEmits(['shown', 'hidden', 'update:modelValue'])

const elModal = ref<HTMLElement>();
const bsModal = ref<Modal>();
const showContent = ref(false);

//can be called by parent
async function show(){
    if (bsModal.value){
        showContent.value = true;
        await nextTick();
        bsModal.value.show();
    }
}

//can be called by parent
function hide(){
    if (bsModal.value){
        bsModal.value.hide();
    }
}

async function toggle(){
    if (bsModal.value){
        if (!showContent.value){
            showContent.value = true;
            await nextTick();
        }
        bsModal.value.toggle();
    }
}

onMounted(() => {
    if (elModal.value){
        bsModal.value = new Modal(elModal.value);

        watch(() => props.modelValue, async () => {
            if (bsModal.value){
                if (props.modelValue){
                    showContent.value = true;
                    await nextTick();
                    bsModal.value.show();
                }
                else{
                    bsModal.value.hide();
                }
            }
        }, { immediate: true })

        elModal.value.addEventListener('hidden.bs.modal', function() {
            emit('hidden');
            emit('update:modelValue', false);
            showContent.value = false;
        })

        elModal.value.addEventListener('shown.bs.modal', function() {
            emit('shown');
        })
    }
});

onBeforeUnmount(() => {
    if (bsModal.value){
        bsModal.value.hide();
    }
})

defineExpose({
    show,
    hide,
    toggle
});
        
</script>
