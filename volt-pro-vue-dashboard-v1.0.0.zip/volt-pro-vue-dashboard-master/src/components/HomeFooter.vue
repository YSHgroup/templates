<template>
  <footer class="footer py-6 bg-gray-800 text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <img
            class="navbar-brand-dark mb-4"
            height="35"
            src="@/assets/img/brand/light.svg"
            alt="Logo light"
          />
          <p class="text-gray-300">
            Volt Vue is a Premium Vue 3, Vite, Bootstrap 5 Admin Dashboard bringing together
            beautiful UI/UX design and functional elements.
          </p>
          <ul class="social-buttons mb-5 mb-lg-0">
            <li>
              <a
                href="https://twitter.com/themesberg"
                aria-label="twitter social link"
                class="d-flex align-item-center"
              >
                <span><font-awesome-icon :icon="faTwitter" class="icon icon-xs text-white"/></span>
              </a>
            </li>
            <li>
              <a
                href="https://www.facebook.com/themesberg/"
                class="d-flex align-item-center"
                aria-label="facebook social link"
              >
                <span ><font-awesome-icon :icon="faFacebook" class="icon icon-xs text-white"/></span>
              </a>
            </li>
            <li>
              <a
                href="https://github.com/themesberg"
                aria-label="github social link"
                class="d-flex align-item-center"
              >
                <span><font-awesome-icon :icon="faGithub" class="icon icon-xs text-white"/></span>
              </a>
            </li>
            <li>
              <a
                href="https://dribbble.com/themesberg"
                class="d-flex align-item-center"
                aria-label="dribbble social link"
              >
                <span><font-awesome-icon :icon="faDribbble" class="icon icon-xs text-white"/></span>
              </a>
            </li>
          </ul>
        </div>
        <div class="col-6 col-md-2 mb-5 mb-lg-0">
          <span class="h5">Themesberg</span>
          <ul class="links-vertical mt-2">
            <li>
              <a target="_blank" href="https://themesberg.com/blog">Blog</a>
            </li>
            <li>
              <a target="_blank" href="https://themesberg.com/products"
                >Products</a
              >
            </li>
            <li>
              <a target="_blank" href="https://themesberg.com/about"
                >About Us</a
              >
            </li>
            <li>
              <a target="_blank" href="https://themesberg.com/contact"
                >Contact Us</a
              >
            </li>
          </ul>
        </div>
        <div class="col-6 col-md-2 mb-5 mb-lg-0">
          <span class="h5">Other</span>
          <ul class="links-vertical mt-2">
            <li>
              <a
                href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/getting-started/quick-start/"
                target="_blank"
                >Docs
                <span class="badge badge-sm bg-secondary text-dark ms-2"
                  >v1.4</span
                ></a
              >
            </li>
            <li>
              <a
                href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/getting-started/changelog/"
                target="_blank"
                >Changelog</a
              >
            </li>
            <li>
              <a target="_blank" href="https://themesberg.com/licensing"
                >License</a
              >
            </li>
            <li>
              <a target="_blank" href="https://themesberg.com/contact"
                >Support</a
              >
            </li>
          </ul>
        </div>
        <div class="col-12 col-md-4 mb-5 mb-lg-0">
          <span class="h5 mb-3 d-block">Subscribe</span>
          <form action="#">
            <div class="form-row mb-2">
              <div class="col-12">
                <input
                  type="email"
                  class="form-control mb-2"
                  placeholder="example@company.com"
                  name="email"
                  aria-label="Subscribe form"
                  required
                />
              </div>
              <div class="col-12 d-grid">
                <button
                  type="submit"
                  class="btn btn-secondary"
                  data-loading-text="Sending"
                >
                  <span>Subscribe</span>
                </button>
              </div>
            </div>
          </form>
          <p class="text-muted font-small m-0">
            We’ll never share your details. See our
            <a class="text-white" href="#">Privacy Policy</a>
          </p>
        </div>
      </div>
      <hr class="bg-gray-700 my-5" />
      <div class="row">
        <div class="col mb-md-0">
          <a
            href="https://themesberg.com"
            target="_blank"
            class="d-flex justify-content-center"
          >
            <img
              src="@/assets/img/themesberg-logo-alt.svg"
              height="35"
              class="mb-4"
              alt="Themesberg Logo"
            />
          </a>
          <div
            class="d-flex text-center justify-content-center align-items-center"
            role="contentinfo"
          >
            <p class="fw-normal font-small mb-0">
              Copyright © Themesberg 2019-<span class="current-year">2021</span
              >. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script lang="ts" setup>
import { faTwitter, faFacebook, faGithub, faDribbble } from '@fortawesome/free-brands-svg-icons'

</script>