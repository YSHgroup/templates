<template>
  <router-link :to="item.routeInfo" class="list-group-item list-group-item-action border-bottom">
    <div class="row align-items-center">
      <div class="col-auto">
        <!-- Avatar -->
        <img alt="Image placeholder" :src="item.avatarImageSrc" class="avatar-md rounded" />
      </div>
      <div class="col ps-0 ms-2">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h4 class="h6 mb-0 text-small">{{ item.user }}</h4>
          </div>
          <div class="text-end">
            <small class="text-danger">{{ item.when }}</small>
          </div>
        </div>
        <p class="font-small mt-1 mb-0">
          {{ item.description }}
        </p>
      </div>
    </div>
  </router-link>
</template>
<script lang="ts" setup>
import type { PropType } from "vue";
import type { NotificationItem } from "@/services/NotificationService";

defineProps({
      item: {
        type: Object as PropType<NotificationItem>,
        required: true
      }
  });
</script>