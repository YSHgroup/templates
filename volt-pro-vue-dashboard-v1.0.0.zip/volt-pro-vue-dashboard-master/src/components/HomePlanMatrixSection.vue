<template>
    <section class="section bg-gray-800" ref="pricing">
            <div class="container">
                <div class="row justify-content-center text-white mb-6">
                    <div class="col-12 col-lg-9 text-center">
                        <h2 class="display-3 fw-light mb-4">Choose the right plan for your business</h2>
                        <p class="lead">You have at least <span class="fw-bold text-secondary">Free 6 Months of Updates</span> and <span class="fw-bold text-secondary">Premium Support</span> on each package. You also have 30 days to request a refund if you're not happy with your purchase.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-6 col-xl-4 mb-5">
                        <div class="card border-light rounded-md mb-3 px-2">
                            <div class="card-header bg-white border-light p-4">
                                <div class="d-flex mb-3"> <span class="h5 text-gray-600 me-2 mb-0">$</span> <span class="display-2 mb-0 fw-extrabold text-primary">89</span> </div>
                                <h3 class="h4 mb-3">Freelancer</h3>
                                <p class="fw-normal font-small mb-0">Great for personal use and for your side projects.</p>
                            </div>
                            <div class="card-body py-4">
                                <ul class="list-group simple-list">
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Full documentation</li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Domains: <strong>1</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Team size: <strong>1 developer</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Premium support: <strong>6 months</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Free updates: <strong>6 months</strong></li>
                                </ul>
                            </div>
                            <div class="card-footer d-grid bg-white border-0 pt-0 px-4 pb-4"><a href="https://themesberg.com/product/dashboard/volt-pro-vue#pricing" target="_blank" class="btn btn-secondary text-dark rounded"> Buy now <span class="icon icon-xs ms-3"></span> </a> </div>
                        </div> 
                        <a href="https://themesberg.com/licensing#freelancer" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="Something unclear? Click to read the full Freelancer license." class="font-small text-white text-center d-flex align-items-center justify-content-center mt-4"><span class="icon icon-xs fas fa-balance-scale me-2"></span>Freelancer License</a> 
                    </div>
                    <div class="col-12 col-lg-6 col-xl-4 mb-5">
                        <div class="card border-light rounded-md mb-3 px-2">
                            <div class="card-header bg-white border-light p-4">
                                <div class="d-flex mb-3"> <span class="h5 text-gray-600 me-2 mb-0">$</span> <span class="display-2 mb-0 fw-extrabold text-primary">399</span> </div>
                                <h3 class="h4 mb-3">Company</h3>
                                <p class="fw-normal font-small mb-0">Relevant for multiple users and extended support.</p>
                            </div>
                            <div class="card-body py-4">
                                <ul class="list-group simple-list">
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Full documentation</li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Domains: <strong>Unlimited</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Team size: <strong>1-5 developers</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Premium support: <strong>12 months</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Free updates: <strong>lifetime</strong></li>
                                </ul>
                            </div>
                            <div class="card-footer d-grid bg-white border-0 pt-0 px-4 pb-4"><a href="https://themesberg.com/product/dashboard/volt-pro-vue#pricing" target="_blank" class="btn btn-gray-800 rounded"> Buy now <span class="icon icon-xs ms-3"></span> </a> </div>
                        </div> 
                        <a href="https://themesberg.com/licensing#company" target="_blank" data-bs-toggle="tooltip" data-bs-placement="top" title="Something unclear? Click to read the full Company license." class="font-small text-white text-center d-flex align-items-center justify-content-center mt-4"><span class="icon icon-xs fas fa-balance-scale me-2"></span>Company License</a> 
                    </div>
                    <div class="col-12 col-lg-6 col-xl-4 mb-5">
                        <div class="card border-light rounded-md mb-3 px-2">
                            <div class="card-header bg-white border-light p-4">
                                <div class="d-flex mb-3"> <span class="h5 text-gray-600 me-2 mb-0">$</span> <span class="display-2 mb-0 fw-extrabold text-primary">1299</span> </div>
                                <h3 class="h4 mb-3">Enterprise</h3>
                                <p class="fw-normal font-small mb-0">Best for large scale uses and extended redistribution rights.</p>
                            </div>
                            <div class="card-body py-4">
                                <ul class="list-group simple-list">
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Full documentation</li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Domains: <strong>Unlimited</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Team size: <strong>Unlimited</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Premium support: <strong>24 months</strong></li>
                                    <li class="list-group-item fw-normal d-inline-flex align-items-center border-0"><span class="icon icon-xxs text-success me-2"><span><font-awesome-icon :icon="faCheck"/></span></span>Free updates: <strong>lifetime</strong></li>
                                </ul>
                            </div>
                            <div class="card-footer d-grid bg-white border-0 pt-0 px-4 pb-4"><a href="https://themesberg.com/product/dashboard/volt-pro-vue#pricing" target="_blank" class="btn btn-gray-800 rounded"> Buy now <span class="icon icon-xs ms-3"></span> </a> </div>
                        </div> 
                        <a href="https://themesberg.com/licensing#enterprise" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Something unclear? Click to read the full Enterprise license." class="font-small text-white text-center d-flex align-items-center justify-content-center mt-4"><span class="icon icon-xs fas fa-balance-scale me-2"></span>Enterprise License</a> 
                    </div>
                </div>
                <div class="mt-lg-4 row">
                    <div class="text-center col-12">
                       <h2 class="h5 text-white fw-normal mb-4">Available in the following technologies:</h2>
                       <div>
                            <a class="me-3 card-link" href="https://themesberg.com/product/dashboard/volt-pro-vue" target="_blank">
                                <img src="@/assets/img/technologies/bootstrap-5-logo.svg" class="image image-sm" />
                            </a>
                            <a class="me-3 card-link" href="https://themesberg.com/product/dashboard/volt-pro-react" target="_blank">
                                <img src="@/assets/img/technologies/react-logo.svg" class="image image-sm" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</template>

<script lang="ts" setup>
import {faCheck} from '@fortawesome/free-solid-svg-icons';

</script>