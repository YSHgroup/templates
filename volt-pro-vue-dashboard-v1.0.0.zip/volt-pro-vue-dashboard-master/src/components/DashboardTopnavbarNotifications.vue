<template>
      <li class="nav-item dropdown">
            <a class="nav-link text-dark notification-bell unread dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" ref="iconNotifications">      
                <span class="bell-shake" :class="{'shaking': keepShaking}">
                    <font-awesome-icon :icon="faBell" class="icon icon-sm text-gray-900"/>
                </span>
                <span class="icon-badge rounded-circle unread-notifications" v-show="hasUnreadNotifications"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-center mt-2 py-0">
              <div class="list-group list-group-flush">
                <a href="#" class="text-center text-primary fw-bold border-bottom border-light py-3">Notifications</a>
                <DashboardTopnavbarNotificationsItem v-for="(item, i) in notifications" :key="i" :item="item" />
                <router-link :to="{name: 'DashboardMessages'}" class="dropdown-item text-center fw-bold rounded-bottom py-3"><EyeIcon class="icon icon-xxs"/> View all</router-link>
              </div>
            </div>
          </li>
</template>

<script lang="ts" setup>
import { onMounted, ref } from "vue";
import {notifications} from '@/services/NotificationService'
import DashboardTopnavbarNotificationsItem from '@/components/DashboardTopnavbarNotificationsItem.vue'
import { faBell } from '@fortawesome/free-solid-svg-icons'
import { EyeIcon } from 'heroicons-vue3/solid'

const iconNotifications = ref<HTMLAnchorElement>();
const hasUnreadNotifications = ref(true);
const keepShaking = ref(true);

// bell shake
const shakingInterval = setInterval(function() {
    if (hasUnreadNotifications.value) {
        keepShaking.value = !keepShaking.value
    }
}, 5000);

onMounted(() => {
    iconNotifications.value?.addEventListener('show.bs.dropdown', function () {
        hasUnreadNotifications.value = false;
        keepShaking.value = false;
        clearInterval(shakingInterval);
    });
})
</script>