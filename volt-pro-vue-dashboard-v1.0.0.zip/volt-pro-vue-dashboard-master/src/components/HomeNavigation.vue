<template>
    <header class="header-global">
        <nav id="navbar-main" aria-label="Primary navigation" class="navbar navbar-main navbar-expand-lg navbar-theme-primary pt-4" :class="classes" >
            <div class="container position-relative">
                <div class="navbar-collapse collapse me-auto" id="navbar_global">
                    <div class="navbar-collapse-header">
                        <div class="row">
                            <div class="col-6 collapse-brand">
                                <router-link :to="{name: 'Home'}">
                                    <img src="@/assets/img/brand/light.svg" alt="Volt logo">
                                </router-link>
                            </div>
                            <div class="col-6 collapse-close">
                                <a href="#navbar_global" class="fas fa-times" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" title="close" aria-label="Toggle navigation"></a>
                            </div>
                        </div>
                    </div>
                    <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
                        <li class="nav-item me-2">
                            <router-link :to="{name: 'DashboardOverview'}" class="nav-link">Dashboard</router-link>
                        </li>
                        <li class="nav-item me-2">
                            <router-link :to="{name: 'DashboardPricing'}" class="nav-link">Pricing</router-link>
                        </li>
                        <li class="nav-item me-2">
                            <router-link :to="{name: 'SignIn'}" class="nav-link">Login</router-link>
                        </li>
                        <li class="nav-item me-2">
                            <router-link :to="{name: 'SignUp'}" class="nav-link">Register</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'Lock'}" class="nav-link">Lock</router-link>
                        </li>
                    </ul>
                </div>
                <div class="d-flex align-items-center ms-auto">
                    <a href="https://themesberg.com/product/dashboard/volt-pro-vue" class="btn btn-secondary text-dark me-md-3"><font-awesome-icon :icon="iconShoppingCart" class="me-2"/> Buy now</a>
                </div>
            </div>
        </nav>
    </header>
</template>

<script lang="ts" setup>
import { faShoppingCart as iconShoppingCart } from '@fortawesome/free-solid-svg-icons';

defineProps<{
    classes: string[]
}>()
</script>

