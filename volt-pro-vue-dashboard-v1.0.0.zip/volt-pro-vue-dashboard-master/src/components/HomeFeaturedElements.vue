<template>
  <div class="row justify-content-between align-items-center mb-5 mb-lg-7">
    <div class="col-lg-5 order-lg-2 mb-5 mb-lg-0">
      <h2 class="h1">Mapbox</h2>
      <p class="mb-4 lead fw-bold">
        Markers and cards integration with Leaflet.js
      </p>
      <p class="mb-4">
        You can use this map to add markers with custom cards and show them on a
        map using our custom MapBox integration with Leaflet.js
      </p>
      <router-link
        :to="{name: 'DashboardMap'}"
        target="_blank"
        class="btn btn-secondary d-inline-flex align-items-center me-3"
        ><span class="me-2"><font-awesome-icon :icon="mapIcon"/></span> Demo</router-link
      >
      <a
        href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/plugins/mapbox/"
        target="_blank"
        class="btn btn-outline-gray-600 d-inline-flex align-items-center"
        ><span class="me-2"><font-awesome-icon :icon="bookIcon"/></span> Guide</a
      >
    </div>
    <div class="col-lg-6 order-lg-1">
      <img
        src="@/assets/img/mockup-map-presentation.png"
        alt="MapBox Leaflet.js Custom Integration Mockup"
      />
    </div>
  </div>
  <div class="row justify-content-between align-items-center mb-5 mb-lg-7">
    <div class="col-lg-5 mb-5 mb-lg-0">
      <h2 class="h1">Calendar</h2>
      <p class="mb-4 lead fw-bold">Advanced FullCalendar.js integration</p>
      <p class="mb-4">
        We created a fully editable calendar where you can add, edit and delete
        events for your admin dashboard.
      </p>
      <router-link
        :to="{name: 'DashboardCalendar'}"
        target="_blank"
        class="btn btn-secondary d-inline-flex align-items-center me-3"
        ><span class="me-2"><font-awesome-icon :icon="calendarIcon"/></span> Demo</router-link
      >
      <a
        href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/plugins/calendar/"
        target="_blank"
        class="btn btn-outline-gray-600 d-inline-flex align-items-center"
        ><span class="me-2"><font-awesome-icon :icon="bookIcon"/></span> Guide</a
      >
    </div>
    <div class="col-lg-6">
      <img
        src="@/assets/img/mockup-calendar-presentation.png"
        alt="Calendar Preview"
      />
    </div>
  </div>
  <div class="row justify-content-between align-items-center">
    <div class="col-lg-5 order-lg-2 mb-5 mb-lg-0">
      <h2 class="h1">Bootstrap 5</h2>
      <p class="mb-4 lead fw-bold">
        Latest version of Bootstrap without jQuery
      </p>
      <p class="mb-4">
        Volt is built using the latest version of Bootstrap 5 and we only used
        Vanilla Javascript for everything including the plugins
      </p>
      <a
        href="https://themesberg.com/docs/volt-bootstrap-5-dashboard/components/accordions/"
        target="_blank"
        class="btn btn-outline-gray-600 d-inline-flex align-items-center"
        ><span class="me-2"><font-awesome-icon :icon="bookIcon"/></span> Getting started</a
      >
    </div>
    <div class="col-lg-6 order-lg-1">
      <img
        src="@/assets/img/illustrations/bs5-illustrations.svg"
        alt="Front pages overview"
      />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { faTh as kanbanIcon, faMapMarkedAlt as mapIcon, faBook as bookIcon } from '@fortawesome/free-solid-svg-icons';
import { faCalendarAlt as calendarIcon } from '@fortawesome/free-regular-svg-icons';

</script>