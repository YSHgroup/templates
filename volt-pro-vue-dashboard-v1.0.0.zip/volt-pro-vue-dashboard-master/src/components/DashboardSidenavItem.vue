<template>
    <li v-if="item.url" class="nav-item">
        <a class="nav-link" target="_blank" :href="item.url">
            <span class="sidebar-text-contracted">{{ item.minimizedText }}</span>
            <span class="sidebar-text">{{ item.title }}</span>
        </a>
    </li>
    <router-link v-else-if="!hasChildren && item.routeName" custom
        :to="{name: item.routeName}"
        v-slot="{ href, navigate, isExactActive }">
        <li class="nav-item"
            :class="[isExactActive && 'active']">
            <a :href="href" @click="navigate" class="nav-link d-flex align-items-center justify-content-between">
                <span>
                    <span v-if="item.iconImage" class="sidebar-icon">
                        <img :src="item.iconImage" height="23" width="23" :alt="item.iconImageAlt">
                    </span> 
                    <span v-else-if="item.icon" class="sidebar-icon"><font-awesome-icon :icon="item.icon"/></span>
                    <span v-else-if="item.heroIcon" class="sidebar-icon">
                        <component :is="item.heroIcon" class="icon icon-xs me-2" />
                    </span>
                    <span v-if="item.minimizedText" class="sidebar-text-contracted">{{ item.minimizedText }}</span>
                    <span class="sidebar-text">{{ item.title }}</span>
                    <span v-if="item.badge" class="badge">{{ item.badge }}</span>
                </span>
                <span v-if="item.notificationCount" class="badge badge-sm bg-danger badge-pill notification-count">{{ item.notificationCount }}</span>
            </a>
        </li>
    </router-link>
    <li v-else class="nav-item">
        <span class="nav-link d-flex justify-content-between align-items-center" data-bs-toggle="collapse" :data-bs-target="'#' + subMenuId" role="button" :aria-expanded="showChildren" :aria-controls="subMenuId">
            <span>
                <span class="sidebar-icon">
                    <font-awesome-icon v-if="item.icon" :icon="item.icon" class="icon icon-xs me-2"/>
                    <component :is="item.heroIcon" v-if="item.heroIcon" class="icon icon-xs me-2" />
                </span> 
                <span class="sidebar-text">{{ item.title }}</span>
                <span v-if="item.badge" class="badge">{{ item.badge }}</span>
            </span>
            <span class="link-arrow"><font-awesome-icon :icon="faChevronRight" class="icon icon-sm"/></span> 
        </span>
        <div class="multi-level collapse" :class="{'show': showChildren}" role="list" :id="subMenuId">
            <ul class="nav flex-column">
                <DashboardSidenavItem v-for="(childItem) in item.children" :key="childItem.id" :item="childItem" />
            </ul>
        </div>
    </li>
</template>

<script lang="ts" setup>
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";
import { computed, ref } from "vue";
import router from '@/router'
import type SidenavItem from "./DashboardSidenavItemProps";

const props = defineProps<{
        item: SidenavItem
}>();
const showChildren = ref(false);
const hasChildren = computed(() => {
            if (props.item?.children?.length){
                return props.item.children.length > 0
            }
            return false;
        });
const subMenuId = computed(() => `subMenu-${props.item.id}`);

function isItemRouteActive(item: SidenavItem){
    if (router.currentRoute.value.name === item.routeName){
        showChildren.value = true;
        return;
    }
    item.children?.forEach(isItemRouteActive);
}

//determine if the current route is active for any descendents and if so show children
isItemRouteActive(props.item);
</script>