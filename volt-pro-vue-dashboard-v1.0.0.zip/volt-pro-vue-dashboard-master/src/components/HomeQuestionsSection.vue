<template>
            <section class="section section-lg bg-soft">
            <div class="container">
                <h2 class="border-bottom border-gray-300 mb-5 pb-3">Got questions?</h2>
                <div class="row faq-section">
                   <div class="col-12 col-md-6">
                      <div class="mb-5">
                         <h4 class="h5">How do I use the license that I got with my purchase?</h4>
                         <p>You will receive a code in your order receipt. You do not need to insert it anywhere. Please keep it in your records for any future inquiry from us. If you create a client project, you can either keep this code or you can send us an email using our <a class="text-dark fw-bold text-underline" href="https://themesberg.com/contact">contact page</a>, and we will transfer the license to your client, provided that they have an account on our website.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What is the difference between the Freelancer/Company/Enterprise licenses?</h4>
                         <p>The Freelancer license is aimed at people who work on their own. It grants you the right to use the purchased product only for one project (either yours or for a client).</p>
                         <p>The Company license is aimed at agencies or larger teams. It grants you the right to create other licensed products base on the template that you purchase from us.</p>
                         <p>The Enterprise license is aimed at large companies with multiple projects. It grants you the right to create any kind of software, SaaS, digital products and sell them.</p>
                         <p>All the differences between the types of licenses are <a class="text-dark fw-bold text-underline" href="https://themesberg.com/licensing">available here</a>.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">Will I get an update to Bootstrap 5 for the Bootstrap 4 themes?</h4>
                         <p>Although two of the products (Pixel Pro and Volt Pro) are already available in Bootstrap 5, we will update all of the themes in this Cyber Monday promotion to Bootstrap 5 in the next 6 months for free.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">Are the themes available with only classic CSS and without Sass as well?</h4>
                         <p>Yes, they are. Each theme has a <code class="text-dark fw-bold">html&amp;css</code> folder which contains the theme with classic HTML, CSS, and Javascript files.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">Do these themes work with Wordpress?</h4>
                         <p>These products are not Wordpress themes, however, they can be integrated in Wordpress by an experienced web developer.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">Are the images, fonts, and icons free to use?</h4>
                         <p>The images, fonts, icons and every other creative element for each theme can be freely used in your project under our licensing terms.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">If I purchased a Freelancer/Company License, how can I upgrade to the Company/Enterprise License?</h4>
                         <p>In case you have already purchased a license, but you want to upgrade, you can just send us a message using the <a class="text-dark fw-bold text-underline" href="https://themesberg.com/contact" target="_blank">contact page</a> and we will send you a discount code so you will only pay the difference for the upgrade.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What does the Included Documentation feature refer to?</h4>
                         <p>It means that each theme within the Cyber Monday promotion has a thorough and up to date documentation on how to get started with the product and each components and plugin is properly explained.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What happens after the 6/12/24 months of Free Updates expires? Can I download the new updates after this period?</h4>
                         <p>At the end of this period, you will need to renew your license (purchase the product again) to get Support.</p>
                      </div>
                      <div>
                         <h4 class="h5">Can I remove the copyright notice from the files?</h4>
                         <p>You can remove the copyright notice (if it's a premium item), but then you will need to create a separate <code class="text-dark fw-bold">.txt</code> file called <code class="text-dark fw-bold">LICENSE.txt</code>, and copy paste the copyright text in there. This file should be added to the root folder of your project.</p>
                      </div>
                   </div>
                   <div class="col-12 col-md-6">
                      <div class="mb-5">
                         <h4 class="h5">What does the full code feature refer to?</h4>
                         <p>It refers to the fact that you will get all of the Sass, HTML, Javascript, and CSS files of the template.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What does the Domains number refer to?</h4>
                         <p>Depending on the license you purchase, you can use our products to either code a website/web application for you, for a client, or for multiple clients, which will be hosted on one or multiple domains:</p>
                         <p>For example, if you purchased the Freelancer License, you can create only one website (for you or a client). If you want to create multiple websites, you will need a bigger license (like Company or Enterprise). Same, if you have multiple subdomains, like test.yoursite.com (http://test.yoursite.com/) or dev.yoursite.com (http://dev.yoursite.com/), you can use the Freelancer or Startup License.</p>
                         <p>If you have a complex application like a SaaS and have client1.yoursite.com (http://client1.yoursite.com/) and client2.yoursite.com (http://client2.yoursite.com/) and clientx.yoursite.com, (http://clientx.yoursite.com/) you will need a multi-domain license like Company or Enterprise.</p>
                         <p>For more information about our licenses, you can <a class="text-dark fw-bold text-underline" href="https://themesberg.com/licensing">check it here</a>.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What does the Team Size refer to?</h4>
                         <p>The Team size for each license reflects the number of people who can access the product.</p>
                         <p>For example, if you buy the Freelancer license, only one person can use the product. If you have a team of 6-10 people, you will need the Company license.</p>
                         <p>For bigger teams of 5 developers, you will need to purchase an Enterprise License.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What does the Tech Support refer to?</h4>
                         <p>Depending on your license type, you have a fixed period when you can submit any ticket to us regarding product functionalities and bug fixes (learning and tutorials related requests are not included). You will get responses directly from the product's creators in 24 hours (during business days):</p>
                         <p>If you purchase the Freelancer license, you will receive Support from us for 6 months. If you need 12 months of Support, you will need the Company license.</p>
                         <p>If you purchase the Enterprise license, you will benefit from 24 months of Support. At the end of this period, you will need to renew your license (purchase the product again) to get Support.</p>
                      </div>
                      <div class="mb-5">
                         <h4 class="h5">What does the Free Updates refer to?</h4>
                         <p>Depending on your license type, you have a determined period when you receive product Updates that include bug fixes and new features:</p>
                         <p>Freelancer: You will receive Free Updates for 6 months. Company: You will receive Free Updates for 12 months. Enterprise: You will benefit from 24 months of Free Updates.</p>
                      </div>
                      <div>
                         <h4 class="h5">Do you have a question?</h4>
                         <p class="mb-0">Feel free to send us a message using the <a class="text-dark fw-bold text-underline" href="https://themesberg.com/contact" target="_blank">contact page</a> and one of our team members will get back to you in the shortest time possible.</p>
                      </div>
                   </div>
                </div>
                <div class="row mt-lg-5 mt-5">
                    <div class="col text-center">
                        <p class="text-italic">Didn't find what you were looking for? No biggie!</p>
                        <a href="https://themesberg.com/contact" class="btn btn-sm btn-secondary" target="_blank">Contact us</a>
                    </div>
                </div>
            </div>
        </section>
</template>