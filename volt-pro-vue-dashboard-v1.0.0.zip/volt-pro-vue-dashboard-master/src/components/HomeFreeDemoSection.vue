<template>
  <section class="section section-lg bg-white">
    <div class="container">
      <div class="row">
        <div class="col-12 col-lg-8">
          <h2 class="h1 fw-bold mb-3">Free Demo</h2>
          <p class="lead mb-4">
            Would you like to test out Volt Bootstrap 5 Dashboard before
            purchasing it? You're in luck, because we have an open source
            version of Volt that you can set up and try it out.
          </p>
          <div class="d-flex align-items-center">
            <a
              href="https://github.com/themesberg/volt-bootstrap-5-dashboard"
              target="_blank"
              class="btn btn-gray-800 me-4"
            >
              View on GitHub
            </a>
            <!-- Place this tag where you want the button to render. -->
            <div class="mt-2">
              <!-- Place this tag where you want the button to render. -->
              <a
                class="github-button"
                href="https://github.com/themesberg/volt-bootstrap-5-dashboard"
                data-color-scheme="no-preference: dark; light: light; dark: light;"
                data-icon="octicon-star"
                data-size="large"
                data-show-count="true"
                aria-label="Star /themesberg/volt-bootstrap-5-dashboard on GitHub"
                >Star</a
              >
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-4">
          <div class="github-big-icon">
            <font-awesome-icon :icon="faGithub" style="width:auto;"/>
          </div>
        </div>
      </div>
      <div class="row mt-6">
        <div class="col-12 col-md-6 col-lg-4 mb-5 mb-lg-0">
          <div class="card shadow border-0 p-4">
            <!-- Header -->
            <div class="card-header bg-white border-0 pb-0">
              <span class="d-block">
                <span class="h2 text-primary fw-bold align-top">Free Demo</span>
              </span>
            </div>
            <!-- End Header -->
            <!-- Content -->
            <div class="card-body">
              <ul class="list-group list-group-flush price-list">
                <li class="list-group-item border-0 ps-0">
                  <strong>100</strong> Components
                </li>
                <li class="list-group-item border-0 ps-0">
                  <strong>11</strong> Example Pages
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  Advanced sidebar
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  Kanban Drag and Drop
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  MapBox
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  Calendar
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  SVG Map
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  Widgets
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0 pb-0">
                 <font-awesome-icon :icon="faTimesCircle" class="icon icon-xs text-danger me-2"/>
                  Premium Support
                </li>
              </ul>
            </div>
            <!-- End Content -->
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 mb-5 mb-lg-0">
          <div class="card shadow border-0p-4 py-5 mt-lg-n5">
            <!-- Header -->
            <div class="card-header bg-white border-0 pb-0">
              <span class="d-block">
                <span class="h2 text-primary fw-bold align-top"
                  >Pro Version</span
                >
              </span>
            </div>
            <!-- End Header -->
            <!-- Content -->
            <div class="card-body">
              <ul class="list-group list-group-flush price-list">
                <li class="list-group-item bg-white border-0 ps-0">
                  <strong>1000+</strong> Components
                </li>
                <li class="list-group-item bg-white border-0 ps-0">
                  <strong>21</strong> Example Pages
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  Advanced sidebar
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  Kanban Drag and Drop
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  MapBox
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  Calendar
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  SVG Map
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  Widgets
                </li>
                <li class="list-group-item d-flex align-items-center border-0 ps-0 pb-0">
                  <font-awesome-icon :icon="faCheckCircle" class="icon icon-xs text-success me-2"/>
                  Premium Support
                </li>
              </ul>
            </div>
            <!-- End Content -->
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { faGithub } from '@fortawesome/free-brands-svg-icons'
import { faTimesCircle, faCheckCircle } from '@fortawesome/free-solid-svg-icons'

</script>