<template>
  <nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse" data-simplebar ref="sidebar" :class="{'contracted': sidebarStore.isCollapsed && hoverCollapsed, 'notransition': !showTransition}">
    <div class="sidebar-inner px-4 pt-3">
      <div
        class="user-card d-flex d-md-none justify-content-between justify-content-md-center pb-4"
      >
        <div class="d-flex align-items-center">
          <div class="avatar-lg me-4">
            <img
              src="@/assets/img/team/profile-picture-3.jpg"
              class="card-img-top rounded-circle border-white"
              alt="Bonnie Green"
            />
          </div>
          <div class="d-block">
            <h2 class="h5 mb-3">Hi, Jane</h2>
            <router-link :to="{ name: 'SignIn' }" class="btn btn-secondary btn-sm d-inline-flex align-items-center">
              <LogoutIcon class="icon icon-xxs me-1" />
              Sign Out
            </router-link>
          </div>
        </div>
        <div class="collapse-close d-md-none">
          <a
            href="#sidebarMenu"
            data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu"
            aria-controls="sidebarMenu"
            aria-expanded="true"
            aria-label="Toggle navigation">
            <font-awesome-icon class="icon icon-xs" :icon="faTimes"/>
          </a>
        </div>
      </div>
      <ul class="nav flex-column pt-3 pt-md-0 mt-1">
        <DashboardSidenavItem
          v-for="item in navItems"
          :key="item.id"
          :item="item"
        />
      </ul>
    </div>
  </nav>
</template>

<script lang="ts" setup>
import { h, onMounted, ref } from "vue";
import DashboardSidenavItem from "./DashboardSidenavItem.vue";
import type SidenavItem from "./DashboardSidenavItemProps";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import { LogoutIcon, ChartPieIcon, InboxInIcon, UsersIcon, CreditCardIcon, ClipboardListIcon,
        CogIcon, CalendarIcon, LocationMarkerIcon, SparklesIcon, TableIcon, NewspaperIcon,
        ArchiveIcon, TemplateIcon } from 'heroicons-vue3/solid';
import voltIconUrl from '@/assets/img/vue-logo.svg';
import { useSidebarStore } from "@/stores/sidebar";

const navItems = ref<SidenavItem[]>([]);
const showTransition = ref(false);
const hoverCollapsed = ref(true);
const sidebar = ref<HTMLElement>()
const sidebarStore = useSidebarStore();

function initNavItems(){
  navItems.value.push(
      {
        id: "volt-overview",
        routeName: "Home",
        iconImage: voltIconUrl,
        title: "Volt Pro Vue",
      },
      {
        id: "dashboard",
        heroIcon: h(ChartPieIcon),
        title: "Dashboard",
        children: [
          {
            id: "overview",
            routeName: "DashboardOverview",
            minimizedText: "O",
            title: "Overview",
          },
          {
            id: "traffic",
            routeName: "DashboardTrafficSources",
            minimizedText: "T",
            title: "All Traffic",
          },
          {
            id: "product-analysis",
            routeName: "DashboardAppAnalysis",
            minimizedText: "P",
            title: "Product Analysis",
          },
        ]
      },
      {
        id: 'messages',
        routeName: "DashboardMessages",
        heroIcon: h(InboxInIcon),
        title: 'Messages',
        notificationCount: 4
      },
      {
        id: 'users',
        routeName: 'DashboardUsersList',
        heroIcon: UsersIcon,
        title: 'Users'
      },
      {
        id: 'transactions',
        routeName: 'DashboardTransactions',
        heroIcon: CreditCardIcon,
        title: 'Transactions'
      },
      {
        id: 'tasks',
        routeName: 'DashboardTasks',
        heroIcon: ClipboardListIcon,
        title: 'Task List'
      },
      {
        id: 'settings',
        routeName: 'DashboardSettings',
        heroIcon: CogIcon,
        title: 'Settings'
      },
      {
        id: 'calendar',
        routeName: 'DashboardCalendar',
        heroIcon: CalendarIcon,
        title: 'Calendar'
      },
      {
        id: 'map',
        routeName: "DashboardMap",
        heroIcon: LocationMarkerIcon,
        title: 'Map'
      },
      {
        id: "tables",
        heroIcon: TableIcon,
        title: "Tables",
        children: [
          {
            id: "datatables",
            routeName: "DashboardDatatables",
            minimizedText: "D",
            title: "DataTables",
          },
          {
            id: "bootstrapTables",
            routeName: "DashboardBootstrapTables",
            minimizedText: "B",
            title: "Bootstrap Tables",
          }
        ]
      },
      {
        id: 'pageExamples',
        heroIcon: NewspaperIcon,
        title: "Page Examples",
        children: [
          {
            id: 'pricing',
            routeName: 'DashboardPricing',
            minimizedText: 'P',
            title: 'Pricing'
          },
          {
            id: 'billing',
            routeName: 'DashboardBilling',
            minimizedText: 'B',
            title: 'Billing'
          },
          {
            id: 'invoice',
            routeName: 'DashboardInvoice',
            minimizedText: 'I',
            title: 'Invoice'
          },
          {
            id: 'signIn',
            routeName: 'SignIn',
            minimizedText: 'S',
            title: 'Sign In'
          },
          {
            id: 'signUp',
            routeName: 'SignUp',
            minimizedText: 'S',
            title: 'Sign Up'
          },
          {
            id: 'forgotPassword',
            routeName: 'ForgotPassword',
            minimizedText: 'F',
            title: 'Forgot Password'
          },
          {
            id: 'resetPassword',
            routeName: 'ResetPassword',
            minimizedText: 'R',
            title: 'Reset Password'
          },
          {
            id: 'lock',
            routeName: 'Lock',
            minimizedText: 'L',
            title: 'Lock'
          },
          {
            id: '404',
            routeName: '404',
            minimizedText: '4',
            title: '404 Not Found'
          },
          {
            id: '500',
            routeName: '500',
            minimizedText: '5',
            title: '500 Error'
          }
        ]
      },
      {
        id: 'components',
        heroIcon: ArchiveIcon,
        title: 'Components',
        children: [
          {
            id: 'componentOverview',
            minimizedText: 'O',
            title: 'Overview',
            routeName: 'ComponentsOverview'
          },
          {
            id: 'accordion',
            minimizedText: 'A',
            title: 'Accordion',
            routeName: 'ComponentsAccordion'
          },
          {
            id: 'buttons',
            minimizedText: 'B',
            title: 'Buttons',
            routeName: 'DashboardButtons'
          },
          {
            id: 'notifications',
            minimizedText: 'N',
            title: 'Notfications',
            routeName: 'DashboardNotifications'
          },
          {
            id: 'forms',
            minimizedText: 'F',
            title: 'Forms',
            routeName: 'DashboardForms'
          },
          {
            id: 'modals',
            minimizedText: 'M',
            title: 'Modals',
            routeName: 'DashboardModals'
          },
           {
            id: 'All Components',
            minimizedText: 'A',
            title: 'All Components',
            url: 'https://themesberg.com/docs/volt-bootstrap-5-dashboard/components/accordions/'
          }
        ]
      },
      {
        id: 'vue-components',
        title: 'Vue Components',
        heroIcon: SparklesIcon,
        children: [
          {
            id: 'vueModal',
            minimizedText: 'VM',
            title: 'Vue Modal',
            badge: 'custom',
            routeName: 'DashboardVueModal'
          },
          {
            id: 'vueOffcanvas',
            minimizedText: 'VO',
            title: 'Vue Offcanvas',
            badge: 'custom',
            routeName: 'DashboardVueOffcanvas'
          },
          {
            id: 'vueToast',
            minimizedText: 'VT',
            title: 'Vue Toast',
            badge: 'custom',
            routeName: 'DashboardVueToast'
          }
        ]
      },
      {
        id: 'widgets',
        routeName: 'DashboardWidgets',
        heroIcon: TemplateIcon,
        title: 'Widgets'
      },
      {
        id: 'getting-started',
        title: 'Getting Started',
        children: [
          {
            id: 'overview',
            minimizedText: 'O',
            title: 'Overview',
            routeName: 'DashboardGettingStartedOverview'
          },
           {
            id: 'quickstart',
            minimizedText: 'Q',
            title: 'Quick Start',
            routeName: 'DashboardGettingStartedQuickStart'
          },
           {
            id: 'license',
            minimizedText: 'L',
            title: 'License',
            routeName: 'DashboardGettingStartedLicense'
          },
          {
            id: 'folderStructure',
            minimizedText: 'F',
            title: 'Folder Structure',
            routeName: 'DashboardGettingStartedFolderStructure'
          },
          {
            id: 'changelog',
            minimizedText: 'C',
            title: 'Changelog',
            routeName: 'DashboardGettingStartedChangelog'
          },
          {
            id: 'resources',
            minimizedText: 'R',
            title: 'Resources',
            routeName: 'DashboardGettingStartedResources'
          }
        ]
      }

      // {
      //     id: 'transactions',
      //     routeName: 'DashboardTransactions',
      //     iconClasses: 'fas fa-hand-holding-usd',
      //     title: 'Transactions'
      // },
      // {
      //     id: 'settings',
      //     routeName: 'DashboardSettings',
      //     iconClasses: 'fas fa-cog',
      //     title: 'Settings'
      // },
      // {
      //     id: 'tables',
      //     routeName: 'DashboardTables',
      //     iconClasses: 'fas fa-table',
      //     title: 'Tables',
      //     children: [{
      //         id: 'bootstrapTables',
      //         routeName: 'DashboardTablesBootstrap',
      //         iconClasses: '',
      //         title: 'Bootstrap Tables'
      //     }]
      // }
    );


}


initNavItems();

onMounted(() => {
  if (!sidebar.value){
    return;
  }
  sidebar.value.addEventListener('shown.bs.collapse', function () {
    if (document.body.clientWidth < 960){
        (document.querySelector('body') as HTMLElement).style.position = 'fixed';
    }
  });

  sidebar.value.addEventListener('hidden.bs.collapse', function () {
    if (document.body.clientWidth < 960){
      (document.querySelector('body') as HTMLElement).style.position = 'relative';
    }
  });

  sidebar.value.addEventListener('mouseenter', () => {
    if (sidebarStore.isCollapsed){
      hoverCollapsed.value = false;
    }
  });

  sidebar.value.addEventListener('mouseleave', () => {
    if (sidebarStore.isCollapsed){
      hoverCollapsed.value = true;
    }
  })

  setTimeout(() => {
    showTransition.value = true;
  }, 500);

});
</script>