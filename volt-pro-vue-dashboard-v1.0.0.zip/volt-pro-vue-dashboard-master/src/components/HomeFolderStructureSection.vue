<template>
    <section class="section section-lg line-bottom-soft">
            <div class="container">
                <div class="row justify-content-center mb-5 mb-lg-6">
                    <div class="col-12 text-center">
                        <h2 class="h1 px-lg-5">What's inside?</h2>
                        <p class="lead px-lg-8">We scaffolded using <code>create-vue</code> so our folder structure is recommended by the Vue core team</p>
                    </div>
                </div>
                <div class="row d-flex align-items-center">
                    <div class="col-12 col-lg-6 mb-4">
                        <div class="d-none d-lg-block mt-5">
                            <h4>Vue 3 recommended folder structure</h4>
                            <p class="lead mb-4">This project was scaffolded from the latest version of <code>create-vue</code> using <code>npm init vue@latest</code></p>
                            <router-link :to="{name: 'DashboardGettingStartedFolderStructure'}" class="btn btn-secondary d-inline-flex align-items-center"><font-awesome-icon :icon="['fas', 'book']" class="me-2"/> Docs</router-link>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 order-lg-first d-flex justify-content-center">
                        <ul class="d-block fmw-100 list-unstyled folder-structure">
                            <li data-bs-toggle="tooltip" data-bs-placement="left" title="Assets that will be copied to output folder"><font-awesome-icon :icon="faFolder" class="icon icon-sm me-2"/>public</li>
                            <li data-bs-toggle="tooltip" data-bs-placement="left" title="Main folder that you will be working with"><font-awesome-icon :icon="faFolder" class="icon icon-sm me-2"/>src</li>
                            <li>
                                <ul class="list-unstyled ps-4">
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Images and Fonts"><font-awesome-icon :icon="faFolder" class="icon icon-sm me-2"/> assets</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Vue components"><font-awesome-icon :icon="faFolder" class="icon icon-sm me-2"/> components</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Vue Router configuration"><font-awesome-icon :icon="faFolder" class="icon icon-sm me-2"/> router</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Sass source files"><font-awesome-icon :icon="faFolder" class="me-2"/> scss</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Data and Api services used by components"><font-awesome-icon :icon="faFolder" class="me-2"/> services</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Pinia stores"><font-awesome-icon :icon="faFolder" class="me-2"/> stores</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Routable components like pages"><font-awesome-icon :icon="faFolder" class="me-2"/> views</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="App root Vue component"><font-awesome-icon :icon="faFileCode" class="me-2 text-primary"/> App.vue</li>
                                    <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="App entrypoint"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> main.ts</li>
                                </ul>
                            </li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Environment variables"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> .env</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="ESLint configuration"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> .eslintrc.cjs</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="This file ensures that generated files and folder are ignored by Git. (eg. node_modules)"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> .gitignore</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="global modules"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> env.d.ts</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="HTML page where Vue app will be injected into"><font-awesome-icon :icon="faHtml5" class="me-2 text-secondary"/> index.html</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Node dependencies and scripts"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> package.json</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="pnpm lockfile"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> pnpm-lock.yaml</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="TypeScript config file"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> tsconfig.json</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="TypeScript config file for Vite"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> tsconfig.vite-config.json</li>
                            <li class="d-flex align-items-center mb-1" data-bs-toggle="tooltip" data-bs-placement="left" title="Vite config file"><font-awesome-icon :icon="faFileCode" class="me-2 text-secondary"/> vite.config.ts</li>
                        </ul>
                    </div>
                    <div class="col-12 mt-5 d-lg-none">
                        <h5>Vue 3 recommended folder structure</h5>
                        <p>This project was scaffolded from the latest version of <code>create-vue</code> using <code>npm init vue@latest</code></p>
                    </div>
                </div>
            </div>
        </section>
</template>

<script lang="ts" setup>
import { library } from '@fortawesome/fontawesome-svg-core'
import { faBook, faFolder, faFileCode } from '@fortawesome/free-solid-svg-icons'
import {faHtml5, faJsSquare} from '@fortawesome/free-brands-svg-icons'

library.add(
    faBook
)
</script>