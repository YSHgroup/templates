<template>
  <section class="section section-sm pt-0">
    <div class="container">
      <div class="row justify-content-center mb-5 mb-lg-6">
        <div class="col-12 text-center">
          <h2 class="h1 px-lg-5">21 hand-crafted pages</h2>
          <p class="lead px-lg-10">
            Every page from Volt has been carefully built to provide all the
            necessary pages your startup will require
          </p>
        </div>
      </div>
      <div class="row mb-5">
        <div
          class="col-6 mb-5"
          v-for="pageExample in examplePages"
          :key="pageExample.name"
        >
          <HomeExamplePage v-bind="pageExample" />
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import HomeExamplePage from '@/components/HomeExamplePage.vue';

interface PageExample {
  thumbnailFilename: string;
  thumbnailAltText: string;
  routeName: string;
  name: string;
}

const examplePages = ref<PageExample[]>([]);
  examplePages.value.push(
      {
        name: "Overview",
        routeName: "DashboardOverview",
        thumbnailFilename: "overview.jpg",
        thumbnailAltText: "Dashboard page preview",
      },
      {
        name: "Traffic Sources",
        routeName: "DashboardTrafficSources",
        thumbnailFilename: "traffic-sources.jpg",
        thumbnailAltText: "Traffic Sources page preview",
      },
      {
        name: "App Analysis",
        routeName: "DashboardAppAnalysis",
        thumbnailFilename: "app-analysis.jpg",
        thumbnailAltText: "App Analysis page preview",
      },
      {
        name: "Kanban Board",
        routeName: "DashboardKanban",
        thumbnailFilename: "kanban.jpg",
        thumbnailAltText: "Kanban page preview",
      },
      {
        name: "Users List",
        routeName: "DashboardUsersList",
        thumbnailFilename: "users-list.jpg",
        thumbnailAltText: "Users page preview",
      },
      {
        name: "Transactions",
        routeName: "DashboardTransactions",
        thumbnailFilename: "transactions.jpg",
        thumbnailAltText: "Transactions page preview",
      },
      {
        name: "Tasks",
        routeName: "DashboardTasks",
        thumbnailFilename: "tasks.jpg",
        thumbnailAltText: "Tasks page preview",
      },
      {
        name: "Settings",
        routeName: "DashboardSettings",
        thumbnailFilename: "settings.jpg",
        thumbnailAltText: "Settings page preview",
      },
      {
        name: "Messages",
        routeName: "DashboardMessages",
        thumbnailFilename: "messages.jpg",
        thumbnailAltText: "Messages page preview",
      },
      {
        name: "Chat",
        routeName: "DashboardChat",
        thumbnailFilename: "single-message.jpg",
        thumbnailAltText: "Chat page preview",
      },
      // {
      //   name: "Calendar",
      //   routeName: "DashboardCalendar",
      //   thumbnailFilename: "calendar.jpg",
      //   thumbnailAltText: "Calendar page preview",
      // },
      {
        name: "Billing",
        routeName: "DashboardBilling",
        thumbnailFilename: "billing.jpg",
        thumbnailAltText: "Billing page preview",
      },
      {
        name: "Invoice",
        routeName: "DashboardInvoice",
        thumbnailFilename: "invoice.jpg",
        thumbnailAltText: "Invoice page preview",
      },
      {
        name: "Pricing",
        routeName: "DashboardPricing",
        thumbnailFilename: "pricing.jpg",
        thumbnailAltText: "Pricing page preview",
      },
      {
        name: "Sign In",
        routeName: "SignIn",
        thumbnailFilename: "sign-in.jpg",
        thumbnailAltText: "Sign In page preview",
      },
      {
        name: "Sign Up",
        routeName: "SignUp",
        thumbnailFilename: "sign-up.jpg",
        thumbnailAltText: "Sign Up page preview",
      },
      {
        name: "Lock Screen",
        routeName: "Lock",
        thumbnailFilename: "lock.jpg",
        thumbnailAltText: "Lock Screen page preview",
      },
      {
        name: "Forgot password",
        routeName: "ForgotPassword",
        thumbnailFilename: "forgot-password.jpg",
        thumbnailAltText: "Forgot password page preview",
      },
      {
        name: "Reset password",
        routeName: "ResetPassword",
        thumbnailFilename: "reset-password.jpg",
        thumbnailAltText: "Reset password page preview",
      },
      {
        name: "404",
        routeName: "404",
        thumbnailFilename: "404.jpg",
        thumbnailAltText: "404 error page preview",
      },
      {
        name: "500",
        routeName: "500",
        thumbnailFilename: "500.jpg",
        thumbnailAltText: "500 error page preview",
      }
    );
</script>