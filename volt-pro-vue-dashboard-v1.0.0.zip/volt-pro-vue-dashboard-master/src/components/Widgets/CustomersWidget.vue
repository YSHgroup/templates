<template>
    <div class="card border-0 shadow">
        <div class="card-body">
          <div class="row d-block d-xxl-flex align-items-center">
            <div class="col-12 col-xxl-6 px-xxl-0 mb-3 mb-xxl-0">
              <div id="chart-customers"></div>
              <apexchart type="area" :options="options" :series="series" />
            </div>
            <div class="col-12 col-xxl-6 px-ssl-4 pe-xxl-0">              
                <h2 class="fs-6 fw-normal mb-1 text-gray-400">Customers</h2>
                <h3 class="fw-extrabold mb-1">345k</h3>
                <small class="d-flex align-items-center">
                  <CalendarIcon class="icon icon-xxs text-gray-400 me-1" />
                  April 1 - May 1
                </small>
                <div class="small d-flex mt-1">
                  <ChevronUpIcon class="icon icon-xs text-success" />
                  <span class="text-success fw-bolder me-1">18,2%</span>
                  Since last month
              </div>
            </div>
          </div>
        </div>
      </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import {CalendarIcon, ChevronUpIcon} from 'heroicons-vue3/solid'
import type { ApexOptions } from 'apexcharts'

  const options = ref<ApexOptions>({
      labels: ['01 Feb', '02 Feb', '03 Feb', '04 Feb', '05 Feb', '06 Feb', '07 Feb', '08 Feb', '09 Feb', '10 Feb', '11 Feb'],
      chart: {
          type: 'area',
          width: "100%",
          height: 140,
          sparkline: {
              enabled: true
          }
      },
      theme: {
          monochrome: {
              enabled: true,
              color: '#31316A',
          }
      },
      tooltip: {
          fillSeriesColor: false,
          onDatasetHover: {
              highlightDataSeries: false,
          },
          theme: 'light',
          style: {
              fontSize: '12px',
              fontFamily: 'Inter',
          },
      }
    });

const series = ref([{
      name: 'Clients',
      data: [120, 160, 200, 470, 420, 150, 470, 750, 650, 190, 140]
  }]);
</script>
