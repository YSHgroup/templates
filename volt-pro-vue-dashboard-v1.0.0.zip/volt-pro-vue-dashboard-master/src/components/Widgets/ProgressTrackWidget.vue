<template>
    <div class="card border-0 shadow">
        <div class="card-header border-bottom d-flex align-items-center justify-content-between">
            <h2 class="fs-5 fw-bold mb-0">Progress track</h2>
                <a href="#" class="btn btn-sm btn-primary">See tasks</a>
            </div>
        <div class="card-body">
            <div class="row align-items-center mb-4" v-for="project in projects" :key="project.name">
                <div class="col-auto">
                    <ClipboardListIcon class="icon icon-sm text-gray-500" />
                </div>
                <div class="col">
                    <div class="progress-wrapper">
                        <div class="progress-info">
                            <div class="h6 mb-0">{{ project.name }}</div>
                            <div class="small fw-bold text-gray-500"><span>{{ project.percentage }} %</span></div>
                        </div>
                        <div class="progress mb-0">
                            <div class="progress-bar" :class="getProgressBarClass(project.percentage)" role="progressbar" :aria-valuenow="project.percentage" aria-valuemin="0" aria-valuemax="100" :style="{width: project.percentage + '%'}"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import { ClipboardListIcon } from 'heroicons-vue3/solid'
import { type Project, getProjectsAsync } from '@/services/DataService'

const projects = ref<Project[]>();

watch(() => '',
async() => {
    projects.value = await getProjectsAsync();
},
{ immediate: true})

        
function getProgressBarClass(percentage: number){
    if (percentage >= 60){
        return 'bg-success';
    }
    else if (percentage >= 40){
        return 'bg-warning';
    }
    else{
        return 'bg-danger';
    }
}
</script>
