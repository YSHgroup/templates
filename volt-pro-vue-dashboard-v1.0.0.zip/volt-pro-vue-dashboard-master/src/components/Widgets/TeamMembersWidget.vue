<template>
  <div class="card border-0 shadow">
    <div class="card-header border-bottom d-flex align-items-center justify-content-between">
      <h2 class="fs-5 fw-bold mb-0">Team members</h2>
      <a href="../users.html" class="btn btn-sm btn-primary">See all</a>
    </div>
    <div class="card-body">
      <ul class="list-group list-group-flush list my--3">
        <li class="list-group-item px-0" v-for="teamMember in teamMembers" :key="teamMember.avatarFilename">
          <div class="row align-items-center">
            <div class="col-auto">
              <!-- Avatar -->
              <a href="#" class="avatar">
                <img
                  class="rounded-circle"
                  alt="Image placeholder"
                  :src="getAvatarUrl(teamMember.avatarFilename)"
                />
              </a>
            </div>
            <div class="col-auto ms--2">
              <h4 class="h6 mb-0">
                <a href="#">{{teamMember.name}}</a>
              </h4>
              <div class="d-flex align-items-center">
                <template v-if="teamMember.status == 1">
                  <div class="bg-success dot rounded-circle me-1"></div>
                  <small>Online</small>
                </template>
                <template v-else-if="teamMember.status == 2">
                  <div class="d-flex align-items-center">
                      <div class="bg-warning dot rounded-circle me-1"></div>
                      <small>In a meeting</small>
                  </div>
                </template>
                <template v-else>
                  <div class="d-flex align-items-center">
                      <div class="bg-danger dot rounded-circle me-1"></div>
                      <small>Offline</small>
                  </div>
                </template>
              </div>    
            </div>
            <div class="col text-end">
              <a v-if="teamMember.status == 1 || teamMember.status == 2" href="#" class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                  <ChatAltIcon class="icon icon-xxs me-2" />
                  Message
              </a>
              <a v-else href="../calendar.html" class="btn btn-sm btn-secondary d-inline-flex align-items-center">
                <CalendarIcon class="icon icon-xxs me-2" />
                Invite
              </a>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { type TeamMember, getTeamMembersAsync} from '@/services/DataService'
import { CalendarIcon, ChatAltIcon } from 'heroicons-vue3/solid'
import { getAvatarUrl } from '@/services/Functions';

const teamMembers = ref<TeamMember[]>([]);

(async () => {
    teamMembers.value = await getTeamMembersAsync();
})();

  
</script>
