<template>
    <div class="card border-0 bg-secondary shadow">
        <div class="card-header d-sm-flex flex-row align-items-center  flex-0">
          <div class="d-block mb-3 mb-sm-0">
            <div class="fs-5 fw-normal mb-2">Sales Value</div>
            <h2 class="fs-3 fw-extrabold">$10,567</h2>
            <div class="small mt-2">
              <span class="fw-normal me-2">Yesterday</span>
              <span class="text-tertiary"><font-awesome-icon :icon="faAngleUp"/></span>
              <span class="text-tertiary fw-bold">10.57%</span>
            </div>
          </div>
          <div class="btn-group ms-auto" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-tertiary active">Day</button>
            <button type="button" class="btn btn-tertiary">Month</button>
            <button type="button" class="btn btn-tertiary">Year</button>
          </div>
        </div>
        <div class="card-body p-2">
          <apexchart type="area" :options="options" :series="series" height="420" />
        </div>
      </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import {
  faAngleUp,
} from "@fortawesome/free-solid-svg-icons";
import type { ApexOptions } from 'apexcharts';


const series = ref([
    {
        name: "Sales",
        data: [95, 52, 78, 45, 19, 53, 60]
    }
]);
        
const options = ref<ApexOptions>({
    chart: {
        height: 420,
        type: "area",
        fontFamily: 'Inter',
        foreColor: '#4B5563',
        toolbar: {
            show: true,
            offsetX: 0,
            offsetY: 0,
            tools: {
                download: false,
                selection: false,
                zoom: false,
                zoomin: true,
                zoomout: true,
                pan: false,
                reset: false,
                customIcons: []
            },
            export: {
                csv: {
                    filename: undefined,
                    columnDelimiter: ',',
                    headerCategory: 'category',
                    headerValue: 'value',
                    dateFormatter(timestamp: number) {
                        return new Date(timestamp).toDateString()
                    }
                }
            },
            autoSelected: 'zoom'
        },
    },
    dataLabels: {
        enabled: false
    },
    tooltip: {
        style: {
            fontSize: '14px',
            fontFamily: 'Inter',
        },
    },
    theme: {
        monochrome: {
            enabled: true,
            color: '#35495e',
        }
    },
    grid: {
        show: true,
        borderColor: '#35495e',
        strokeDashArray: 1,
    },
    markers: {
        size: 5,
        strokeColors: '#ffffff',
        hover: {
            size: undefined,
            sizeOffset: 3
        }
    },
    xaxis: {
        categories: ['01 Feb', '02 Feb', '03 Feb', '04 Feb', '05 Feb', '06 Feb', '07 Feb'],
        labels: {
            style: {
                fontSize: '12px',
                fontWeight: 500,
            },
        },
        axisBorder: {
            color: '#35495e',
        },
        axisTicks: {
            color: '#35495e',
        }
    },
    yaxis: {
        labels: {
            style: {
                colors: ['#4B5563'],
                fontSize: '12px',
                fontWeight: 500,
            },
        },
    },
    responsive: [
        {
            breakpoint: 768,
            options: {
                yaxis: {
                    show: false,
                }
            }
        }
    ]
})
</script>
