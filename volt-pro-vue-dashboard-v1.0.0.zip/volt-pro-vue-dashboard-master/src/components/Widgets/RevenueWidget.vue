<template>
  <div class="card border-0 shadow">
    <div class="card-body">
      <div class="row d-block d-xxl-flex align-items-center">
        <div class="col-12 col-xxl-6 px-xxl-0 mb-3 mb-xxl-0">
          <apexchart type="bar" :options="options" :series="series" />
        </div>
        <div class="col-12 col-xxl-6 ps-xxl-4 pe-xl-0">
          <h2 class="fs-6 fw-normal mb-1 text-gray-400">Revenue</h2>
          <h3 class="fw-extrabold mb-1">$253,594</h3>
          <small class="d-flex align-items-center">
            <CalendarIcon class="icon icon-xxs text-gray-400 me-1" />
            Apr 1 - May 1
          </small>
          <div class="small d-flex mt-1">
            <div>
              <ChevronDownIcon class="icon icon-xs text-danger" />
              <span class="text-danger fw-bolder">4,6%</span> Since last month
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import {CalendarIcon, ChevronDownIcon} from 'heroicons-vue3/solid'
import type { ApexOptions } from 'apexcharts'

const series = ref([{
    name: 'Sales',
    data: [34, 29, 32, 38, 39, 35, 36]
}]);

const options = ref<ApexOptions>({
  chart: {
    type: 'bar',
      width: "100%",
      height: 140,
      sparkline: {
        enabled: true
      }
  },
  theme: {
    monochrome: {
      enabled: true,
          color: '#31316A',
      }
  },
  plotOptions: {
    bar: {
      columnWidth: '25%',
      borderRadius: 5,
      colors: {
        backgroundBarColors: ['#F2F4F6', '#F2F4F6', '#F2F4F6', '#F2F4F6'],
        backgroundBarRadius: 5
      }
    }
  },
  labels: [1, 2, 3, 4, 5, 6, 7].map(n => n.toString()),
  xaxis: {
      categories: ['01 Feb', '02 Feb', '03 Feb', '04 Feb', '05 Feb', '06 Feb', '07 Feb'],
      crosshairs: {
          width: 1
      },
  },
  tooltip: {
      fillSeriesColor: false,
      onDatasetHover: {
          highlightDataSeries: false,
      },
      theme: 'light',
      style: {
          fontSize: '12px',
          fontFamily: 'Inter',
      },
      y: {
          formatter: function (val) {
              return "$ " + val + "k"
          }
      }
  }
});
</script>
