<template>
  <div class="card border-0 shadow">
    <div class="card-body">
      <div class="row d-block d-sm-flex d-xl-block d-xxl-flex align-items-center">
        <div class="col-12 col-sm-6 col-xl-12 col-xxl-6 px-xxl-0 mb-3 mb-sm-0 mb-xl-3 mb-xxl-0">
          <apexchart type="area" :options="options" :series="series" />
        </div>
        <div class="col-12 col-sm-6 col-xl-12 col-xxl-6 ps-xxl-4 pe-xxl-0">
          <h2 class="fs-6 fw-normal mb-1 text-gray-400">Users</h2>
          <h3 class="fw-extrabold mb-1">15.3k</h3>
          <small class="d-flex align-items-center">
              <CalendarIcon class="icon icon-xxs text-gray-400 me-1" />
              Apr 1 - May 1
          </small> 
          <div class="small d-flex mt-1">                               
              <div>
                <ChevronUpIcon class="icon icon-xs text-success" />
                <span class="text-success fw-bolder">20%</span> Since last month
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import {CalendarIcon, ChevronUpIcon} from 'heroicons-vue3/solid'
import type { ApexOptions } from 'apexcharts';

const series = ref([{
      name: 'Users',
      data: [520, 560, 500, 570, 520, 550, 570, 550, 550, 590, 540]
  }]);

const options = ref<ApexOptions>({
  labels: ['06PM', '02 Feb', '03 Feb', '04 Feb', '05 Feb', '06 Feb', '07 Feb', '08 Feb', '09 Feb', '10 Feb', '11 Feb'],
  chart: {
      type: 'area',
      width: "100%",
      height: 140,
      sparkline: {
          enabled: true
      }
  },
  theme: {
      monochrome: {
          enabled: true,
          color: '#31316A',
      }
  },
  tooltip: {
      fillSeriesColor: false,
      onDatasetHover: {
          highlightDataSeries: false,
      },
      theme: 'light',
      style: {
          fontSize: '12px',
          fontFamily: 'Inter',
      },
  }
})
</script>
