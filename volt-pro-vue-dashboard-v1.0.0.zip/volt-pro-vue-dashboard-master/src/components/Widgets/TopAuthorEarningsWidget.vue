<template>
  <div class="card border-0 shadow">
    <div class="card-header border-bottom">
        <h2 class="fs-5 fw-bold mb-0">Top Author Earnings</h2>
    </div>
    <div class="card-body py-0">
      <ul class="list-group list-group-flush">
        <li class="list-group-item bg-transparent border-bottom py-3 px-0" v-for="(author, i) in authors" :key="i">
            <div class="row align-items-center">
                <div class="col-auto">
                    <!-- Avatar -->
                    <a href="#" class="avatar-md">
                        <img class="rounded" alt="Image placeholder" :src="getAvatarUrl(author.avatarFilename)">
                    </a>
                </div>
                <div class="col-auto px-0">
                    <h4 class="fs-6 text-dark mb-0">
                        <a href="#">{{author.authorName}}</a>
                    </h4>
                    <span class="small">{{author.authorTitle}}</span>
                </div>
                <div class="col text-end">
                    <span class="fs-6 fw-bolder text-dark">${{toLocale(author.earnings)}}</span>
                </div>
            </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { getAuthorEarnings, AuthorEarnings } from '@/services/WidgetDataService'
import { getAvatarUrl } from '@/services/Functions';

const authors = ref<AuthorEarnings[]>([]);

function toLocale(num: number){
  return num.toLocaleString();
}

(async () => {
  authors.value = await getAuthorEarnings();
})();
</script>
