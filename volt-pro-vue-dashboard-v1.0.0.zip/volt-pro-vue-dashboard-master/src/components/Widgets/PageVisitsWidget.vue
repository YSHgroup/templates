<template>
  <div class="card border-0 shadow">
    <div class="card-header">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="fs-5 fw-bold mb-0">Page visits</h2>
        </div>
        <div class="col text-end">
            <a href="./traffic-sources.html" class="btn btn-sm btn-primary">See all</a>
        </div>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table align-items-center table-flush">
        <thead class="thead-light">
          <tr>
            <th class="border-bottom" scope="col">Page name</th>
            <th class="border-bottom" scope="col">Page Views</th>
            <th class="border-bottom" scope="col">Page Value</th>
            <th class="border-bottom" scope="col">Bounce rate</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="page in pageVisits" :key="page.pageName">
            <th class="text-gray-900" scope="row">
              {{page.pageName}}
            </th>
            <td class="fw-bolder text-gray-500">
              {{page.pageViews}}
            </td>
            <td class="fw-bolder text-gray-500">
              ${{page.pageValue}}
            </td>
            <td class="fw-bolder text-gray-500">
              <div class="d-flex">
                <ArrowNarrowUpIcon v-if="page.bounceRateIncreased" class="icon icon-xs text-danger me-2" />
                <ArrowNarrowDownIcon v-else class="icon icon-xs text-success me-2" />
                {{page.bounceRate}}%
              </div>              
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import {getPageVisitsSummaryAsync, type PageVisit} from '@/services/DataService'
import router from '@/router';
import { ArrowNarrowUpIcon, ArrowNarrowDownIcon } from 'heroicons-vue3/solid'


const pageVisits = ref<PageVisit[]>();

//api call to get data
//in a real-world scenerio, we would get data based on a router value
watch(
  () => router.currentRoute.value.query,
  async () => {
    pageVisits.value = await getPageVisitsSummaryAsync();
  },
  { immediate: true }
)
</script>
