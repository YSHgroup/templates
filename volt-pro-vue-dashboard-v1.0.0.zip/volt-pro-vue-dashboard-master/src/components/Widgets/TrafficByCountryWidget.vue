<template>
    <div class="card border-0 shadow">
        <div class="card-header pb-5">
            <h2 class="fs-5 fw-bold mb-1">Visits past 30 days by country</h2>
            <div id="map" ref="elMap"></div>
        </div>
        <div class="card-body py-4">
            <div v-for="(country, i) in countries"
                :key="country.name"
                class="row align-items-center"
                :class="i == countries.length - 1 ? '' : 'mb-4'" >
                <div class="col-auto">
                    <!-- Avatar -->
                    <a href="#" class="image image-xs rounded-circle">
                    <img alt="Image placeholder" :src="getFlagUrl(country.flagFilename)">
                    </a>
                </div>
                <div class="col">
                    <div class="progress-wrapper">
                        <div class="progress-info">
                            <div class="h6 mb-0">{{ country.name }} <span class="text-gray-500 font-small">({{ country.visitCount }})</span></div>
                            <div class="small fw-bold"><span>{{ country.visitPercentage }} %</span></div>
                        </div>
                        <div class="progress mb-0">
                            <div class="progress-bar bg-dark" role="progressbar" :aria-valuenow="country.visitPercentage" aria-valuemin="0" aria-valuemax="100" :style="{width: country.visitPercentage + '%'}"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer bg-gray-50 border-top text-center">
            <a class="fw-bold d-flex align-items-center justify-content-center" href="../calendar.html">
                <EyeIcon class="icon icon-xs me-2" />
                See all
            </a>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from 'vue'
import { CountryVisit, getCountryVisits } from '@/services/WidgetDataService'
import svgMap from 'svgmap'
import { EyeIcon } from 'heroicons-vue3/solid'
import { getFlagUrl } from '@/services/Functions'

const countries = ref<CountryVisit[]>([]);
const elMap = ref<HTMLElement>();

watch(() => '',
async() => {
    countries.value = await getCountryVisits();
},
{ immediate: true})

onMounted(() => {
    if (elMap.value){
        new svgMap({
            targetElementID: 'map',
            colorMin: '#41b883',
            colorMax: '#017843',
            //colorMin: '#81f8c3',
            //colorMax: '#41b883',
            flagType: 'emoji',
            data: {
                data: {
                    visitors: {
                        name: 'Visitors',
                        format: '{0} visitors',
                        thousandSeparator: ',',
                        thresholdMax: 500000,
                        thresholdMin: 0
                    },
                    change: {
                        name: 'Change by month',
                        format: '{0} %'
                    }
                },
                applyData: 'visitors',
                values: {
                    US: { visitors: 272109, change: 4.73 },
                    CA: { visitors: 160064, change: 11.09 },
                    DE: { visitors: 120048, change: -2.3 },
                    GB: { visitors: 110048, change: 3.3 },
                    FR: { visitors: 100048, change: 1.3 },
                    ES: { visitors: 90048, change: 1.5 },
                    JP: { visitors: 56022, change: 3.5 },
                    IT: { visitors: 48019, change: 1 },
                    NL: { visitors: 40016, change: 2 },
                    RU: { visitors: 30016, change: 3.4 },
                    CN: { visitors: 50016, change: 6 },
                    IN: { visitors: 140016, change: 2 },
                    BR: { visitors: 40016, change: 5 },
                    // ...
                }
            }
        });
    }
})
</script>
