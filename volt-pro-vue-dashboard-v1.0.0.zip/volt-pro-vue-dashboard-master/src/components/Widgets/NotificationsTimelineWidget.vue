<template>
  <div class="card notification-card border-0 shadow">
    <div class="card-header d-flex align-items-center">
        <h2 class="fs-5 fw-bold mb-0">Notifications</h2>
        <div class="ms-auto">
          <a class="fw-normal d-inline-flex align-items-center" href="#">
            <EyeIcon class="icon icon-xxs me-2" />
            View all
          </a>
        </div>
    </div>
    <div class="card-body">
      <div class="list-group list-group-flush list-group-timeline">
        <div class="list-group-item border-0" v-for="(notification, i) in notifications" :key="i">
          <div class="row ps-lg-1">
            <div class="col-auto">
              <div class="icon-shape icon-xs rounded" :class="'icon-shape-' + notification.iconShapeColor">
                <component :is="notification.iconName" />
              </div>
            </div>
            <div class="col ms-n2 mb-3">
              <h3 class="fs-6 fw-bold mb-1">{{notification.subject}}</h3>
              <p class="mb-1">{{notification.message}}</p>
              <div class="d-flex align-items-center">
                  <ClockIcon class="icon icon-xxs text-gray-400 me-1" />
                  <span class="small">{{toRelativeDate(notification.timestamp)}}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { getNotifications, Notification } from '@/services/WidgetDataService'
import {EyeIcon, ClockIcon} from 'heroicons-vue3/solid'
import type {DateTime} from 'luxon'
import { ref } from 'vue'

const notifications = ref<Notification[]>([]);

(async () => {
  notifications.value = await getNotifications();
})()


function toRelativeDate(date: DateTime){
  return date.toRelative()
}
</script>
