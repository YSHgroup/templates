<template>
    <div class="card border-0 shadow">
        <div class="card-header border-bottom">
            <h2 class="fs-5 fw-bold mb-1">Events</h2>
        </div>
        <div class="card-body">
            <div v-for="(event,i) in events" :key="i"
                class="row align-items-center d-block d-sm-flex" :class="i == events.length - 1 ? '' : 'border-bottom pb-4 mb-4'"
                >
                <div class="col-auto mb-3 mb-sm-0">
                    <div class="calendar d-flex">
                        <span class="calendar-month">{{ getMonth(event.startDateDate) }}</span>
                        <span class="calendar-day py-2">{{ getDay(event.startDateDate) }}</span></div>
                </div>
                <div class="col">
                    <a href=""><h3 class="h5 mb-1">{{ event.title }}</h3></a>
                    <span>Organized by <a href="#">{{ event.organizedBy }}</a></span>
                    <div v-if="!event.endDate" class="small fw-bold">Time: {{ getTime(event.startDateDate) }}</div>
                        <div v-else class="small fw-bold">{{ getDateAbbr(event.startDateDate, false) }} - {{ getDateAbbr(new Date(event.endDate), true) }}</div>
                    <span class="small fw-bold">Place: {{ event.location }}</span>
                </div>
            </div>
        </div>
        <div class="card-footer border-top bg-gray-50">
            <a class="fw-bold d-flex align-items-center justify-content-center" href="../calendar.html">
                <EyeIcon class="icon icon-xs me-2" />
                See all
            </a>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import { format } from 'date-fns'
import { Event, getEvents } from '@/services/WidgetDataService';
import { EyeIcon } from 'heroicons-vue3/solid'


const events = ref<Event[]>([]);
        
watch(() => '',
    async() => {
        events.value = await getEvents();
    },
{ immediate: true})

function getMonth(date: Date){
    return format(date, 'MMM');
}


function getDay(date: Date){
    return format(date, 'dd');
}
        
function getTime(date: Date){
    return format(date, 'p');
}
        
function getDateAbbr(date: Date, includeYear: boolean){
    const formatString = 'eee, dd MMM' + (includeYear ?  ' yyyy' : ''); 
    return format(date, formatString);
}
</script>
