<template>
  <div class="card border-0 shadow">
    <div class="card-header border-bottom">
        <h2 class="fs-5 fw-bold mb-1">Weekly Sales</h2>
        <small>28 Daily Avg.</small> 
    </div>
    <div class="card-body text-center py-4 py-xl-5">
        <h3 class="display-3 fw-extrabold mb-0">$456,678</h3>
        <p>Total Themesberg Sales</p>
        <a href="#" class="btn btn-primary d-inline-flex align-items-center">
            <DocumentTextIcon class="icon icon-xxs me-2" />
            Generate Report
        </a>
    </div>
    <div class="card-footer border-0 px-3 py-4">
        <apexchart type="bar" :options="options" :series="series" height="260" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import {DocumentTextIcon} from 'heroicons-vue3/solid'
import type { ApexOptions } from 'apexcharts';

const series = ref([{
    name: 'Sales',
    data: [32, 44, 37, 47, 42, 55, 47, 65]
}]);

const options = ref<ApexOptions>({
    chart: {
        type: 'bar',
        width: "100%",
        height: 260,
        sparkline: {
            enabled: true
        }
    },
    theme: {
        monochrome: {
            enabled: true,
            color: '#31316A',
        }
    },
    plotOptions: {
        bar: {
            columnWidth: '20%',
            borderRadius: 5,
            horizontal: false,
            distributed: false,
            colors: {
                backgroundBarColors: ['#F2F4F6', '#F2F4F6', '#F2F4F6', '#F2F4F6'],
                backgroundBarRadius: 5,
            },
        }
    },
    labels: [1, 2, 3, 4, 5, 6, 7, 8].map(n => n.toString()),
    xaxis: {
        categories: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7', 'Week 8'],
        crosshairs: {
            width: 1
        },
    },
    tooltip: {
        fillSeriesColor: false,
        onDatasetHover: {
            highlightDataSeries: false,
        },
        theme: 'light',
        style: {
            fontSize: '12px',
            fontFamily: 'Inter',
        },
        y: {
            formatter: function (val: number) {
                return "$ " + val + "k"
            }
        }
    }
})
</script>
