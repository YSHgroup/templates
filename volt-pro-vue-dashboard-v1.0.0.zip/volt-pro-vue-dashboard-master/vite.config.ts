import { fileURLToPath, URL } from 'url'

import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig(({command, mode}) => {
  const env = loadEnv(mode, process.cwd());

  //uncomment VITE_BASE_PATH in env.production if you host in a subpath
  const baseFromConfig = env.VITE_BASE_PATH;
  console.log('env', env);
  console.log('base from config: ', baseFromConfig);
  
  const config = {
    base: baseFromConfig ? baseFromConfig : undefined,
    plugins: [vue()],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url))
      }
    }
  };

  return config;
})
