/// <reference types="vite/client" />

//https://vitejs.dev/guide/env-and-mode.html#intellisense-for-typescript
interface ImportMetaEnv {
  readonly VITE_DOCS_VERSION: string
  readonly VITE_MAPBOX_TOKEN: string
  readonly VITE_MAPBOX_ID: string
}
  
interface ImportMeta {
  readonly env: ImportMetaEnv
}

//hack until tooling fixes .vue imports from .ts files
//declare module '*.vue';

//these libraries don't have any types so we have to declare some here
declare module 'svgmap';
declare module 'simple-datatables';

//needed bc a dependency uses BigInt class
class BigInt{
  
}

