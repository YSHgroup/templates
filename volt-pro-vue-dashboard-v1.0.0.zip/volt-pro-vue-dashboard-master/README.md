# Volt Vue Pro Dashboard  -Bootstrap 5, Vite, TypesScript, Pinia

Volt Vue Pro Dashboard is an admin dashboard built in TypeScript using [Vue 3](https://vuejs.org/) front-end framework and styled with [Bootstrap 5](https://getbootstrap.com/) CSS framework. It is based on the latest recommended developer experience (DX) tooling and Vue framework libraries, such as Vite, Vue Router, and Pinia.

## Powered by Vue 3
Volt Vue Pro is powered by the latest version of the popular front-end framework Vue 3 and its related libraries.

## Data-driven
Components were built with real-world scenerios in mind in a data-driven fashion. For example, tasks, messages, user notifications, etc are all arrays of data fed to component templates. This will make it easy to wire up  the UI to a back-end API.

## Bootstrap 5
This library is based on the latest version of the [Bootstrap 5 CSS framework](https://getbootstrap.com/) which brought many improvements, such as [dropping dependency on jQuery](https://themesberg.com/blog/tutorial/bootstrap-5-tutorial), introducing RTL support, the utility API and many other style and markup improvements.

## TypeScript
This library is built using [TypeScript](https://www.typescriptlang.org/), which is a superset of JavaScript and provides type safety at compile time. The Vue 3 source itself is written in TypeScript.

## Vite
[Vite](https://vitejs.dev/) is now the recommended frontend builder for Vue 3. It was written by Evan Yu, the creator of Vue. It is lightning fast and will speed up your development time by updating the browser instantly when you make changes (Hot Module Replacement).

## Vue Router
[Vue Router](https://router.vuejs.org/) has also been rewritten in TypeScript for Vue 3. It is the offical router of Vue.

## Pinia
[Pinia](https://pinia.vuejs.org/) is now the recommended library for state management in Vue 3. It is TypeScript friendly and requires much less boilerplate than Vuex. A sample implementation is included in this template.

## Single-file Component with script setup
Vue 3 introduced a simplified way of writing Single File Components (SFCs) in Vue 3 using [`script setup`](https://vuejs.org/api/sfc-script-setup.html#script-setup). It is the recommended way to write components using the new Composition Api. Creating components with Options API is still supported and they can live side by side with Composition API components. All components in this template are written using `script setup` with the Composition API.

## 10 Example Dashboard Pages

Get started with 10 beautiful example pages for a dashboard which is based on the most popular dashboard template written in Bootstrap 5, called [Volt Dashboard](https://github.com/themesberg/volt-bootstrap-5-dashboard).

## Workflow

This product is built using the following popular front-end technologies:

- Vue 3 front-end framework
  - create-vue
  - Vite
  - Vue Router
  - Pinia
- Bootstrap 5 CSS Framework
- TypeScript
- SASS CSS preprocessor
- ESLint
- PNPM / NPM / Yarn

## Table of Contents

* [Version](#versions)
* [Demo](#demo)
* [Quick Start](#quick-start)
* [Documentation](#documentation)
* [File Structure](#file-structure)
* [Browser Support](#browser-support)
* [Resources](#resources)
* [Reporting Issues](#reporting-issues)
* [Technical Support or Questions](#technical-support-or-questions)
* [Licensing](#licensing)
* [Useful Links](#useful-links)

## Versions

[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/html-logo.jpg?raw=true" width="60" height="60" />](https://themesberg.com/product/admin-dashboard/volt-bootstrap-5-dashboard)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/react-logo.jpg?raw=true" width="60" height="60" />](https://themesberg.com/product/dashboard/volt-react)[<img src="https://themesberg.s3.us-east-2.amazonaws.com/public/github/technology/laravel-logo.jpeg" width="60" height="60" />](https://themesberg.com/product/laravel/volt-admin-dashboard-template).

| HTML | React  |
| --- | ---  |
| [![Volt Bootstrap 5 Dashboard HTML](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-bootstrap-5-dashboard/volt-bootstrap-5-dashboard-preview.jpg)](https://github.com/themesberg/volt-bootstrap-5-dashboard) | [![Volt React Dashboard](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-react-dashboard/thumbnail.png)](https://demo.themesberg.com/volt-react-dashboard/)

## Demo

| Dashboard | Transactions | Settings | Forms |
| --- | --- | --- | --- |
| [![Dashboard](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/overview.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/dashboard/overview) | [![Transactions](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/transactions.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/transactions) | [![Settings](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/settings.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/settings) | [![Tables](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/tables.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/tables/bootstrap-tables)

| Sign in | Sign up | Forgot password | Reset password |
| --- | --- | --- | --- |
| [![Sign in](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/sign-in.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/sign-in) | [![Sign up](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/sign-up.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/sign-up) | [![Forgot Password](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/forgot-password.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/forgot-password) | [![Reset password](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/reset-password.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/reset-password)

| Lock Profile | 404 Not Found | 500 Server Error | Documentation |
| --- | --- | --- | --- |
| [![Lock Profile](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/lock.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/lock) | [![404 Not Found](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/404.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/404) | [![500 Server Error](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/500.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/examples/500) | [![Documentation](https://themesberg.s3.us-east-2.amazonaws.com/public/products/volt-pro-react-dashboard/github/docs.jpg)](https://demo.themesberg.com/volt-react-dashboard/#/documentation/quick-start)

-   [Live Demo](https://demo.themesberg.com/volt-react-dashboard)
-   [Download](https://themesberg.com/product/dashboard/volt-react)

## QuickStart
1. Register and Download from [Themesberg](https://themesberg.com/product/dashboard/volt-react) or clone this repository

Also see [Quick Start]() in the documentation.

### Option 1: Using PNPM (Recommended, used by Vue 3 source repositories)
2. Make sure you have [Node.js](https://nodejs.org/en/) installed. We recommended the latest LTS version.
3. Install [PNPM](https://pnpm.io/)
4. Open a terminal and change directory to the root of the Volt Vue Pro directory. Run `pnpm install` to download all project dependencies.
```
pnpm install
```

### Option 2: Using NPM
2. Install [Node.js](https://nodejs.org/en/) if you haven't already. NPM is included with Node.
3. Open a terminal and change directory into the root folder of this project. Run `npm install` to download all project dependencies.
```
npm install
```

### Option 3: Using Yarn
2. Yarn is also supported, but we recommend using PNPM or NPM instead of Yarn.
3. If you prefer Yarn, you most likely already have it installed and know the Yarn commands.

### Running the app (PNPM, NPM, or Yarn)
5. Start the app in development mode by running the following command in terminal at the root of your project:
```
npm run dev
```

6. Navigate to [http://localhost:3000/](http://localhost:3000/) to see your app in the browser. Any chnages you make to your code will automatically be reflected in the browser thanks to Vite and HMR (Hot module reloading)

7. To generate production files, run in a terminal
```
npm run build
```

## Documentation
See our [online documentation]() for extensive documentation, including how to get started, what IDEs and plugins to use, folder structure with notes, and links to resources.

## File Structure
After download or git clone you'll find the following directories and files:

```
Volt React Dashboard
.
├── LICENSE.md
├── README.md
├── OVERVIEW.md
├── .env
├── .eslintrc.cjs
├── .gitignore
├── env.d.ts
├── index.html
├── package.json
├── pnpm-lock.yaml
├── tsconfig.json
├── tsconfig.vite-config.json
├── vite.config.ts
├── public
│   ├── android-chrome-192x192.png
│   ├── android-chrome-512x512.png
│   ├── apple-touch-icon.png
│   ├── browserconfig.xml
│   ├── favicon-16x16.png
│   ├── favicon-32x32.png
│   ├── favicon.ico
│   ├── index.html
│   ├── manifest.json
│   ├── mstile-150x150.png
│   ├── safari-pinned-tab.svg
│   └── site.webmanifest
|── src
    ├── assets
    │   ├── img
    ├── components/
    │   ├── Dashboard/
    │   ├── Shared/
    │   ├── Widgets/
    │
    ├── router/
    ├── scss/
    ├── services/
    ├── stores/
    ├── views/
    │   ├── Dashboard/
    │   ├── Examples/
    │   ├── About.vue
    │   ├── Dashboard.vue
    │   ├── Home.vue
    │   ├── Messages.vue
    ├── App.vue
    ├── main.ts
    |── stub/


```

## Browser Support

At present, we officially aim to support the last two versions of the following browsers:

<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/chrome.png" width="64" height="64">
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/firefox.png" width="64" height="64">
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/edge.png" width="64" height="64">
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/safari.png" width="64" height="64">
<img src="https://s3.amazonaws.com/creativetim_bucket/github/browser/opera.png" width="64" height="64">

## Resources

- Demo: <https://demo.themesberg.com/volt-react-dashboard>
- Download Page: <https://themesberg.com/product/dashboard/volt-react>
- Documentation: <https://demo.themesberg.com/volt-react-dashboard/#/documentation/overview>
- License Agreement: <https://themesberg.com/licensing>
- Support: <https://themesberg.com/contact>
- Issues: [Github Issues Page](https://github.com/themesberg/volt-react-dashboard/issues)

## Reporting Issues

We use GitHub Issues as the official bug tracker for Volt React Dashboard. Here are some advices for our users that want to report an issue:

1. Make sure that you are using the latest version of Volt React Dashboard. Check the CHANGELOG from your dashboard on our [website](https://themesberg.com/product/dashboard/volt-react#changelog).
2. Providing us reproducible steps for the issue will shorten the time it takes for it to be fixed.
3. Some issues may be browser specific, so specifying in what browser you encountered the issue might help.

## Technical Support or Questions

If you have questions or need help integrating the product please [contact us](https://themesberg.com/contact) instead of opening an issue.

## Licensing

- Copyright 2021 Themesberg (Crafty Dwarf LLC) (https://themesberg.com)
- Themesberg [license](https://themesberg.com/licensing#mit) (MIT License)

## Useful Links

- [React themes](https://themesberg.com/templates/react) from Themesberg
- [Affiliate Program](https://themesberg.com/affiliate)

##### Social Media

Twitter: <https://twitter.com/themesberg>

Facebook: <https://www.facebook.com/themesberg/>

Dribbble: <https://dribbble.com/themesberg>

Instagram: <https://www.instagram.com/themesberg/>

